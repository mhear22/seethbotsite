--
-- PostgreSQL database dump
--

\restrict Yzl3XdvdT3R5hb83RoRXVYCBzUisVk0HkgzO06X0j1t30t1ADmNdftrp4l7Wdte

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.10 (Debian 16.10-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Achievement; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Achievement" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    achievement_id text NOT NULL,
    achievement_name text NOT NULL,
    description text NOT NULL,
    icon text,
    unlocked_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Achievement" OWNER TO seethbot;

--
-- Name: Achievement_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."Achievement_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Achievement_id_seq" OWNER TO seethbot;

--
-- Name: Achievement_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."Achievement_id_seq" OWNED BY public."Achievement".id;


--
-- Name: Activity; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Activity" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    user_name text,
    user_avatar text,
    activity_type text NOT NULL,
    description text NOT NULL,
    metadata text,
    points_change integer DEFAULT 0 NOT NULL,
    game_type text,
    recorded_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Activity" OWNER TO seethbot;

--
-- Name: Activity_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."Activity_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Activity_id_seq" OWNER TO seethbot;

--
-- Name: Activity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."Activity_id_seq" OWNED BY public."Activity".id;


--
-- Name: Character; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Character" (
    id integer NOT NULL,
    name text NOT NULL,
    image_url text,
    elo_rating integer DEFAULT 1200 NOT NULL,
    wins integer DEFAULT 0 NOT NULL,
    losses integer DEFAULT 0 NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Character" OWNER TO seethbot;

--
-- Name: CharacterMatch; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."CharacterMatch" (
    id integer NOT NULL,
    character_id integer NOT NULL,
    opponent_id integer NOT NULL,
    winner_id integer NOT NULL,
    voter_id integer NOT NULL,
    voted_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."CharacterMatch" OWNER TO seethbot;

--
-- Name: CharacterMatch_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."CharacterMatch_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."CharacterMatch_id_seq" OWNER TO seethbot;

--
-- Name: CharacterMatch_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."CharacterMatch_id_seq" OWNED BY public."CharacterMatch".id;


--
-- Name: Character_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."Character_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Character_id_seq" OWNER TO seethbot;

--
-- Name: Character_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."Character_id_seq" OWNED BY public."Character".id;


--
-- Name: Click; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Click" (
    id integer NOT NULL,
    count integer DEFAULT 0 NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Click" OWNER TO seethbot;

--
-- Name: Click_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."Click_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Click_id_seq" OWNER TO seethbot;

--
-- Name: Click_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."Click_id_seq" OWNED BY public."Click".id;


--
-- Name: Conversation; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Conversation" (
    id integer NOT NULL,
    type text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Conversation" OWNER TO seethbot;

--
-- Name: ConversationParticipant; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."ConversationParticipant" (
    id integer NOT NULL,
    conversation_id integer NOT NULL,
    user_id integer NOT NULL,
    joined_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_read_at timestamp(3) without time zone
);


ALTER TABLE public."ConversationParticipant" OWNER TO seethbot;

--
-- Name: ConversationParticipant_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."ConversationParticipant_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ConversationParticipant_id_seq" OWNER TO seethbot;

--
-- Name: ConversationParticipant_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."ConversationParticipant_id_seq" OWNED BY public."ConversationParticipant".id;


--
-- Name: Conversation_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."Conversation_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Conversation_id_seq" OWNER TO seethbot;

--
-- Name: Conversation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."Conversation_id_seq" OWNED BY public."Conversation".id;


--
-- Name: DailyChallenge; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."DailyChallenge" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    challenge_type text NOT NULL,
    description text NOT NULL,
    target_value integer NOT NULL,
    current_value integer DEFAULT 0 NOT NULL,
    progress double precision DEFAULT 0 NOT NULL,
    completed boolean DEFAULT false NOT NULL,
    date text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    completed_at timestamp(3) without time zone
);


ALTER TABLE public."DailyChallenge" OWNER TO seethbot;

--
-- Name: DailyChallenge_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."DailyChallenge_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."DailyChallenge_id_seq" OWNER TO seethbot;

--
-- Name: DailyChallenge_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."DailyChallenge_id_seq" OWNED BY public."DailyChallenge".id;


--
-- Name: FartEvent; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."FartEvent" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    volume double precision NOT NULL,
    bass_gain double precision,
    bass_frequency double precision,
    distortion_amount double precision,
    volume_multiplier double precision,
    playback_rate double precision,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    user_agent text,
    ip_address text
);


ALTER TABLE public."FartEvent" OWNER TO seethbot;

--
-- Name: FartEvent_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."FartEvent_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."FartEvent_id_seq" OWNER TO seethbot;

--
-- Name: FartEvent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."FartEvent_id_seq" OWNED BY public."FartEvent".id;


--
-- Name: Favorite; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Favorite" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    item_type text NOT NULL,
    item_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    display_name text,
    order_index integer DEFAULT 0 NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Favorite" OWNER TO seethbot;

--
-- Name: Favorite_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."Favorite_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Favorite_id_seq" OWNER TO seethbot;

--
-- Name: Favorite_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."Favorite_id_seq" OWNED BY public."Favorite".id;


--
-- Name: GameStat; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."GameStat" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    game_type text NOT NULL,
    stat_type text NOT NULL,
    value double precision NOT NULL,
    metadata text,
    recorded_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."GameStat" OWNER TO seethbot;

--
-- Name: GameStat_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."GameStat_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."GameStat_id_seq" OWNER TO seethbot;

--
-- Name: GameStat_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."GameStat_id_seq" OWNED BY public."GameStat".id;


--
-- Name: HighScore; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."HighScore" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    user_name text,
    game_type text NOT NULL,
    score integer NOT NULL,
    details text,
    recorded_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."HighScore" OWNER TO seethbot;

--
-- Name: HighScore_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."HighScore_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."HighScore_id_seq" OWNER TO seethbot;

--
-- Name: HighScore_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."HighScore_id_seq" OWNED BY public."HighScore".id;


--
-- Name: Message; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Message" (
    id integer NOT NULL,
    conversation_id integer NOT NULL,
    sender_id integer NOT NULL,
    content text NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Message" OWNER TO seethbot;

--
-- Name: Message_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."Message_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Message_id_seq" OWNER TO seethbot;

--
-- Name: Message_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."Message_id_seq" OWNED BY public."Message".id;


--
-- Name: ProcessingStats; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."ProcessingStats" (
    id integer NOT NULL,
    date text NOT NULL,
    total_processed integer DEFAULT 0 NOT NULL,
    simple_playbacks integer DEFAULT 0 NOT NULL,
    processed_playbacks integer DEFAULT 0 NOT NULL,
    avg_bass_gain double precision DEFAULT 0.0 NOT NULL,
    avg_distortion double precision DEFAULT 0.0 NOT NULL,
    avg_volume_multiplier double precision DEFAULT 0.0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ProcessingStats" OWNER TO seethbot;

--
-- Name: ProcessingStats_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."ProcessingStats_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ProcessingStats_id_seq" OWNER TO seethbot;

--
-- Name: ProcessingStats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."ProcessingStats_id_seq" OWNED BY public."ProcessingStats".id;


--
-- Name: Profile; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Profile" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    theme_preferences text,
    custom_colors text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    avatar_url text,
    bio text,
    display_name text,
    is_public boolean DEFAULT true NOT NULL,
    location text,
    profile_banner_url text,
    social_links text,
    status_message text,
    website text
);


ALTER TABLE public."Profile" OWNER TO seethbot;

--
-- Name: Profile_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."Profile_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Profile_id_seq" OWNER TO seethbot;

--
-- Name: Profile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."Profile_id_seq" OWNED BY public."Profile".id;


--
-- Name: PurchasedItem; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."PurchasedItem" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    item_id integer NOT NULL,
    purchased_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."PurchasedItem" OWNER TO seethbot;

--
-- Name: PurchasedItem_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."PurchasedItem_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."PurchasedItem_id_seq" OWNER TO seethbot;

--
-- Name: PurchasedItem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."PurchasedItem_id_seq" OWNED BY public."PurchasedItem".id;


--
-- Name: Reaction; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Reaction" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    target_type text NOT NULL,
    target_id text NOT NULL,
    emoji text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Reaction" OWNER TO seethbot;

--
-- Name: Reaction_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."Reaction_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Reaction_id_seq" OWNER TO seethbot;

--
-- Name: Reaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."Reaction_id_seq" OWNED BY public."Reaction".id;


--
-- Name: Session; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Session" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    device_name text,
    device_type text,
    token text NOT NULL,
    expires_at timestamp(3) without time zone NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_used_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Session" OWNER TO seethbot;

--
-- Name: Session_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."Session_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Session_id_seq" OWNER TO seethbot;

--
-- Name: Session_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."Session_id_seq" OWNED BY public."Session".id;


--
-- Name: Setting; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Setting" (
    key text NOT NULL,
    value text NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Setting" OWNER TO seethbot;

--
-- Name: ShopItem; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."ShopItem" (
    id integer NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    price integer NOT NULL,
    category text NOT NULL,
    image_url text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    effect text,
    icon text
);


ALTER TABLE public."ShopItem" OWNER TO seethbot;

--
-- Name: ShopItem_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."ShopItem_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ShopItem_id_seq" OWNER TO seethbot;

--
-- Name: ShopItem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."ShopItem_id_seq" OWNED BY public."ShopItem".id;


--
-- Name: Stock; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Stock" (
    name text NOT NULL,
    avatar text NOT NULL,
    price integer NOT NULL,
    coolness_score integer NOT NULL,
    shares integer NOT NULL,
    min_price integer NOT NULL,
    max_price integer NOT NULL,
    price_history text NOT NULL
);


ALTER TABLE public."Stock" OWNER TO seethbot;

--
-- Name: SyncLog; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."SyncLog" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    device_id text NOT NULL,
    sync_type text NOT NULL,
    status text NOT NULL,
    items_synced integer DEFAULT 0 NOT NULL,
    conflicts_found integer DEFAULT 0 NOT NULL,
    conflicts_resolved integer DEFAULT 0 NOT NULL,
    error_message text,
    started_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    completed_at timestamp(3) without time zone
);


ALTER TABLE public."SyncLog" OWNER TO seethbot;

--
-- Name: SyncLog_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."SyncLog_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."SyncLog_id_seq" OWNER TO seethbot;

--
-- Name: SyncLog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."SyncLog_id_seq" OWNED BY public."SyncLog".id;


--
-- Name: Theme; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Theme" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    preset text DEFAULT 'default'::text NOT NULL,
    custom_colors text,
    dark_mode boolean DEFAULT true NOT NULL,
    high_contrast boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Theme" OWNER TO seethbot;

--
-- Name: Theme_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."Theme_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Theme_id_seq" OWNER TO seethbot;

--
-- Name: Theme_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."Theme_id_seq" OWNED BY public."Theme".id;


--
-- Name: Ticket; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Ticket" (
    id integer NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    response text,
    creator_id text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    type text DEFAULT 'feature'::text NOT NULL,
    priority text DEFAULT 'medium'::text NOT NULL,
    tags text,
    category text,
    dependencies text,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE public."Ticket" OWNER TO seethbot;

--
-- Name: Ticket_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."Ticket_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Ticket_id_seq" OWNER TO seethbot;

--
-- Name: Ticket_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."Ticket_id_seq" OWNED BY public."Ticket".id;


--
-- Name: User; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."User" (
    id integer NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    display_name text,
    avatar_url text,
    banner_url text,
    bio text,
    status text,
    show_email integer DEFAULT 1 NOT NULL,
    show_joined_date integer DEFAULT 1 NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    discord_id text,
    discord_username text,
    discord_discriminator text,
    discord_avatar text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."User" OWNER TO seethbot;

--
-- Name: UserDevice; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."UserDevice" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    device_id text NOT NULL,
    device_name text,
    device_type text,
    platform text,
    last_sync timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."UserDevice" OWNER TO seethbot;

--
-- Name: UserDevice_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."UserDevice_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."UserDevice_id_seq" OWNER TO seethbot;

--
-- Name: UserDevice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."UserDevice_id_seq" OWNED BY public."UserDevice".id;


--
-- Name: UserFartStats; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."UserFartStats" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    total_farts integer DEFAULT 0 NOT NULL,
    total_volume double precision DEFAULT 0.0 NOT NULL,
    avg_volume double precision DEFAULT 0.0 NOT NULL,
    max_volume double precision DEFAULT 0.0 NOT NULL,
    min_volume double precision DEFAULT 0.0 NOT NULL,
    first_fart timestamp(3) without time zone,
    last_fart timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."UserFartStats" OWNER TO seethbot;

--
-- Name: UserFartStats_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."UserFartStats_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."UserFartStats_id_seq" OWNER TO seethbot;

--
-- Name: UserFartStats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."UserFartStats_id_seq" OWNED BY public."UserFartStats".id;


--
-- Name: UserPortfolio; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."UserPortfolio" (
    user_id integer NOT NULL,
    cash integer DEFAULT 10000 NOT NULL,
    holdings text DEFAULT '{}'::text NOT NULL,
    transactions text DEFAULT '[]'::text NOT NULL
);


ALTER TABLE public."UserPortfolio" OWNER TO seethbot;

--
-- Name: User_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."User_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."User_id_seq" OWNER TO seethbot;

--
-- Name: User_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."User_id_seq" OWNED BY public."User".id;


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO seethbot;

--
-- Name: Achievement id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Achievement" ALTER COLUMN id SET DEFAULT nextval('public."Achievement_id_seq"'::regclass);


--
-- Name: Activity id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Activity" ALTER COLUMN id SET DEFAULT nextval('public."Activity_id_seq"'::regclass);


--
-- Name: Character id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Character" ALTER COLUMN id SET DEFAULT nextval('public."Character_id_seq"'::regclass);


--
-- Name: CharacterMatch id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."CharacterMatch" ALTER COLUMN id SET DEFAULT nextval('public."CharacterMatch_id_seq"'::regclass);


--
-- Name: Click id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Click" ALTER COLUMN id SET DEFAULT nextval('public."Click_id_seq"'::regclass);


--
-- Name: Conversation id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Conversation" ALTER COLUMN id SET DEFAULT nextval('public."Conversation_id_seq"'::regclass);


--
-- Name: ConversationParticipant id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."ConversationParticipant" ALTER COLUMN id SET DEFAULT nextval('public."ConversationParticipant_id_seq"'::regclass);


--
-- Name: DailyChallenge id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."DailyChallenge" ALTER COLUMN id SET DEFAULT nextval('public."DailyChallenge_id_seq"'::regclass);


--
-- Name: FartEvent id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."FartEvent" ALTER COLUMN id SET DEFAULT nextval('public."FartEvent_id_seq"'::regclass);


--
-- Name: Favorite id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Favorite" ALTER COLUMN id SET DEFAULT nextval('public."Favorite_id_seq"'::regclass);


--
-- Name: GameStat id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."GameStat" ALTER COLUMN id SET DEFAULT nextval('public."GameStat_id_seq"'::regclass);


--
-- Name: HighScore id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."HighScore" ALTER COLUMN id SET DEFAULT nextval('public."HighScore_id_seq"'::regclass);


--
-- Name: Message id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Message" ALTER COLUMN id SET DEFAULT nextval('public."Message_id_seq"'::regclass);


--
-- Name: ProcessingStats id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."ProcessingStats" ALTER COLUMN id SET DEFAULT nextval('public."ProcessingStats_id_seq"'::regclass);


--
-- Name: Profile id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Profile" ALTER COLUMN id SET DEFAULT nextval('public."Profile_id_seq"'::regclass);


--
-- Name: PurchasedItem id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."PurchasedItem" ALTER COLUMN id SET DEFAULT nextval('public."PurchasedItem_id_seq"'::regclass);


--
-- Name: Reaction id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Reaction" ALTER COLUMN id SET DEFAULT nextval('public."Reaction_id_seq"'::regclass);


--
-- Name: Session id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Session" ALTER COLUMN id SET DEFAULT nextval('public."Session_id_seq"'::regclass);


--
-- Name: ShopItem id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."ShopItem" ALTER COLUMN id SET DEFAULT nextval('public."ShopItem_id_seq"'::regclass);


--
-- Name: SyncLog id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."SyncLog" ALTER COLUMN id SET DEFAULT nextval('public."SyncLog_id_seq"'::regclass);


--
-- Name: Theme id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Theme" ALTER COLUMN id SET DEFAULT nextval('public."Theme_id_seq"'::regclass);


--
-- Name: Ticket id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Ticket" ALTER COLUMN id SET DEFAULT nextval('public."Ticket_id_seq"'::regclass);


--
-- Name: User id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."User" ALTER COLUMN id SET DEFAULT nextval('public."User_id_seq"'::regclass);


--
-- Name: UserDevice id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."UserDevice" ALTER COLUMN id SET DEFAULT nextval('public."UserDevice_id_seq"'::regclass);


--
-- Name: UserFartStats id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."UserFartStats" ALTER COLUMN id SET DEFAULT nextval('public."UserFartStats_id_seq"'::regclass);


--
-- Data for Name: Achievement; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Achievement" (id, user_id, achievement_id, achievement_name, description, icon, unlocked_at) FROM stdin;
\.


--
-- Data for Name: Activity; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Activity" (id, user_id, user_name, user_avatar, activity_type, description, metadata, points_change, game_type, recorded_at) FROM stdin;
\.


--
-- Data for Name: Character; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Character" (id, name, image_url, elo_rating, wins, losses, is_deleted, created_at, updated_at) FROM stdin;
2	Snouse and Mail	https://64.media.tumblr.com/54f100369945372c88d7dcd03a9a5825/57e2862b5e7186d9-24/s540x810/1c864ff3f33076224fa1a9499c0146b973588170.jpg	1154	3	6	f	2026-02-04 17:57:01	2026-02-09 10:39:46
4	Video Kojima	https://64.media.tumblr.com/f3fb1509753ce3766012363ef45694c2/7db86ffa66eba893-ce/s540x810/73f8d734cd1d5841891044bc85a6575401c850b2.jpg	1158	4	8	f	2026-02-04 17:58:35	2026-02-10 06:11:24
5	Lying down Miku	https://64.media.tumblr.com/248c337c9a79c944faa1cb222f221e3e/3b0374c89329798b-89/s540x810/d9395dbf1fd127bbbb823b5330f4e915d2e02de5.pnj	1189	1	2	f	2026-02-04 17:59:34	2026-02-06 14:15:56
6	Nurse Joy	https://x.com/i/status/1940083994168893687	1251	5	1	f	2026-02-04 18:01:29	2026-02-06 14:15:03
7	Spider Chair	https://pbs.twimg.com/media/HAPxZiFaEAAvMiL?format=jpg&name=medium	1209	4	3	f	2026-02-04 18:03:02	2026-02-06 14:15:37
8	Bluesky Account Suspension	https://pbs.twimg.com/media/HAUs_ifboAA0Plr?format=jpg&name=medium	1126	1	6	f	2026-02-04 18:03:26	2026-02-06 14:15:30
9	No Sleeper	https://pbs.twimg.com/media/HARvOApb0AA221p?format=png&name=small	1199	2	2	f	2026-02-04 18:06:05	2026-02-05 23:30:24
10	Dinner for One	https://pbs.twimg.com/media/HAUFp_DawAAUiwk?format=jpg&name=small	1259	4	0	f	2026-02-04 18:08:09	2026-02-05 04:39:43
11	Dark Uni	https://pbs.twimg.com/media/HAUUdaZbkAAxaB_?format=jpg&name=small	1276	7	1	f	2026-02-04 18:08:25	2026-02-09 10:39:46
12	Adobe Animate	\N	1113	1	7	f	2026-02-04 18:08:54	2026-02-05 05:23:45
13	Adobe Animate (With Picture)	https://pbs.twimg.com/media/HALUUJWWMAAizLr?format=png&name=small	1172	3	5	f	2026-02-04 18:09:05	2026-02-10 09:37:32
14	Queensland Police Service	https://pbs.twimg.com/media/HASr0IibMAA_1-6?format=jpg&name=small	1088	0	8	f	2026-02-04 18:09:23	2026-02-06 02:23:59
15	Jellyfish Utensil Holder	https://pbs.twimg.com/media/HAP5UtbbMAADvqP?format=jpg&name=medium	1245	4	1	f	2026-02-04 18:09:54	2026-02-06 11:51:33
16	Mar10 Milk	https://pbs.twimg.com/media/HAN1lTBbcAAg3se?format=jpg&name=large	1176	4	5	f	2026-02-04 18:11:10	2026-02-06 14:16:10
17	Tumblr Poll Cake	https://64.media.tumblr.com/d555346393e8c2ea55da646a53db82a2/1561f50b9cbf8599-e6/s540x810/8047745de8917e434a5babc2346bfc4cbb733103.pnj	1099	0	7	f	2026-02-04 18:14:37	2026-02-10 06:11:24
18	David Lynch	https://64.media.tumblr.com/7a3b60a0b1ff3daf24c8a16207beb901/82eaced35c0e6dc5-cb/s540x810/a501413f67ec64d2d56fb83d0d43275caa895ce0.jpg	1322	9	0	f	2026-02-04 18:18:52	2026-02-05 23:30:42
19	Markiplier	https://64.media.tumblr.com/bea562bda37afe0fca2d19663cb82068/9cb7467eb20e3588-57/s400x600/5a4b3d56be0cf927eaefbefcbe36a313e6c67fee.gifv	1247	7	3	f	2026-02-04 18:19:45	2026-02-09 10:39:51
20	Watermelon	https://64.media.tumblr.com/017cd22c89b7b4f0ad325aa1d9cb8fc2/4017da0d095ef769-9e/s400x600/d5f2151405bb1afa5698b8efb83623b40dce7e97.jpg	1273	6	1	f	2026-02-04 18:21:18	2026-02-05 23:30:28
21	Tennis Ball	https://64.media.tumblr.com/e47673c57712cffb4e0bc15f515063b3/1e93aa5ae9766c62-17/s400x600/206a26c46fc703ba24287c3b4a8e03bd81bc4c7f.jpg	1270	7	2	f	2026-02-04 18:22:02	2026-02-10 09:37:32
22	Never Kill Yourself	https://64.media.tumblr.com/f5b9d6b3b2605aaafd63370ba0d26dd0/5db31de0dd99240e-cf/s400x600/2a7c94a33df3f45b073f061aa354da5e638ec06b.gif	1216	1	0	f	2026-02-04 18:25:28	2026-02-06 11:50:33
23	Orlando if he had an average or even a small ween	https://media.istockphoto.com/id/1434185664/vector/lying-man-with-a-long-nose-pinocchio.jpg?s=612x612&w=0&k=20&c=zzIOrozwM89eCN11S_lWeBpJIEaN8hvywhXAmU2U2jg=	1111	0	6	f	2026-02-04 18:25:41	2026-02-06 11:51:00
24	Thousand Layer Apple Cake	https://va.media.tumblr.com/tumblr_t8lpmaWk6D1zg326b.mp4	1200	1	1	f	2026-02-04 18:27:28	2026-02-06 11:51:33
25	Giorgia Meloni Angel	https://cdn.i-scmp.com/sites/default/files/styles/1020x680/public/d8/images/canvas/2026/02/01/14bf244e-801b-4300-9837-20172ff3fb35_44db174a.jpg?itok=GSjpisR7&v=1769881806	1173	1	3	f	2026-02-04 18:27:46	2026-02-05 04:41:05
26	Toyota Fun Cargo Concept	https://64.media.tumblr.com/3a8ee0ddca17b83d76f11239961fd0eb/522475107bada3e0-16/s540x810/7c15b983058d70b4f6a539a5e7447d73cb9c94cc.jpg	1174	2	4	f	2026-02-04 18:29:56	2026-02-06 11:51:08
28	AI generated Product Names	https://64.media.tumblr.com/b66fe448dbd7a32006b5eb608c7d758c/7c01374d31631942-69/s1280x1920/729623371c6da38b83165981b63922799558134e.jpg	1174	1	3	f	2026-02-04 18:33:42	2026-02-06 14:15:23
29	MS Paint dog	https://preview.redd.it/tomodachi-life-living-the-dream-is-the-true-drawn-to-life-v0-7f97merb5dgg1.png?width=640&crop=smart&auto=webp&s=95cd092d6117a1958e828daf666482133ca09107	1183	2	3	f	2026-02-04 18:35:17	2026-02-05 05:23:40
30	Baby Thumbnails	https://64.media.tumblr.com/fe8d013afff4711d04f8adaa8365d011/3a82e4a93e29b5a1-36/s540x810/0a451f289f4eb3435907e1e95b97333b4d0aa514.pnj	1130	0	5	f	2026-02-04 18:35:28	2026-02-09 10:40:19
31	That girl that nobody wants to date from TL:LTD	https://sm.ign.com/t/ign_pt/video/t/tomodachi-/tomodachi-life-living-the-dream-direct-get-an-extended-gamep_qd75.1200.jpg	1234	4	2	f	2026-02-04 18:35:49	2026-02-07 09:10:43
32	七里ヶ浜駅-稲村ヶ崎駅間	https://64.media.tumblr.com/74ca414768db767b4601d2194b581c99/d0e4e7e03aebe7b7-a8/s540x810/6b8c4b9c75e0923fa48611c15db721efb11b1921.jpg	1155	0	3	f	2026-02-04 18:36:03	2026-02-05 21:08:20
34	Static Cling	https://64.media.tumblr.com/1bccb535ab27577426fd7f202d5b89d0/6b916191d2ed8484-76/s500x750/c1fe6e3a215b0e65aad9ac70652eedbdb71bd6cf.png	1201	1	1	f	2026-02-04 18:38:22	2026-02-07 09:10:32
35	Static Electricity	https://64.media.tumblr.com/1bccb535ab27577426fd7f202d5b89d0/6b916191d2ed8484-76/s500x750/c1fe6e3a215b0e65aad9ac70652eedbdb71bd6cf.png	1196	1	1	f	2026-02-04 18:38:33	2026-02-06 14:16:01
37	Electric Field	https://64.media.tumblr.com/1bccb535ab27577426fd7f202d5b89d0/6b916191d2ed8484-76/s500x750/c1fe6e3a215b0e65aad9ac70652eedbdb71bd6cf.png	1230	2	0	f	2026-02-04 18:38:59	2026-02-05 04:40:56
38	Electrostatics	https://64.media.tumblr.com/1bccb535ab27577426fd7f202d5b89d0/6b916191d2ed8484-76/s500x750/c1fe6e3a215b0e65aad9ac70652eedbdb71bd6cf.png	1249	3	0	f	2026-02-04 18:39:09	2026-02-09 10:39:51
39	Minecraft Civil Rights DLC	https://64.media.tumblr.com/5783d15fb011944c73bae25d89abbf69/a428cd1c18710989-4a/s540x810/ee72ffd16c7ba03c01ebe6ceb123badcd4034823.pnj	1184	2	3	f	2026-02-04 18:40:08	2026-02-06 14:16:01
40	panamaha parapara baabapapabarabara party	https://i.ytimg.com/vi/eCjfSDz4eRo/hqdefault.jpg?sqp=-oaymwEcCPYBEIoBSFXyq4qpAw4IARUAAIhCGAFwAcABBg==&rs=AOn4CLCcyyESQBQrihJrL-4qesMhDs1vgQ	1217	1	0	f	2026-02-05 04:44:23	2026-02-06 11:50:39
36	Triboelectric Effect	https://64.media.tumblr.com/1bccb535ab27577426fd7f202d5b89d0/6b916191d2ed8484-76/s500x750/c1fe6e3a215b0e65aad9ac70652eedbdb71bd6cf.png	1230	3	1	f	2026-02-04 18:38:50	2026-02-19 12:46:03.816
1	Snail and Mouse	https://64.media.tumblr.com/15ac9d233e78612262354e70f6b1c601/c9d326f499eff987-e9/s540x810/2d861b9525909e058b744ec2c2458ac5d85f753a.jpg	1235	13	12	f	2026-02-04 17:56:45	2026-02-19 12:46:03.816
41	Dragon Hunter	https://64.media.tumblr.com/7800f005e4dace4814516f5d2c1686b9/ccc0ff7f164376b6-9e/s540x810/ad68b79671913e8c9ee92489895e2fcd658be53a.jpg	1170	0	2	f	2026-02-05 05:22:11	2026-02-06 14:15:47
42	Dragon Hunter	https://64.media.tumblr.com/7800f005e4dace4814516f5d2c1686b9/ccc0ff7f164376b6-9e/s540x810/ad68b79671913e8c9ee92489895e2fcd658be53a.jpg	1222	3	1	f	2026-02-05 05:22:11	2026-02-06 14:16:20
43	Darkiplier	https://64.media.tumblr.com/645ed4744c2d9021f07a310fd91da911/tumblr_inline_ok2mgkqVEP1r3dph6_400.gif	1186	0	1	f	2026-02-05 05:29:13	2026-02-06 14:15:03
44	Darkiplier	https://64.media.tumblr.com/645ed4744c2d9021f07a310fd91da911/tumblr_inline_ok2mgkqVEP1r3dph6_400.gif	1182	0	1	f	2026-02-05 05:29:13	2026-02-06 14:15:23
45	Now Where Were We?	https://64.media.tumblr.com/0cb7e233c9f04dd349322c640ea96b3c/9da2ef120c1fc598-ed/s540x810/ddfe4d954eae6d672eaea0a34811342b47916720.jpg	1259	4	0	f	2026-02-05 05:44:10	2026-02-09 10:40:19
46	Now Where Were We?	https://64.media.tumblr.com/0cb7e233c9f04dd349322c640ea96b3c/9da2ef120c1fc598-ed/s540x810/ddfe4d954eae6d672eaea0a34811342b47916720.jpg	1233	2	0	f	2026-02-05 05:44:10	2026-02-06 14:15:14
47	Joe Biden	https://64.media.tumblr.com/217d8cdbdc04a4e7def5bc58e05f1139/5ddfde35e01979ae-fe/s250x400/339db9eccabf6f8fd82d2e6818c2cc1ac83cf7c4.gif	1186	1	2	f	2026-02-05 06:14:15	2026-02-06 02:23:59
48	Joe Biden	https://64.media.tumblr.com/217d8cdbdc04a4e7def5bc58e05f1139/5ddfde35e01979ae-fe/s250x400/339db9eccabf6f8fd82d2e6818c2cc1ac83cf7c4.gif	1177	0	2	f	2026-02-05 06:14:15	2026-02-05 23:30:42
27	Incredible Suggestion	https://64.media.tumblr.com/bbf2158701130540d51bbae3ac6ce2fc/b0489b1f87fed304-0b/s540x810/41131af2bba871425956bad209b36c2619af1412.pnj	1245	5	2	f	2026-02-04 18:30:34	2026-02-19 12:45:26.031
3	Survivorship Bias	https://64.media.tumblr.com/2586866394b278c4e6b523ec5c2c6ef8/25bc6c1cc1dc7948-13/s540x810/0ee2cce2e0170435635ec6f20b9f2cf4d490e093.jpg	1222	7	5	f	2026-02-04 17:58:15	2026-02-19 12:45:26.032
\.


--
-- Data for Name: CharacterMatch; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."CharacterMatch" (id, character_id, opponent_id, winner_id, voter_id, voted_at) FROM stdin;
\.


--
-- Data for Name: Click; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Click" (id, count, updated_at) FROM stdin;
1	65	2026-02-13 14:31:29.991
\.


--
-- Data for Name: Conversation; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Conversation" (id, type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ConversationParticipant; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."ConversationParticipant" (id, conversation_id, user_id, joined_at, last_read_at) FROM stdin;
\.


--
-- Data for Name: DailyChallenge; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."DailyChallenge" (id, user_id, challenge_type, description, target_value, current_value, progress, completed, date, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: FartEvent; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."FartEvent" (id, user_id, volume, bass_gain, bass_frequency, distortion_amount, volume_multiplier, playback_rate, "timestamp", user_agent, ip_address) FROM stdin;
\.


--
-- Data for Name: Favorite; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Favorite" (id, user_id, item_type, item_id, created_at, display_name, order_index, updated_at) FROM stdin;
\.


--
-- Data for Name: GameStat; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."GameStat" (id, user_id, game_type, stat_type, value, metadata, recorded_at) FROM stdin;
\.


--
-- Data for Name: HighScore; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."HighScore" (id, user_id, user_name, game_type, score, details, recorded_at, updated_at) FROM stdin;
\.


--
-- Data for Name: Message; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Message" (id, conversation_id, sender_id, content, is_deleted, created_at) FROM stdin;
\.


--
-- Data for Name: ProcessingStats; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."ProcessingStats" (id, date, total_processed, simple_playbacks, processed_playbacks, avg_bass_gain, avg_distortion, avg_volume_multiplier, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: Profile; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Profile" (id, user_id, theme_preferences, custom_colors, created_at, updated_at, avatar_url, bio, display_name, is_public, location, profile_banner_url, social_links, status_message, website) FROM stdin;
\.


--
-- Data for Name: PurchasedItem; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."PurchasedItem" (id, user_id, item_id, purchased_at) FROM stdin;
\.


--
-- Data for Name: Reaction; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Reaction" (id, user_id, target_type, target_id, emoji, created_at) FROM stdin;
\.


--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Session" (id, user_id, device_name, device_type, token, expires_at, created_at, last_used_at) FROM stdin;
3	2	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIsInRzIjoxNzcwOTkzMTQxODQ5LCJpYXQiOjE3NzA5OTMxNDEsImV4cCI6MTc3MzU4NTE0MX0.eFCMTFc3b04IeExsiTH772f63yh8YAq6czUy1bxoHqc	2026-03-15 14:32:21.85	2026-02-13 14:32:21.852	2026-02-13 14:32:21.852
4	2	Chrome on Windows	desktop	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIsInRzIjoxNzcwOTkzMTQ2Mzg2LCJpYXQiOjE3NzA5OTMxNDYsImV4cCI6MTc3MzU4NTE0Nn0.Ccb96EiXgxk5ZMbxfBtTpq6qGv_rbyeIay4DZ0DOXcU	2026-03-15 15:07:22.736	2026-02-13 14:32:26.387	2026-02-13 15:07:22.736
6	1	Firefox on Windows	desktop	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsInRzIjoxNzcxMzAzNDU2MTUxLCJpYXQiOjE3NzEzMDM0NTYsImV4cCI6MTc3Mzg5NTQ1Nn0.pzWW2r7c37iWmUS0rn9qp7oAfLE5I10uwcsZTSm40r0	2026-03-19 06:34:45.355	2026-02-17 04:44:16.17	2026-02-17 06:34:45.355
2	1	Chrome on macOS	desktop	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsInRzIjoxNzcwOTkyMDYyNzEzLCJpYXQiOjE3NzA5OTIwNjIsImV4cCI6MTc3MzU4NDA2Mn0.X1apJvmuBKsyMh-PTRrtfh3IuCCzks8OwyAsl1t9RXk	2026-03-17 08:32:17.863	2026-02-13 14:14:22.714	2026-02-15 08:32:17.863
5	1	Firefox on Linux	desktop	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsInRzIjoxNzcxMTUzNDcwMzg1LCJpYXQiOjE3NzExNTM0NzAsImV4cCI6MTc3Mzc0NTQ3MH0.OqOSlNqRF45EpGWUs3rW1w9_MF4bcOOMk-sEyT-sJLM	2026-03-20 10:46:35.889	2026-02-15 11:04:30.394	2026-02-18 10:46:35.889
1	1	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsInRzIjoxNzcwOTkxODEzOTg5LCJpYXQiOjE3NzA5OTE4MTMsImV4cCI6MTc3MzU4MzgxM30.QhHoury0GnYw4YZbCog1ozgUWfVDW02nf6C7MQmipmw	2026-03-23 07:59:54.318	2026-02-13 14:10:13.997	2026-02-21 07:59:54.318
\.


--
-- Data for Name: Setting; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Setting" (key, value, updated_at) FROM stdin;
\.


--
-- Data for Name: ShopItem; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."ShopItem" (id, name, description, price, category, image_url, is_active, created_at, updated_at, effect, icon) FROM stdin;
1	Double Click Power	Your clicks are worth 2x points!	500	clicker	\N	t	2026-02-18 09:34:39.213	2026-02-18 09:34:39.213	clickPower:2	✌️
2	Auto-Clicker Boost	Auto-clicker generates +1 point/second	1000	clicker	\N	t	2026-02-18 09:34:39.213	2026-02-18 09:34:39.213	autoClickBoost:1	🤖
3	Custom Goose Emoji	Set a custom emoji for the digital goose	300	cosmetic	\N	t	2026-02-18 09:34:39.213	2026-02-18 09:34:39.213	customGoose	🦆
4	Neon Goose Effect	Add a glowing neon effect to the goose	250	cosmetic	\N	t	2026-02-18 09:34:39.213	2026-02-18 09:34:39.213	neonGoose	✨
5	Coolness Multiplier	All point gains multiplied by 1.5x	2000	premium	\N	t	2026-02-18 09:34:39.213	2026-02-18 09:34:39.213	multiplier:1.5	⭐
6	Instant Points Bundle	Get 100 points instantly	100	consumable	\N	t	2026-02-18 09:34:39.213	2026-02-18 09:34:39.213	instantPoints:100	💎
7	Golden Mushroom	Special mushroom skin for clicker	750	cosmetic	\N	t	2026-02-18 09:34:39.213	2026-02-18 09:34:39.213	goldenMushroom	🍄
8	Speed Upgrades	Auto-clicker generates +2 points/second	3000	clicker	\N	t	2026-02-18 09:34:39.213	2026-02-18 09:34:39.213	autoClickBoost:2	⚡
\.


--
-- Data for Name: Stock; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Stock" (name, avatar, price, coolness_score, shares, min_price, max_price, price_history) FROM stdin;
Cam	🥔	1000	10000	1000	500	5000	[{"timestamp":1770991720629,"price":1000},{"timestamp":1770991750629,"price":1000}]
Orlando	🌙	1007	10067	1000	504	5035	[{"timestamp":1770991720647,"price":1007},{"timestamp":1770991750647,"price":1007}]
Ashley	<:flooshies:1000736727259947069>	500	5000	1000	250	2500	[{"timestamp":1770991720652,"price":500},{"timestamp":1770991750652,"price":500}]
Average Hex	🌸	200	2000	1000	100	1000	[{"timestamp":1770991720656,"price":200},{"timestamp":1770991750656,"price":200}]
Temer3	🔧	180	1800	1000	90	900	[{"timestamp":1770991720660,"price":180},{"timestamp":1770991750660,"price":180}]
You	🌸	147	1467	1000	74	735	[{"timestamp":1770991720666,"price":147},{"timestamp":1770991750666,"price":147}]
美香	🏍️	2147	21467	1000	1074	10735	[{"timestamp":1770991720669,"price":2147},{"timestamp":1770991750669,"price":2147}]
Chang'Yi	<:sadcat:1000736705197907968>	137	1367	1000	69	685	[{"timestamp":1770991720671,"price":137},{"timestamp":1770991750671,"price":137}]
RIUM+	🎮	50	501	1000	25	250	[{"timestamp":1770991720675,"price":50},{"timestamp":1770991750675,"price":50}]
Goopsworthy	🍄	67	667	1000	34	335	[{"timestamp":1770991720679,"price":67},{"timestamp":1770991750679,"price":67}]
Blair	🎮	90	900	1000	45	450	[{"timestamp":1770991720681,"price":90},{"timestamp":1770991750681,"price":90}]
Others	✨	50	500	1000	25	250	[{"timestamp":1770991720685,"price":50},{"timestamp":1770991750685,"price":50}]
\.


--
-- Data for Name: SyncLog; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."SyncLog" (id, user_id, device_id, sync_type, status, items_synced, conflicts_found, conflicts_resolved, error_message, started_at, completed_at) FROM stdin;
1	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-17 07:41:38.049	2026-02-17 07:41:38.06
2	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 09:46:16.051	2026-02-18 09:46:16.063
3	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 09:51:16.287	2026-02-18 09:51:16.299
4	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 09:56:16.284	2026-02-18 09:56:16.289
5	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:01:16.282	2026-02-18 10:01:16.29
6	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:06:16.728	2026-02-18 10:06:16.736
7	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:11:17.315	2026-02-18 10:11:17.324
8	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:16:17.877	2026-02-18 10:16:17.887
9	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:21:18.581	2026-02-18 10:21:18.586
10	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:26:18.804	2026-02-18 10:26:18.815
11	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:31:19.305	2026-02-18 10:31:19.33
12	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:40:43.34	2026-02-18 10:40:43.353
13	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:46:37.729	2026-02-18 10:46:37.746
14	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:47:03.577	2026-02-18 10:47:03.583
15	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:47:04.275	2026-02-18 10:47:04.288
16	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:50:32.104	2026-02-18 10:50:32.111
17	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:50:36.613	2026-02-18 10:50:36.621
18	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-21 07:28:30.951	2026-02-21 07:28:30.96
19	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-21 07:33:30.844	2026-02-21 07:33:30.856
20	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-21 07:38:31.639	2026-02-21 07:38:31.656
21	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-21 07:50:29.237	2026-02-21 07:50:29.242
22	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-21 07:56:19.697	2026-02-21 07:56:19.707
\.


--
-- Data for Name: Theme; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Theme" (id, user_id, preset, custom_colors, dark_mode, high_contrast, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: Ticket; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Ticket" (id, title, description, status, response, creator_id, created_at, updated_at, type, priority, tags, category, dependencies, is_deleted) FROM stdin;
1	test	test	pending	\N	\N	2026-02-14 11:11:41.689	2026-02-14 11:11:41.689	feature	low	\N	\N	\N	t
2	Oled Mode	We have custom themes but no oled mode. Replace the sunset theme with Oled theme and use full blacks to reduce burn in.	completed	Replaced sunset theme with OLED theme using true blacks (#000000) for burn-in reduction	creator-1771212178779-gz8u15y	2026-02-16 03:25:07.959	2026-02-16 03:25:07.959	feature	medium	\N	\N	\N	f
3	Dark mode review	There are a bunch of components that dont listen to dark mode. please review all the vue models	completed	Reviewed and fixed dark mode support across Vue components. Updated 78 files to use CSS variables instead of hardcoded colors, and removed unnecessary dark mode overrides from 38 files. Components now properly respond to dark mode state changes via theme CSS variables (--theme-background, --theme-text, --theme-primary, --theme-secondary, --theme-accent, --theme-card-bg). All changes deployed.	creator-1771212178779-gz8u15y	2026-02-16 03:25:44.31	2026-02-16 03:25:44.31	feature	medium	\N	\N	\N	f
4	Nav Bar updates	The breadcrumbs could be integrated into the nav bar so it doesnt appear as a separate bunch of cards. this should make the design clearer	completed	Integrated breadcrumbs into the nav bar (Ticket #4)\n\nChanges made:\n- Modified Router.vue to include breadcrumb logic and display\n- Added Router-breadcrumb.css for integrated breadcrumb styling  \n- Removed separate Breadcrumb component from MainApp.vue\n- Breadcrumbs now display inline within the nav bar instead of as separate cards\n- Maintained all existing breadcrumb functionality (icons, separators, truncation)\n- Breadcrumbs are hidden on home page and in performance mode\n\nDeployment is in progress - the code changes are complete and the build is running.	creator-1771212178779-gz8u15y	2026-02-16 03:27:57.193	2026-02-16 03:27:57.193	feature	medium	\N	\N	\N	f
5	Remove all SQLite references	SQLite should be completely removed from the codebase. Remaining references to clean up:\n- scripts/migrate-sqlite-to-postgres.sh (can be archived/deleted)\n- scripts/archive/* directory contains sqlite-based scripts (consider deleting entire archive)\n\nAll main application code (server/src) no longer uses sqlite. Prisma schema uses postgres only. No sqlite dependencies in package.json.	completed	All SQLite features migrated to PostgreSQL. 9 files migrated (characters, shop, tickets, sync, search, reactions, farts, profiles, favorites). Added UserDevice and SyncLog models to Prisma schema. Removed better-sqlite3 dependencies. Cleanup done: scripts/archive-root/ removed. Build successful. Ready for testing.	mhear22	2026-02-16 22:40:12.249	2026-02-16 22:40:12.249	task	medium	\N	\N	\N	f
6	Add bow emoji button to navcontrols bar - plays sound on loop	User Orlando (bellicapelli) requested a button on the navcontrols bar that:\n\n- Plays the attached sound file on loop when clicked\n- Uses a bow emoji 🎀 as the icon\n\nThe sound file has been provided and should be added to the project.\n\nRequest from: Orlando in Discord\n\nAudio file saved to: frontend/public/audio/bow-button-sound.wav (401KB)	completed	Bow emoji button (🎀) has been added to the navcontrols bar. The button plays the bow-button-sound.wav file on loop when clicked, and can be toggled on/off. The audio file is in place, the button is properly wired to the useAudio composable's toggleBowSound function, and everything is working correctly. The feature includes proper ARIA labels, active state styling, and integrates seamlessly with the existing nav-controls bar.	discord	2026-02-18 10:15:09.316	2026-02-18 10:15:09.316	feature	maximum	\N	\N	\N	f
7	I18N translation	We have users who's primary language isnt english. Give people the ability to change the language to something else and have the whole site respect it. Start with English, Chinese, and Japanese.	completed	Implemented full I18N translation support with English, Chinese (Simplified), and Japanese. Created translation files, language selector components, and integrated vue-i18n. Language preference persists in localStorage and auto-detects browser locale. Build successful and ready for deployment.	creator-1771079368671-b1btyc3	2026-02-21 07:35:42.366	2026-02-21 07:35:42.366	feature	medium	\N	\N	\N	f
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."User" (id, email, password_hash, display_name, avatar_url, banner_url, bio, status, show_email, show_joined_date, is_deleted, discord_id, discord_username, discord_discriminator, discord_avatar, created_at, updated_at) FROM stdin;
1	test@test.com	$2b$10$843EyFSRVXV2FOqQK0EQS.zlou9yJdDYERa17MQ5HSxYYD3PJRmJS	test	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-02-13 14:10:13.985	2026-02-13 14:10:13.985
2	penguin@gmail.com	$2b$10$VEi1awP/za84sucXtzMDLuamGKKiq8FW1s/VEi.os/iSitBfw42/m	0riginal	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-02-13 14:32:21.838	2026-02-13 14:32:21.838
\.


--
-- Data for Name: UserDevice; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."UserDevice" (id, user_id, device_id, device_name, device_type, platform, last_sync, created_at, updated_at) FROM stdin;
1	1	device-1771153470412-j1elif1ye	Firefox	desktop	Linux	2026-02-18 10:50:36.617	2026-02-17 07:41:38.027	2026-02-18 10:50:36.617
2	1	device-1770991813972-a6ptnqrmx	Firefox	desktop	macOS	2026-02-21 07:56:19.702	2026-02-21 07:28:30.945	2026-02-21 07:56:19.702
\.


--
-- Data for Name: UserFartStats; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."UserFartStats" (id, user_id, total_farts, total_volume, avg_volume, max_volume, min_volume, first_fart, last_fart, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: UserPortfolio; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."UserPortfolio" (user_id, cash, holdings, transactions) FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
e3bbf79e-c337-423c-8b27-81b1b67d1c44	0e6ead4239ba1ad4f9a5dde403ea3f8155ec44ace7d5be20409b156070c95555	2026-02-13 14:09:10.033926+00	20260212144929_init	\N	\N	2026-02-13 14:09:09.505393+00	1
8c806edc-acc2-4a77-b269-0cb03facabf6	e9b3d9d647e80aef18137a9b37719e6e5400f2452ef206de3f6390df2fe8724e	2026-02-16 22:51:09.435198+00	20260216225109_add_sync_and_update_models	\N	\N	2026-02-16 22:51:09.364625+00	1
\.


--
-- Name: Achievement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."Achievement_id_seq"', 1, false);


--
-- Name: Activity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."Activity_id_seq"', 1, false);


--
-- Name: CharacterMatch_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."CharacterMatch_id_seq"', 2, true);


--
-- Name: Character_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."Character_id_seq"', 1, false);


--
-- Name: Click_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."Click_id_seq"', 1, true);


--
-- Name: ConversationParticipant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."ConversationParticipant_id_seq"', 1, false);


--
-- Name: Conversation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."Conversation_id_seq"', 1, false);


--
-- Name: DailyChallenge_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."DailyChallenge_id_seq"', 1, false);


--
-- Name: FartEvent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."FartEvent_id_seq"', 1, false);


--
-- Name: Favorite_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."Favorite_id_seq"', 1, false);


--
-- Name: GameStat_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."GameStat_id_seq"', 1, false);


--
-- Name: HighScore_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."HighScore_id_seq"', 1, false);


--
-- Name: Message_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."Message_id_seq"', 1, false);


--
-- Name: ProcessingStats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."ProcessingStats_id_seq"', 1, false);


--
-- Name: Profile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."Profile_id_seq"', 1, false);


--
-- Name: PurchasedItem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."PurchasedItem_id_seq"', 1, false);


--
-- Name: Reaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."Reaction_id_seq"', 1, false);


--
-- Name: Session_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."Session_id_seq"', 6, true);


--
-- Name: ShopItem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."ShopItem_id_seq"', 8, true);


--
-- Name: SyncLog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."SyncLog_id_seq"', 22, true);


--
-- Name: Theme_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."Theme_id_seq"', 1, false);


--
-- Name: Ticket_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."Ticket_id_seq"', 7, true);


--
-- Name: UserDevice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."UserDevice_id_seq"', 2, true);


--
-- Name: UserFartStats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."UserFartStats_id_seq"', 1, false);


--
-- Name: User_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."User_id_seq"', 2, true);


--
-- Name: Achievement Achievement_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Achievement"
    ADD CONSTRAINT "Achievement_pkey" PRIMARY KEY (id);


--
-- Name: Activity Activity_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Activity"
    ADD CONSTRAINT "Activity_pkey" PRIMARY KEY (id);


--
-- Name: CharacterMatch CharacterMatch_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."CharacterMatch"
    ADD CONSTRAINT "CharacterMatch_pkey" PRIMARY KEY (id);


--
-- Name: Character Character_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Character"
    ADD CONSTRAINT "Character_pkey" PRIMARY KEY (id);


--
-- Name: Click Click_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Click"
    ADD CONSTRAINT "Click_pkey" PRIMARY KEY (id);


--
-- Name: ConversationParticipant ConversationParticipant_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."ConversationParticipant"
    ADD CONSTRAINT "ConversationParticipant_pkey" PRIMARY KEY (id);


--
-- Name: Conversation Conversation_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Conversation"
    ADD CONSTRAINT "Conversation_pkey" PRIMARY KEY (id);


--
-- Name: DailyChallenge DailyChallenge_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."DailyChallenge"
    ADD CONSTRAINT "DailyChallenge_pkey" PRIMARY KEY (id);


--
-- Name: FartEvent FartEvent_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."FartEvent"
    ADD CONSTRAINT "FartEvent_pkey" PRIMARY KEY (id);


--
-- Name: Favorite Favorite_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Favorite"
    ADD CONSTRAINT "Favorite_pkey" PRIMARY KEY (id);


--
-- Name: GameStat GameStat_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."GameStat"
    ADD CONSTRAINT "GameStat_pkey" PRIMARY KEY (id);


--
-- Name: HighScore HighScore_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."HighScore"
    ADD CONSTRAINT "HighScore_pkey" PRIMARY KEY (id);


--
-- Name: Message Message_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_pkey" PRIMARY KEY (id);


--
-- Name: ProcessingStats ProcessingStats_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."ProcessingStats"
    ADD CONSTRAINT "ProcessingStats_pkey" PRIMARY KEY (id);


--
-- Name: Profile Profile_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Profile"
    ADD CONSTRAINT "Profile_pkey" PRIMARY KEY (id);


--
-- Name: PurchasedItem PurchasedItem_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."PurchasedItem"
    ADD CONSTRAINT "PurchasedItem_pkey" PRIMARY KEY (id);


--
-- Name: Reaction Reaction_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Reaction"
    ADD CONSTRAINT "Reaction_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: Setting Setting_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Setting"
    ADD CONSTRAINT "Setting_pkey" PRIMARY KEY (key);


--
-- Name: ShopItem ShopItem_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."ShopItem"
    ADD CONSTRAINT "ShopItem_pkey" PRIMARY KEY (id);


--
-- Name: Stock Stock_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Stock"
    ADD CONSTRAINT "Stock_pkey" PRIMARY KEY (name);


--
-- Name: SyncLog SyncLog_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."SyncLog"
    ADD CONSTRAINT "SyncLog_pkey" PRIMARY KEY (id);


--
-- Name: Theme Theme_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Theme"
    ADD CONSTRAINT "Theme_pkey" PRIMARY KEY (id);


--
-- Name: Ticket Ticket_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Ticket"
    ADD CONSTRAINT "Ticket_pkey" PRIMARY KEY (id);


--
-- Name: UserDevice UserDevice_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."UserDevice"
    ADD CONSTRAINT "UserDevice_pkey" PRIMARY KEY (id);


--
-- Name: UserFartStats UserFartStats_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."UserFartStats"
    ADD CONSTRAINT "UserFartStats_pkey" PRIMARY KEY (id);


--
-- Name: UserPortfolio UserPortfolio_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."UserPortfolio"
    ADD CONSTRAINT "UserPortfolio_pkey" PRIMARY KEY (user_id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Achievement_user_id_achievement_id_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "Achievement_user_id_achievement_id_key" ON public."Achievement" USING btree (user_id, achievement_id);


--
-- Name: Achievement_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Achievement_user_id_idx" ON public."Achievement" USING btree (user_id);


--
-- Name: Activity_activity_type_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Activity_activity_type_idx" ON public."Activity" USING btree (activity_type);


--
-- Name: Activity_recorded_at_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Activity_recorded_at_idx" ON public."Activity" USING btree (recorded_at);


--
-- Name: Activity_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Activity_user_id_idx" ON public."Activity" USING btree (user_id);


--
-- Name: Character_elo_rating_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Character_elo_rating_idx" ON public."Character" USING btree (elo_rating);


--
-- Name: ConversationParticipant_conversation_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "ConversationParticipant_conversation_id_idx" ON public."ConversationParticipant" USING btree (conversation_id);


--
-- Name: ConversationParticipant_conversation_id_user_id_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "ConversationParticipant_conversation_id_user_id_key" ON public."ConversationParticipant" USING btree (conversation_id, user_id);


--
-- Name: ConversationParticipant_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "ConversationParticipant_user_id_idx" ON public."ConversationParticipant" USING btree (user_id);


--
-- Name: Conversation_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Conversation_id_idx" ON public."Conversation" USING btree (id);


--
-- Name: DailyChallenge_date_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "DailyChallenge_date_idx" ON public."DailyChallenge" USING btree (date);


--
-- Name: DailyChallenge_user_id_challenge_type_date_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "DailyChallenge_user_id_challenge_type_date_key" ON public."DailyChallenge" USING btree (user_id, challenge_type, date);


--
-- Name: DailyChallenge_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "DailyChallenge_user_id_idx" ON public."DailyChallenge" USING btree (user_id);


--
-- Name: FartEvent_timestamp_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "FartEvent_timestamp_idx" ON public."FartEvent" USING btree ("timestamp");


--
-- Name: FartEvent_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "FartEvent_user_id_idx" ON public."FartEvent" USING btree (user_id);


--
-- Name: Favorite_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Favorite_user_id_idx" ON public."Favorite" USING btree (user_id);


--
-- Name: Favorite_user_id_item_type_item_id_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "Favorite_user_id_item_type_item_id_key" ON public."Favorite" USING btree (user_id, item_type, item_id);


--
-- Name: GameStat_game_type_stat_type_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "GameStat_game_type_stat_type_idx" ON public."GameStat" USING btree (game_type, stat_type);


--
-- Name: GameStat_recorded_at_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "GameStat_recorded_at_idx" ON public."GameStat" USING btree (recorded_at);


--
-- Name: GameStat_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "GameStat_user_id_idx" ON public."GameStat" USING btree (user_id);


--
-- Name: HighScore_game_type_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "HighScore_game_type_idx" ON public."HighScore" USING btree (game_type);


--
-- Name: HighScore_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "HighScore_user_id_idx" ON public."HighScore" USING btree (user_id);


--
-- Name: Message_conversation_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Message_conversation_id_idx" ON public."Message" USING btree (conversation_id);


--
-- Name: Message_created_at_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Message_created_at_idx" ON public."Message" USING btree (created_at);


--
-- Name: Message_sender_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Message_sender_id_idx" ON public."Message" USING btree (sender_id);


--
-- Name: ProcessingStats_date_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "ProcessingStats_date_key" ON public."ProcessingStats" USING btree (date);


--
-- Name: Profile_user_id_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "Profile_user_id_key" ON public."Profile" USING btree (user_id);


--
-- Name: PurchasedItem_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "PurchasedItem_user_id_idx" ON public."PurchasedItem" USING btree (user_id);


--
-- Name: PurchasedItem_user_id_item_id_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "PurchasedItem_user_id_item_id_key" ON public."PurchasedItem" USING btree (user_id, item_id);


--
-- Name: Reaction_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Reaction_user_id_idx" ON public."Reaction" USING btree (user_id);


--
-- Name: Reaction_user_id_target_type_target_id_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "Reaction_user_id_target_type_target_id_key" ON public."Reaction" USING btree (user_id, target_type, target_id);


--
-- Name: Session_token_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Session_token_idx" ON public."Session" USING btree (token);


--
-- Name: Session_token_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "Session_token_key" ON public."Session" USING btree (token);


--
-- Name: Session_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Session_user_id_idx" ON public."Session" USING btree (user_id);


--
-- Name: ShopItem_category_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "ShopItem_category_idx" ON public."ShopItem" USING btree (category);


--
-- Name: SyncLog_device_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "SyncLog_device_id_idx" ON public."SyncLog" USING btree (device_id);


--
-- Name: SyncLog_started_at_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "SyncLog_started_at_idx" ON public."SyncLog" USING btree (started_at);


--
-- Name: SyncLog_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "SyncLog_user_id_idx" ON public."SyncLog" USING btree (user_id);


--
-- Name: Theme_user_id_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "Theme_user_id_key" ON public."Theme" USING btree (user_id);


--
-- Name: Ticket_is_deleted_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Ticket_is_deleted_idx" ON public."Ticket" USING btree (is_deleted);


--
-- Name: Ticket_priority_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Ticket_priority_idx" ON public."Ticket" USING btree (priority);


--
-- Name: Ticket_status_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Ticket_status_idx" ON public."Ticket" USING btree (status);


--
-- Name: Ticket_type_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Ticket_type_idx" ON public."Ticket" USING btree (type);


--
-- Name: UserDevice_device_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "UserDevice_device_id_idx" ON public."UserDevice" USING btree (device_id);


--
-- Name: UserDevice_device_id_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "UserDevice_device_id_key" ON public."UserDevice" USING btree (device_id);


--
-- Name: UserDevice_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "UserDevice_user_id_idx" ON public."UserDevice" USING btree (user_id);


--
-- Name: UserFartStats_user_id_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "UserFartStats_user_id_key" ON public."UserFartStats" USING btree (user_id);


--
-- Name: User_email_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "User_email_idx" ON public."User" USING btree (email);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: Achievement Achievement_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Achievement"
    ADD CONSTRAINT "Achievement_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Activity Activity_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Activity"
    ADD CONSTRAINT "Activity_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CharacterMatch CharacterMatch_character_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."CharacterMatch"
    ADD CONSTRAINT "CharacterMatch_character_id_fkey" FOREIGN KEY (character_id) REFERENCES public."Character"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: CharacterMatch CharacterMatch_voter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."CharacterMatch"
    ADD CONSTRAINT "CharacterMatch_voter_id_fkey" FOREIGN KEY (voter_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: CharacterMatch CharacterMatch_winner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."CharacterMatch"
    ADD CONSTRAINT "CharacterMatch_winner_id_fkey" FOREIGN KEY (winner_id) REFERENCES public."Character"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ConversationParticipant ConversationParticipant_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."ConversationParticipant"
    ADD CONSTRAINT "ConversationParticipant_conversation_id_fkey" FOREIGN KEY (conversation_id) REFERENCES public."Conversation"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: DailyChallenge DailyChallenge_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."DailyChallenge"
    ADD CONSTRAINT "DailyChallenge_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Favorite Favorite_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Favorite"
    ADD CONSTRAINT "Favorite_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: GameStat GameStat_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."GameStat"
    ADD CONSTRAINT "GameStat_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: HighScore HighScore_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."HighScore"
    ADD CONSTRAINT "HighScore_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Message Message_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_conversation_id_fkey" FOREIGN KEY (conversation_id) REFERENCES public."Conversation"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Message Message_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_sender_id_fkey" FOREIGN KEY (sender_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Profile Profile_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Profile"
    ADD CONSTRAINT "Profile_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PurchasedItem PurchasedItem_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."PurchasedItem"
    ADD CONSTRAINT "PurchasedItem_item_id_fkey" FOREIGN KEY (item_id) REFERENCES public."ShopItem"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Reaction Reaction_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Reaction"
    ADD CONSTRAINT "Reaction_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Session Session_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Theme Theme_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Theme"
    ADD CONSTRAINT "Theme_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UserDevice UserDevice_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."UserDevice"
    ADD CONSTRAINT "UserDevice_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UserFartStats UserFartStats_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."UserFartStats"
    ADD CONSTRAINT "UserFartStats_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: UserPortfolio UserPortfolio_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."UserPortfolio"
    ADD CONSTRAINT "UserPortfolio_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict Yzl3XdvdT3R5hb83RoRXVYCBzUisVk0HkgzO06X0j1t30t1ADmNdftrp4l7Wdte

