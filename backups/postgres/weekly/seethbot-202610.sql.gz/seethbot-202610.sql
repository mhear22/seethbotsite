--
-- PostgreSQL database dump
--

\restrict iql2trgsvAQ3FxCtbSIcXiddqto5SM5q7NI8kSqs8G1lgfcdIxMaiORbUhJTI9i

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.10 (Debian 16.10-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Achievement; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Achievement" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    achievement_id text NOT NULL,
    achievement_name text NOT NULL,
    description text NOT NULL,
    icon text,
    unlocked_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Achievement" OWNER TO seethbot;

--
-- Name: Achievement_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."Achievement_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Achievement_id_seq" OWNER TO seethbot;

--
-- Name: Achievement_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."Achievement_id_seq" OWNED BY public."Achievement".id;


--
-- Name: Activity; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Activity" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    user_name text,
    user_avatar text,
    activity_type text NOT NULL,
    description text NOT NULL,
    metadata text,
    points_change integer DEFAULT 0 NOT NULL,
    game_type text,
    recorded_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Activity" OWNER TO seethbot;

--
-- Name: Activity_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."Activity_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Activity_id_seq" OWNER TO seethbot;

--
-- Name: Activity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."Activity_id_seq" OWNED BY public."Activity".id;


--
-- Name: Character; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Character" (
    id integer NOT NULL,
    name text NOT NULL,
    image_url text,
    elo_rating integer DEFAULT 1200 NOT NULL,
    wins integer DEFAULT 0 NOT NULL,
    losses integer DEFAULT 0 NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Character" OWNER TO seethbot;

--
-- Name: CharacterMatch; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."CharacterMatch" (
    id integer NOT NULL,
    character_id integer NOT NULL,
    opponent_id integer NOT NULL,
    winner_id integer NOT NULL,
    voter_id integer NOT NULL,
    voted_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."CharacterMatch" OWNER TO seethbot;

--
-- Name: CharacterMatch_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."CharacterMatch_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."CharacterMatch_id_seq" OWNER TO seethbot;

--
-- Name: CharacterMatch_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."CharacterMatch_id_seq" OWNED BY public."CharacterMatch".id;


--
-- Name: Character_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."Character_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Character_id_seq" OWNER TO seethbot;

--
-- Name: Character_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."Character_id_seq" OWNED BY public."Character".id;


--
-- Name: Click; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Click" (
    id integer NOT NULL,
    count integer DEFAULT 0 NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Click" OWNER TO seethbot;

--
-- Name: Click_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."Click_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Click_id_seq" OWNER TO seethbot;

--
-- Name: Click_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."Click_id_seq" OWNED BY public."Click".id;


--
-- Name: Conversation; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Conversation" (
    id integer NOT NULL,
    type text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Conversation" OWNER TO seethbot;

--
-- Name: ConversationParticipant; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."ConversationParticipant" (
    id integer NOT NULL,
    conversation_id integer NOT NULL,
    user_id integer NOT NULL,
    joined_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_read_at timestamp(3) without time zone
);


ALTER TABLE public."ConversationParticipant" OWNER TO seethbot;

--
-- Name: ConversationParticipant_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."ConversationParticipant_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ConversationParticipant_id_seq" OWNER TO seethbot;

--
-- Name: ConversationParticipant_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."ConversationParticipant_id_seq" OWNED BY public."ConversationParticipant".id;


--
-- Name: Conversation_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."Conversation_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Conversation_id_seq" OWNER TO seethbot;

--
-- Name: Conversation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."Conversation_id_seq" OWNED BY public."Conversation".id;


--
-- Name: DailyChallenge; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."DailyChallenge" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    challenge_type text NOT NULL,
    description text NOT NULL,
    target_value integer NOT NULL,
    current_value integer DEFAULT 0 NOT NULL,
    progress double precision DEFAULT 0 NOT NULL,
    completed boolean DEFAULT false NOT NULL,
    date text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    completed_at timestamp(3) without time zone
);


ALTER TABLE public."DailyChallenge" OWNER TO seethbot;

--
-- Name: DailyChallenge_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."DailyChallenge_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."DailyChallenge_id_seq" OWNER TO seethbot;

--
-- Name: DailyChallenge_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."DailyChallenge_id_seq" OWNED BY public."DailyChallenge".id;


--
-- Name: DataCenterRun; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."DataCenterRun" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name text NOT NULL,
    location text NOT NULL,
    state_json text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    last_played_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."DataCenterRun" OWNER TO seethbot;

--
-- Name: DataCenterRun_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."DataCenterRun_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."DataCenterRun_id_seq" OWNER TO seethbot;

--
-- Name: DataCenterRun_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."DataCenterRun_id_seq" OWNED BY public."DataCenterRun".id;


--
-- Name: FartEvent; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."FartEvent" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    volume double precision NOT NULL,
    bass_gain double precision,
    bass_frequency double precision,
    distortion_amount double precision,
    volume_multiplier double precision,
    playback_rate double precision,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    user_agent text,
    ip_address text
);


ALTER TABLE public."FartEvent" OWNER TO seethbot;

--
-- Name: FartEvent_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."FartEvent_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."FartEvent_id_seq" OWNER TO seethbot;

--
-- Name: FartEvent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."FartEvent_id_seq" OWNED BY public."FartEvent".id;


--
-- Name: Favorite; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Favorite" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    item_type text NOT NULL,
    item_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    display_name text,
    order_index integer DEFAULT 0 NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Favorite" OWNER TO seethbot;

--
-- Name: Favorite_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."Favorite_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Favorite_id_seq" OWNER TO seethbot;

--
-- Name: Favorite_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."Favorite_id_seq" OWNED BY public."Favorite".id;


--
-- Name: GameStat; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."GameStat" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    game_type text NOT NULL,
    stat_type text NOT NULL,
    value double precision NOT NULL,
    metadata text,
    recorded_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."GameStat" OWNER TO seethbot;

--
-- Name: GameStat_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."GameStat_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."GameStat_id_seq" OWNER TO seethbot;

--
-- Name: GameStat_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."GameStat_id_seq" OWNED BY public."GameStat".id;


--
-- Name: HighScore; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."HighScore" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    user_name text,
    game_type text NOT NULL,
    score integer NOT NULL,
    details text,
    recorded_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."HighScore" OWNER TO seethbot;

--
-- Name: HighScore_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."HighScore_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."HighScore_id_seq" OWNER TO seethbot;

--
-- Name: HighScore_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."HighScore_id_seq" OWNED BY public."HighScore".id;


--
-- Name: MembershipTier; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."MembershipTier" (
    id integer NOT NULL,
    name text NOT NULL,
    price integer NOT NULL,
    "interval" text DEFAULT 'month'::text NOT NULL,
    features text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."MembershipTier" OWNER TO seethbot;

--
-- Name: MembershipTier_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."MembershipTier_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."MembershipTier_id_seq" OWNER TO seethbot;

--
-- Name: MembershipTier_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."MembershipTier_id_seq" OWNED BY public."MembershipTier".id;


--
-- Name: Message; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Message" (
    id integer NOT NULL,
    conversation_id integer NOT NULL,
    sender_id integer NOT NULL,
    content text NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Message" OWNER TO seethbot;

--
-- Name: Message_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."Message_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Message_id_seq" OWNER TO seethbot;

--
-- Name: Message_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."Message_id_seq" OWNED BY public."Message".id;


--
-- Name: ProcessingStats; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."ProcessingStats" (
    id integer NOT NULL,
    date text NOT NULL,
    total_processed integer DEFAULT 0 NOT NULL,
    simple_playbacks integer DEFAULT 0 NOT NULL,
    processed_playbacks integer DEFAULT 0 NOT NULL,
    avg_bass_gain double precision DEFAULT 0.0 NOT NULL,
    avg_distortion double precision DEFAULT 0.0 NOT NULL,
    avg_volume_multiplier double precision DEFAULT 0.0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ProcessingStats" OWNER TO seethbot;

--
-- Name: ProcessingStats_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."ProcessingStats_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ProcessingStats_id_seq" OWNER TO seethbot;

--
-- Name: ProcessingStats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."ProcessingStats_id_seq" OWNED BY public."ProcessingStats".id;


--
-- Name: Profile; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Profile" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    theme_preferences text,
    custom_colors text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    avatar_url text,
    bio text,
    display_name text,
    is_public boolean DEFAULT true NOT NULL,
    location text,
    profile_banner_url text,
    social_links text,
    status_message text,
    website text
);


ALTER TABLE public."Profile" OWNER TO seethbot;

--
-- Name: Profile_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."Profile_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Profile_id_seq" OWNER TO seethbot;

--
-- Name: Profile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."Profile_id_seq" OWNED BY public."Profile".id;


--
-- Name: PurchasedItem; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."PurchasedItem" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    item_id integer NOT NULL,
    purchased_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."PurchasedItem" OWNER TO seethbot;

--
-- Name: PurchasedItem_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."PurchasedItem_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."PurchasedItem_id_seq" OWNER TO seethbot;

--
-- Name: PurchasedItem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."PurchasedItem_id_seq" OWNED BY public."PurchasedItem".id;


--
-- Name: Reaction; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Reaction" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    target_type text NOT NULL,
    target_id text NOT NULL,
    emoji text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Reaction" OWNER TO seethbot;

--
-- Name: Reaction_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."Reaction_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Reaction_id_seq" OWNER TO seethbot;

--
-- Name: Reaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."Reaction_id_seq" OWNED BY public."Reaction".id;


--
-- Name: Session; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Session" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    device_name text,
    device_type text,
    token text NOT NULL,
    expires_at timestamp(3) without time zone NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_used_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Session" OWNER TO seethbot;

--
-- Name: Session_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."Session_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Session_id_seq" OWNER TO seethbot;

--
-- Name: Session_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."Session_id_seq" OWNED BY public."Session".id;


--
-- Name: Setting; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Setting" (
    key text NOT NULL,
    value text NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Setting" OWNER TO seethbot;

--
-- Name: ShopItem; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."ShopItem" (
    id integer NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    price integer NOT NULL,
    category text NOT NULL,
    image_url text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    effect text,
    icon text
);


ALTER TABLE public."ShopItem" OWNER TO seethbot;

--
-- Name: ShopItem_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."ShopItem_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ShopItem_id_seq" OWNER TO seethbot;

--
-- Name: ShopItem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."ShopItem_id_seq" OWNED BY public."ShopItem".id;


--
-- Name: Stock; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Stock" (
    name text NOT NULL,
    avatar text NOT NULL,
    price integer NOT NULL,
    coolness_score integer NOT NULL,
    shares integer NOT NULL,
    min_price integer NOT NULL,
    max_price integer NOT NULL,
    price_history text NOT NULL
);


ALTER TABLE public."Stock" OWNER TO seethbot;

--
-- Name: SubscriptionPayment; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."SubscriptionPayment" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    tier_name text NOT NULL,
    amount integer NOT NULL,
    currency text DEFAULT 'AUD'::text NOT NULL,
    payment_method text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    paypal_order_id text,
    paypal_txn_id text,
    bank_ref text,
    admin_notes text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    completed_at timestamp(3) without time zone
);


ALTER TABLE public."SubscriptionPayment" OWNER TO seethbot;

--
-- Name: SubscriptionPayment_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."SubscriptionPayment_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."SubscriptionPayment_id_seq" OWNER TO seethbot;

--
-- Name: SubscriptionPayment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."SubscriptionPayment_id_seq" OWNED BY public."SubscriptionPayment".id;


--
-- Name: SyncLog; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."SyncLog" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    device_id text NOT NULL,
    sync_type text NOT NULL,
    status text NOT NULL,
    items_synced integer DEFAULT 0 NOT NULL,
    conflicts_found integer DEFAULT 0 NOT NULL,
    conflicts_resolved integer DEFAULT 0 NOT NULL,
    error_message text,
    started_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    completed_at timestamp(3) without time zone
);


ALTER TABLE public."SyncLog" OWNER TO seethbot;

--
-- Name: SyncLog_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."SyncLog_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."SyncLog_id_seq" OWNER TO seethbot;

--
-- Name: SyncLog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."SyncLog_id_seq" OWNED BY public."SyncLog".id;


--
-- Name: Theme; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Theme" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    preset text DEFAULT 'default'::text NOT NULL,
    custom_colors text,
    dark_mode boolean DEFAULT true NOT NULL,
    high_contrast boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Theme" OWNER TO seethbot;

--
-- Name: Theme_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."Theme_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Theme_id_seq" OWNER TO seethbot;

--
-- Name: Theme_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."Theme_id_seq" OWNED BY public."Theme".id;


--
-- Name: Ticket; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Ticket" (
    id integer NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    response text,
    creator_id text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    type text DEFAULT 'feature'::text NOT NULL,
    priority text DEFAULT 'medium'::text NOT NULL,
    tags text,
    category text,
    dependencies text,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE public."Ticket" OWNER TO seethbot;

--
-- Name: Ticket_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."Ticket_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Ticket_id_seq" OWNER TO seethbot;

--
-- Name: Ticket_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."Ticket_id_seq" OWNED BY public."Ticket".id;


--
-- Name: User; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."User" (
    id integer NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    display_name text,
    avatar_url text,
    banner_url text,
    bio text,
    status text,
    show_email integer DEFAULT 1 NOT NULL,
    show_joined_date integer DEFAULT 1 NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    discord_id text,
    discord_username text,
    discord_discriminator text,
    discord_avatar text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    payment_method text,
    subscription_end timestamp(3) without time zone,
    subscription_start timestamp(3) without time zone,
    subscription_status text,
    subscription_tier text
);


ALTER TABLE public."User" OWNER TO seethbot;

--
-- Name: UserDevice; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."UserDevice" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    device_id text NOT NULL,
    device_name text,
    device_type text,
    platform text,
    last_sync timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."UserDevice" OWNER TO seethbot;

--
-- Name: UserDevice_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."UserDevice_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."UserDevice_id_seq" OWNER TO seethbot;

--
-- Name: UserDevice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."UserDevice_id_seq" OWNED BY public."UserDevice".id;


--
-- Name: UserFartStats; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."UserFartStats" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    total_farts integer DEFAULT 0 NOT NULL,
    total_volume double precision DEFAULT 0.0 NOT NULL,
    avg_volume double precision DEFAULT 0.0 NOT NULL,
    max_volume double precision DEFAULT 0.0 NOT NULL,
    min_volume double precision DEFAULT 0.0 NOT NULL,
    first_fart timestamp(3) without time zone,
    last_fart timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."UserFartStats" OWNER TO seethbot;

--
-- Name: UserFartStats_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."UserFartStats_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."UserFartStats_id_seq" OWNER TO seethbot;

--
-- Name: UserFartStats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."UserFartStats_id_seq" OWNED BY public."UserFartStats".id;


--
-- Name: UserPortfolio; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."UserPortfolio" (
    user_id integer NOT NULL,
    cash integer DEFAULT 10000 NOT NULL,
    holdings text DEFAULT '{}'::text NOT NULL,
    transactions text DEFAULT '[]'::text NOT NULL
);


ALTER TABLE public."UserPortfolio" OWNER TO seethbot;

--
-- Name: User_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."User_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."User_id_seq" OWNER TO seethbot;

--
-- Name: User_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."User_id_seq" OWNED BY public."User".id;


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO seethbot;

--
-- Name: Achievement id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Achievement" ALTER COLUMN id SET DEFAULT nextval('public."Achievement_id_seq"'::regclass);


--
-- Name: Activity id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Activity" ALTER COLUMN id SET DEFAULT nextval('public."Activity_id_seq"'::regclass);


--
-- Name: Character id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Character" ALTER COLUMN id SET DEFAULT nextval('public."Character_id_seq"'::regclass);


--
-- Name: CharacterMatch id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."CharacterMatch" ALTER COLUMN id SET DEFAULT nextval('public."CharacterMatch_id_seq"'::regclass);


--
-- Name: Click id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Click" ALTER COLUMN id SET DEFAULT nextval('public."Click_id_seq"'::regclass);


--
-- Name: Conversation id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Conversation" ALTER COLUMN id SET DEFAULT nextval('public."Conversation_id_seq"'::regclass);


--
-- Name: ConversationParticipant id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."ConversationParticipant" ALTER COLUMN id SET DEFAULT nextval('public."ConversationParticipant_id_seq"'::regclass);


--
-- Name: DailyChallenge id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."DailyChallenge" ALTER COLUMN id SET DEFAULT nextval('public."DailyChallenge_id_seq"'::regclass);


--
-- Name: DataCenterRun id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."DataCenterRun" ALTER COLUMN id SET DEFAULT nextval('public."DataCenterRun_id_seq"'::regclass);


--
-- Name: FartEvent id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."FartEvent" ALTER COLUMN id SET DEFAULT nextval('public."FartEvent_id_seq"'::regclass);


--
-- Name: Favorite id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Favorite" ALTER COLUMN id SET DEFAULT nextval('public."Favorite_id_seq"'::regclass);


--
-- Name: GameStat id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."GameStat" ALTER COLUMN id SET DEFAULT nextval('public."GameStat_id_seq"'::regclass);


--
-- Name: HighScore id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."HighScore" ALTER COLUMN id SET DEFAULT nextval('public."HighScore_id_seq"'::regclass);


--
-- Name: MembershipTier id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."MembershipTier" ALTER COLUMN id SET DEFAULT nextval('public."MembershipTier_id_seq"'::regclass);


--
-- Name: Message id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Message" ALTER COLUMN id SET DEFAULT nextval('public."Message_id_seq"'::regclass);


--
-- Name: ProcessingStats id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."ProcessingStats" ALTER COLUMN id SET DEFAULT nextval('public."ProcessingStats_id_seq"'::regclass);


--
-- Name: Profile id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Profile" ALTER COLUMN id SET DEFAULT nextval('public."Profile_id_seq"'::regclass);


--
-- Name: PurchasedItem id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."PurchasedItem" ALTER COLUMN id SET DEFAULT nextval('public."PurchasedItem_id_seq"'::regclass);


--
-- Name: Reaction id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Reaction" ALTER COLUMN id SET DEFAULT nextval('public."Reaction_id_seq"'::regclass);


--
-- Name: Session id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Session" ALTER COLUMN id SET DEFAULT nextval('public."Session_id_seq"'::regclass);


--
-- Name: ShopItem id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."ShopItem" ALTER COLUMN id SET DEFAULT nextval('public."ShopItem_id_seq"'::regclass);


--
-- Name: SubscriptionPayment id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."SubscriptionPayment" ALTER COLUMN id SET DEFAULT nextval('public."SubscriptionPayment_id_seq"'::regclass);


--
-- Name: SyncLog id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."SyncLog" ALTER COLUMN id SET DEFAULT nextval('public."SyncLog_id_seq"'::regclass);


--
-- Name: Theme id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Theme" ALTER COLUMN id SET DEFAULT nextval('public."Theme_id_seq"'::regclass);


--
-- Name: Ticket id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Ticket" ALTER COLUMN id SET DEFAULT nextval('public."Ticket_id_seq"'::regclass);


--
-- Name: User id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."User" ALTER COLUMN id SET DEFAULT nextval('public."User_id_seq"'::regclass);


--
-- Name: UserDevice id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."UserDevice" ALTER COLUMN id SET DEFAULT nextval('public."UserDevice_id_seq"'::regclass);


--
-- Name: UserFartStats id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."UserFartStats" ALTER COLUMN id SET DEFAULT nextval('public."UserFartStats_id_seq"'::regclass);


--
-- Data for Name: Achievement; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Achievement" (id, user_id, achievement_id, achievement_name, description, icon, unlocked_at) FROM stdin;
\.


--
-- Data for Name: Activity; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Activity" (id, user_id, user_name, user_avatar, activity_type, description, metadata, points_change, game_type, recorded_at) FROM stdin;
\.


--
-- Data for Name: Character; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Character" (id, name, image_url, elo_rating, wins, losses, is_deleted, created_at, updated_at) FROM stdin;
2	Snouse and Mail	https://64.media.tumblr.com/54f100369945372c88d7dcd03a9a5825/57e2862b5e7186d9-24/s540x810/1c864ff3f33076224fa1a9499c0146b973588170.jpg	1154	3	6	f	2026-02-04 17:57:01	2026-02-09 10:39:46
4	Video Kojima	https://64.media.tumblr.com/f3fb1509753ce3766012363ef45694c2/7db86ffa66eba893-ce/s540x810/73f8d734cd1d5841891044bc85a6575401c850b2.jpg	1158	4	8	f	2026-02-04 17:58:35	2026-02-10 06:11:24
5	Lying down Miku	https://64.media.tumblr.com/248c337c9a79c944faa1cb222f221e3e/3b0374c89329798b-89/s540x810/d9395dbf1fd127bbbb823b5330f4e915d2e02de5.pnj	1189	1	2	f	2026-02-04 17:59:34	2026-02-06 14:15:56
6	Nurse Joy	https://x.com/i/status/1940083994168893687	1251	5	1	f	2026-02-04 18:01:29	2026-02-06 14:15:03
7	Spider Chair	https://pbs.twimg.com/media/HAPxZiFaEAAvMiL?format=jpg&name=medium	1209	4	3	f	2026-02-04 18:03:02	2026-02-06 14:15:37
8	Bluesky Account Suspension	https://pbs.twimg.com/media/HAUs_ifboAA0Plr?format=jpg&name=medium	1126	1	6	f	2026-02-04 18:03:26	2026-02-06 14:15:30
9	No Sleeper	https://pbs.twimg.com/media/HARvOApb0AA221p?format=png&name=small	1199	2	2	f	2026-02-04 18:06:05	2026-02-05 23:30:24
10	Dinner for One	https://pbs.twimg.com/media/HAUFp_DawAAUiwk?format=jpg&name=small	1259	4	0	f	2026-02-04 18:08:09	2026-02-05 04:39:43
11	Dark Uni	https://pbs.twimg.com/media/HAUUdaZbkAAxaB_?format=jpg&name=small	1276	7	1	f	2026-02-04 18:08:25	2026-02-09 10:39:46
12	Adobe Animate	\N	1113	1	7	f	2026-02-04 18:08:54	2026-02-05 05:23:45
13	Adobe Animate (With Picture)	https://pbs.twimg.com/media/HALUUJWWMAAizLr?format=png&name=small	1172	3	5	f	2026-02-04 18:09:05	2026-02-10 09:37:32
14	Queensland Police Service	https://pbs.twimg.com/media/HASr0IibMAA_1-6?format=jpg&name=small	1088	0	8	f	2026-02-04 18:09:23	2026-02-06 02:23:59
15	Jellyfish Utensil Holder	https://pbs.twimg.com/media/HAP5UtbbMAADvqP?format=jpg&name=medium	1245	4	1	f	2026-02-04 18:09:54	2026-02-06 11:51:33
16	Mar10 Milk	https://pbs.twimg.com/media/HAN1lTBbcAAg3se?format=jpg&name=large	1176	4	5	f	2026-02-04 18:11:10	2026-02-06 14:16:10
17	Tumblr Poll Cake	https://64.media.tumblr.com/d555346393e8c2ea55da646a53db82a2/1561f50b9cbf8599-e6/s540x810/8047745de8917e434a5babc2346bfc4cbb733103.pnj	1099	0	7	f	2026-02-04 18:14:37	2026-02-10 06:11:24
18	David Lynch	https://64.media.tumblr.com/7a3b60a0b1ff3daf24c8a16207beb901/82eaced35c0e6dc5-cb/s540x810/a501413f67ec64d2d56fb83d0d43275caa895ce0.jpg	1322	9	0	f	2026-02-04 18:18:52	2026-02-05 23:30:42
19	Markiplier	https://64.media.tumblr.com/bea562bda37afe0fca2d19663cb82068/9cb7467eb20e3588-57/s400x600/5a4b3d56be0cf927eaefbefcbe36a313e6c67fee.gifv	1247	7	3	f	2026-02-04 18:19:45	2026-02-09 10:39:51
20	Watermelon	https://64.media.tumblr.com/017cd22c89b7b4f0ad325aa1d9cb8fc2/4017da0d095ef769-9e/s400x600/d5f2151405bb1afa5698b8efb83623b40dce7e97.jpg	1273	6	1	f	2026-02-04 18:21:18	2026-02-05 23:30:28
21	Tennis Ball	https://64.media.tumblr.com/e47673c57712cffb4e0bc15f515063b3/1e93aa5ae9766c62-17/s400x600/206a26c46fc703ba24287c3b4a8e03bd81bc4c7f.jpg	1270	7	2	f	2026-02-04 18:22:02	2026-02-10 09:37:32
22	Never Kill Yourself	https://64.media.tumblr.com/f5b9d6b3b2605aaafd63370ba0d26dd0/5db31de0dd99240e-cf/s400x600/2a7c94a33df3f45b073f061aa354da5e638ec06b.gif	1216	1	0	f	2026-02-04 18:25:28	2026-02-06 11:50:33
23	Orlando if he had an average or even a small ween	https://media.istockphoto.com/id/1434185664/vector/lying-man-with-a-long-nose-pinocchio.jpg?s=612x612&w=0&k=20&c=zzIOrozwM89eCN11S_lWeBpJIEaN8hvywhXAmU2U2jg=	1111	0	6	f	2026-02-04 18:25:41	2026-02-06 11:51:00
24	Thousand Layer Apple Cake	https://va.media.tumblr.com/tumblr_t8lpmaWk6D1zg326b.mp4	1200	1	1	f	2026-02-04 18:27:28	2026-02-06 11:51:33
25	Giorgia Meloni Angel	https://cdn.i-scmp.com/sites/default/files/styles/1020x680/public/d8/images/canvas/2026/02/01/14bf244e-801b-4300-9837-20172ff3fb35_44db174a.jpg?itok=GSjpisR7&v=1769881806	1173	1	3	f	2026-02-04 18:27:46	2026-02-05 04:41:05
26	Toyota Fun Cargo Concept	https://64.media.tumblr.com/3a8ee0ddca17b83d76f11239961fd0eb/522475107bada3e0-16/s540x810/7c15b983058d70b4f6a539a5e7447d73cb9c94cc.jpg	1174	2	4	f	2026-02-04 18:29:56	2026-02-06 11:51:08
28	AI generated Product Names	https://64.media.tumblr.com/b66fe448dbd7a32006b5eb608c7d758c/7c01374d31631942-69/s1280x1920/729623371c6da38b83165981b63922799558134e.jpg	1174	1	3	f	2026-02-04 18:33:42	2026-02-06 14:15:23
29	MS Paint dog	https://preview.redd.it/tomodachi-life-living-the-dream-is-the-true-drawn-to-life-v0-7f97merb5dgg1.png?width=640&crop=smart&auto=webp&s=95cd092d6117a1958e828daf666482133ca09107	1183	2	3	f	2026-02-04 18:35:17	2026-02-05 05:23:40
30	Baby Thumbnails	https://64.media.tumblr.com/fe8d013afff4711d04f8adaa8365d011/3a82e4a93e29b5a1-36/s540x810/0a451f289f4eb3435907e1e95b97333b4d0aa514.pnj	1130	0	5	f	2026-02-04 18:35:28	2026-02-09 10:40:19
31	That girl that nobody wants to date from TL:LTD	https://sm.ign.com/t/ign_pt/video/t/tomodachi-/tomodachi-life-living-the-dream-direct-get-an-extended-gamep_qd75.1200.jpg	1234	4	2	f	2026-02-04 18:35:49	2026-02-07 09:10:43
32	七里ヶ浜駅-稲村ヶ崎駅間	https://64.media.tumblr.com/74ca414768db767b4601d2194b581c99/d0e4e7e03aebe7b7-a8/s540x810/6b8c4b9c75e0923fa48611c15db721efb11b1921.jpg	1155	0	3	f	2026-02-04 18:36:03	2026-02-05 21:08:20
34	Static Cling	https://64.media.tumblr.com/1bccb535ab27577426fd7f202d5b89d0/6b916191d2ed8484-76/s500x750/c1fe6e3a215b0e65aad9ac70652eedbdb71bd6cf.png	1201	1	1	f	2026-02-04 18:38:22	2026-02-07 09:10:32
35	Static Electricity	https://64.media.tumblr.com/1bccb535ab27577426fd7f202d5b89d0/6b916191d2ed8484-76/s500x750/c1fe6e3a215b0e65aad9ac70652eedbdb71bd6cf.png	1196	1	1	f	2026-02-04 18:38:33	2026-02-06 14:16:01
37	Electric Field	https://64.media.tumblr.com/1bccb535ab27577426fd7f202d5b89d0/6b916191d2ed8484-76/s500x750/c1fe6e3a215b0e65aad9ac70652eedbdb71bd6cf.png	1230	2	0	f	2026-02-04 18:38:59	2026-02-05 04:40:56
38	Electrostatics	https://64.media.tumblr.com/1bccb535ab27577426fd7f202d5b89d0/6b916191d2ed8484-76/s500x750/c1fe6e3a215b0e65aad9ac70652eedbdb71bd6cf.png	1249	3	0	f	2026-02-04 18:39:09	2026-02-09 10:39:51
39	Minecraft Civil Rights DLC	https://64.media.tumblr.com/5783d15fb011944c73bae25d89abbf69/a428cd1c18710989-4a/s540x810/ee72ffd16c7ba03c01ebe6ceb123badcd4034823.pnj	1184	2	3	f	2026-02-04 18:40:08	2026-02-06 14:16:01
40	panamaha parapara baabapapabarabara party	https://i.ytimg.com/vi/eCjfSDz4eRo/hqdefault.jpg?sqp=-oaymwEcCPYBEIoBSFXyq4qpAw4IARUAAIhCGAFwAcABBg==&rs=AOn4CLCcyyESQBQrihJrL-4qesMhDs1vgQ	1217	1	0	f	2026-02-05 04:44:23	2026-02-06 11:50:39
36	Triboelectric Effect	https://64.media.tumblr.com/1bccb535ab27577426fd7f202d5b89d0/6b916191d2ed8484-76/s500x750/c1fe6e3a215b0e65aad9ac70652eedbdb71bd6cf.png	1230	3	1	f	2026-02-04 18:38:50	2026-02-19 12:46:03.816
1	Snail and Mouse	https://64.media.tumblr.com/15ac9d233e78612262354e70f6b1c601/c9d326f499eff987-e9/s540x810/2d861b9525909e058b744ec2c2458ac5d85f753a.jpg	1235	13	12	f	2026-02-04 17:56:45	2026-02-19 12:46:03.816
41	Dragon Hunter	https://64.media.tumblr.com/7800f005e4dace4814516f5d2c1686b9/ccc0ff7f164376b6-9e/s540x810/ad68b79671913e8c9ee92489895e2fcd658be53a.jpg	1170	0	2	f	2026-02-05 05:22:11	2026-02-06 14:15:47
42	Dragon Hunter	https://64.media.tumblr.com/7800f005e4dace4814516f5d2c1686b9/ccc0ff7f164376b6-9e/s540x810/ad68b79671913e8c9ee92489895e2fcd658be53a.jpg	1222	3	1	f	2026-02-05 05:22:11	2026-02-06 14:16:20
43	Darkiplier	https://64.media.tumblr.com/645ed4744c2d9021f07a310fd91da911/tumblr_inline_ok2mgkqVEP1r3dph6_400.gif	1186	0	1	f	2026-02-05 05:29:13	2026-02-06 14:15:03
44	Darkiplier	https://64.media.tumblr.com/645ed4744c2d9021f07a310fd91da911/tumblr_inline_ok2mgkqVEP1r3dph6_400.gif	1182	0	1	f	2026-02-05 05:29:13	2026-02-06 14:15:23
45	Now Where Were We?	https://64.media.tumblr.com/0cb7e233c9f04dd349322c640ea96b3c/9da2ef120c1fc598-ed/s540x810/ddfe4d954eae6d672eaea0a34811342b47916720.jpg	1259	4	0	f	2026-02-05 05:44:10	2026-02-09 10:40:19
46	Now Where Were We?	https://64.media.tumblr.com/0cb7e233c9f04dd349322c640ea96b3c/9da2ef120c1fc598-ed/s540x810/ddfe4d954eae6d672eaea0a34811342b47916720.jpg	1233	2	0	f	2026-02-05 05:44:10	2026-02-06 14:15:14
47	Joe Biden	https://64.media.tumblr.com/217d8cdbdc04a4e7def5bc58e05f1139/5ddfde35e01979ae-fe/s250x400/339db9eccabf6f8fd82d2e6818c2cc1ac83cf7c4.gif	1186	1	2	f	2026-02-05 06:14:15	2026-02-06 02:23:59
48	Joe Biden	https://64.media.tumblr.com/217d8cdbdc04a4e7def5bc58e05f1139/5ddfde35e01979ae-fe/s250x400/339db9eccabf6f8fd82d2e6818c2cc1ac83cf7c4.gif	1177	0	2	f	2026-02-05 06:14:15	2026-02-05 23:30:42
27	Incredible Suggestion	https://64.media.tumblr.com/bbf2158701130540d51bbae3ac6ce2fc/b0489b1f87fed304-0b/s540x810/41131af2bba871425956bad209b36c2619af1412.pnj	1245	5	2	f	2026-02-04 18:30:34	2026-02-19 12:45:26.031
3	Survivorship Bias	https://64.media.tumblr.com/2586866394b278c4e6b523ec5c2c6ef8/25bc6c1cc1dc7948-13/s540x810/0ee2cce2e0170435635ec6f20b9f2cf4d490e093.jpg	1222	7	5	f	2026-02-04 17:58:15	2026-02-19 12:45:26.032
\.


--
-- Data for Name: CharacterMatch; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."CharacterMatch" (id, character_id, opponent_id, winner_id, voter_id, voted_at) FROM stdin;
\.


--
-- Data for Name: Click; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Click" (id, count, updated_at) FROM stdin;
1	1	2026-02-13 14:31:29.991
\.


--
-- Data for Name: Conversation; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Conversation" (id, type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ConversationParticipant; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."ConversationParticipant" (id, conversation_id, user_id, joined_at, last_read_at) FROM stdin;
\.


--
-- Data for Name: DailyChallenge; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."DailyChallenge" (id, user_id, challenge_type, description, target_value, current_value, progress, completed, date, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: DataCenterRun; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."DataCenterRun" (id, user_id, name, location, state_json, status, created_at, updated_at, last_played_at) FROM stdin;
1	1	Tech Hub Run	tech_hub	{"version":1,"phase":"won","locationId":"tech_hub","day":679,"secondsIntoDay":0,"rows":5,"cols":5,"cash":1582150,"clients":249,"clientInterestProgress":0.12668966257602698,"zeroClientDays":0,"totalWorkload":250.24000000000228,"pressure":0,"expansionLockDays":0,"legalStrikes":0,"rapidExpansionDebt":0,"supplierRep":{"zoogle":102.00000000000016,"asw":6515.800000000562,"macrohard":8.54,"gridlink":3021.1999999995282},"placedRacks":[{"id":"9183d930-2daf-48f6-9fae-c7d0827a52f9","offerId":"gridlink-cooling-tower","supplierId":"gridlink","role":"utility","utilityType":"cooling_tower","adjacentIncomeBoost":0,"movedToday":false,"name":"Cooling Tower","x":1,"y":2,"heat":-9.6,"dailyCash":0,"dailyPowerCost":36,"workloadContribution":0,"repGain":0.35},{"id":"af06acfb-0205-4aa4-bd78-c6db54a4d16b","offerId":"gridlink-cooling-tower","supplierId":"gridlink","role":"utility","utilityType":"cooling_tower","adjacentIncomeBoost":0,"movedToday":false,"name":"Cooling Tower","x":3,"y":2,"heat":-9.6,"dailyCash":0,"dailyPowerCost":36,"workloadContribution":0,"repGain":0.35},{"id":"adeaea5b-c380-4f43-86ec-b3ac0a669378","offerId":"gridlink-cooling-tower","supplierId":"gridlink","role":"utility","utilityType":"cooling_tower","adjacentIncomeBoost":0,"movedToday":false,"name":"Cooling Tower","x":2,"y":1,"heat":-9.6,"dailyCash":0,"dailyPowerCost":36,"workloadContribution":0,"repGain":0.35},{"id":"0dce2818-02de-4cef-a1f5-b17b881468cb","offerId":"gridlink-cooling-tower","supplierId":"gridlink","role":"utility","utilityType":"cooling_tower","adjacentIncomeBoost":0,"movedToday":false,"name":"Cooling Tower","x":2,"y":3,"heat":-9.6,"dailyCash":0,"dailyPowerCost":36,"workloadContribution":0,"repGain":0.35},{"id":"63f8e326-c99a-44cb-a6f3-ac3d16cac60a","offerId":"asw-photon-cage","supplierId":"asw","role":"compute","adjacentIncomeBoost":0,"movedToday":false,"name":"Photon Cage","x":3,"y":3,"heat":10.2,"dailyCash":325,"dailyPowerCost":0,"workloadContribution":1,"repGain":1.1},{"id":"3d78143e-9401-44c9-a3d0-1f7fa0db2886","offerId":"gridlink-cooling-tower","supplierId":"gridlink","role":"utility","utilityType":"cooling_tower","adjacentIncomeBoost":0,"movedToday":false,"name":"Cooling Tower","x":3,"y":4,"heat":-9.6,"dailyCash":0,"dailyPowerCost":36,"workloadContribution":0,"repGain":0.35},{"id":"db8596d5-41fb-42b5-8c76-135d3ab520ee","offerId":"gridlink-cooling-tower","supplierId":"gridlink","role":"utility","utilityType":"cooling_tower","adjacentIncomeBoost":0,"movedToday":false,"name":"Cooling Tower","x":4,"y":3,"heat":-9.6,"dailyCash":0,"dailyPowerCost":36,"workloadContribution":0,"repGain":0.35},{"id":"641c9257-1c26-46aa-b6c2-22722d5351e9","offerId":"gridlink-cooling-tower","supplierId":"gridlink","role":"utility","utilityType":"cooling_tower","adjacentIncomeBoost":0,"movedToday":false,"name":"Cooling Tower","x":0,"y":1,"heat":-9.6,"dailyCash":0,"dailyPowerCost":36,"workloadContribution":0,"repGain":0.35},{"id":"ba3ab6bf-4c84-418a-92b4-373b9c775467","offerId":"gridlink-cooling-tower","supplierId":"gridlink","role":"utility","utilityType":"cooling_tower","adjacentIncomeBoost":0,"movedToday":false,"name":"Cooling Tower","x":1,"y":0,"heat":-9.6,"dailyCash":0,"dailyPowerCost":36,"workloadContribution":0,"repGain":0.35},{"id":"ad9eaff1-5e84-44b3-ba9b-460865e40590","offerId":"asw-photon-cage","supplierId":"asw","role":"compute","adjacentIncomeBoost":0,"movedToday":false,"name":"Photon Cage","x":1,"y":1,"heat":10.2,"dailyCash":325,"dailyPowerCost":0,"workloadContribution":1,"repGain":1.1},{"id":"77bd8c2e-02e0-44ea-b67e-3b9cf77b3d49","offerId":"asw-photon-cage","supplierId":"asw","role":"compute","adjacentIncomeBoost":0,"movedToday":false,"name":"Photon Cage","x":4,"y":4,"heat":10.2,"dailyCash":325,"dailyPowerCost":0,"workloadContribution":1,"repGain":1.1},{"id":"32a4147e-318c-4c22-8fc1-cfc8576a65e4","offerId":"asw-photon-cage","supplierId":"asw","role":"compute","adjacentIncomeBoost":0,"movedToday":false,"name":"Photon Cage","x":0,"y":0,"heat":10.2,"dailyCash":325,"dailyPowerCost":0,"workloadContribution":1,"repGain":1.1},{"id":"42298db6-bf6c-4e8f-b84d-595f13ce9974","offerId":"asw-photon-cage","supplierId":"asw","role":"compute","adjacentIncomeBoost":0,"movedToday":false,"name":"Photon Cage","x":0,"y":2,"heat":10.2,"dailyCash":325,"dailyPowerCost":0,"workloadContribution":1,"repGain":1.1},{"id":"974c02c0-d0ce-45fc-9252-4d54a4e927fc","offerId":"asw-photon-cage","supplierId":"asw","role":"compute","adjacentIncomeBoost":0,"movedToday":false,"name":"Photon Cage","x":2,"y":4,"heat":10.2,"dailyCash":325,"dailyPowerCost":0,"workloadContribution":1,"repGain":1.1},{"id":"726ff73e-ecae-4836-b33d-fe36d1fbfeec","offerId":"gridlink-cooling-tower","supplierId":"gridlink","role":"utility","utilityType":"cooling_tower","adjacentIncomeBoost":0,"movedToday":false,"name":"Cooling Tower","x":1,"y":4,"heat":-9.6,"dailyCash":0,"dailyPowerCost":36,"workloadContribution":0,"repGain":0.35},{"id":"13ececad-447d-4728-8966-cdd5ae814913","offerId":"gridlink-cooling-tower","supplierId":"gridlink","role":"utility","utilityType":"cooling_tower","adjacentIncomeBoost":0,"movedToday":false,"name":"Cooling Tower","x":0,"y":3,"heat":-9.6,"dailyCash":0,"dailyPowerCost":36,"workloadContribution":0,"repGain":0.35},{"id":"732815c1-a35b-4e6d-8024-5c3b4004f639","offerId":"asw-photon-cage","supplierId":"asw","role":"compute","adjacentIncomeBoost":0,"movedToday":false,"name":"Photon Cage","x":1,"y":3,"heat":10.2,"dailyCash":325,"dailyPowerCost":0,"workloadContribution":1,"repGain":1.1},{"id":"f335aa0d-c262-4cd0-991f-63b3ed210cbd","offerId":"gridlink-cooling-tower","supplierId":"gridlink","role":"utility","utilityType":"cooling_tower","adjacentIncomeBoost":0,"movedToday":false,"name":"Cooling Tower","x":4,"y":1,"heat":-9.6,"dailyCash":0,"dailyPowerCost":36,"workloadContribution":0,"repGain":0.35},{"id":"05f0ea62-6d02-4aea-add9-837d4b41f001","offerId":"gridlink-cooling-tower","supplierId":"gridlink","role":"utility","utilityType":"cooling_tower","adjacentIncomeBoost":0,"movedToday":false,"name":"Cooling Tower","x":3,"y":0,"heat":-9.6,"dailyCash":0,"dailyPowerCost":36,"workloadContribution":0,"repGain":0.35},{"id":"712cbf1c-60bc-4615-9db7-11ef0e07d21b","offerId":"asw-photon-cage","supplierId":"asw","role":"compute","adjacentIncomeBoost":0,"movedToday":false,"name":"Photon Cage","x":2,"y":0,"heat":10.2,"dailyCash":325,"dailyPowerCost":0,"workloadContribution":1,"repGain":1.1},{"id":"120766fc-9ea2-4203-bfed-e930975f7bb7","offerId":"asw-photon-cage","supplierId":"asw","role":"compute","adjacentIncomeBoost":0,"movedToday":false,"name":"Photon Cage","x":3,"y":1,"heat":10.2,"dailyCash":325,"dailyPowerCost":0,"workloadContribution":1,"repGain":1.1},{"id":"79a54279-1399-40a1-9148-c40703b0b46a","offerId":"asw-photon-cage","supplierId":"asw","role":"compute","adjacentIncomeBoost":0,"movedToday":false,"name":"Photon Cage","x":4,"y":2,"heat":10.2,"dailyCash":325,"dailyPowerCost":0,"workloadContribution":1,"repGain":1.1},{"id":"3a131bd7-438d-4b1a-b238-e7eac21383dd","offerId":"gridlink-cooling-tower","supplierId":"gridlink","role":"utility","utilityType":"cooling_tower","adjacentIncomeBoost":0,"movedToday":false,"name":"Cooling Tower","x":4,"y":0,"heat":-9.6,"dailyCash":0,"dailyPowerCost":36,"workloadContribution":0,"repGain":0.35},{"id":"594e44de-2daf-406a-9d15-dcef3843751c","offerId":"gridlink-cooling-tower","supplierId":"gridlink","role":"utility","utilityType":"cooling_tower","adjacentIncomeBoost":0,"movedToday":false,"name":"Cooling Tower","x":0,"y":4,"heat":-9.6,"dailyCash":0,"dailyPowerCost":36,"workloadContribution":0,"repGain":0.35}],"heatMap":[[10.666,9.079,10.666,4.888,0],[9.079,10.666,6.984,10.666,4.888],[10.666,6.984,0.006,6.984,10.666],[4.888,10.666,6.984,10.666,9.079],[0,4.888,10.666,9.079,10.666]],"lossReason":null,"runName":"Tech Hub Run"}	won	2026-02-25 15:20:33.836	2026-02-25 15:35:45.711	2026-02-25 15:35:45.582
\.


--
-- Data for Name: FartEvent; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."FartEvent" (id, user_id, volume, bass_gain, bass_frequency, distortion_amount, volume_multiplier, playback_rate, "timestamp", user_agent, ip_address) FROM stdin;
\.


--
-- Data for Name: Favorite; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Favorite" (id, user_id, item_type, item_id, created_at, display_name, order_index, updated_at) FROM stdin;
\.


--
-- Data for Name: GameStat; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."GameStat" (id, user_id, game_type, stat_type, value, metadata, recorded_at) FROM stdin;
\.


--
-- Data for Name: HighScore; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."HighScore" (id, user_id, user_name, game_type, score, details, recorded_at, updated_at) FROM stdin;
\.


--
-- Data for Name: MembershipTier; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."MembershipTier" (id, name, price, "interval", features, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: Message; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Message" (id, conversation_id, sender_id, content, is_deleted, created_at) FROM stdin;
\.


--
-- Data for Name: ProcessingStats; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."ProcessingStats" (id, date, total_processed, simple_playbacks, processed_playbacks, avg_bass_gain, avg_distortion, avg_volume_multiplier, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: Profile; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Profile" (id, user_id, theme_preferences, custom_colors, created_at, updated_at, avatar_url, bio, display_name, is_public, location, profile_banner_url, social_links, status_message, website) FROM stdin;
\.


--
-- Data for Name: PurchasedItem; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."PurchasedItem" (id, user_id, item_id, purchased_at) FROM stdin;
\.


--
-- Data for Name: Reaction; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Reaction" (id, user_id, target_type, target_id, emoji, created_at) FROM stdin;
\.


--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Session" (id, user_id, device_name, device_type, token, expires_at, created_at, last_used_at) FROM stdin;
1	1	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsInRzIjoxNzcwOTkxODEzOTg5LCJpYXQiOjE3NzA5OTE4MTMsImV4cCI6MTc3MzU4MzgxM30.QhHoury0GnYw4YZbCog1ozgUWfVDW02nf6C7MQmipmw	2026-04-02 10:01:51.457	2026-02-13 14:10:13.997	2026-03-03 10:01:51.457
5	1	Firefox on Linux	desktop	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsInRzIjoxNzcxMTUzNDcwMzg1LCJpYXQiOjE3NzExNTM0NzAsImV4cCI6MTc3Mzc0NTQ3MH0.OqOSlNqRF45EpGWUs3rW1w9_MF4bcOOMk-sEyT-sJLM	2026-04-03 14:22:48.139	2026-02-15 11:04:30.394	2026-03-04 14:22:48.139
3	2	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIsInRzIjoxNzcwOTkzMTQxODQ5LCJpYXQiOjE3NzA5OTMxNDEsImV4cCI6MTc3MzU4NTE0MX0.eFCMTFc3b04IeExsiTH772f63yh8YAq6czUy1bxoHqc	2026-03-15 14:32:21.85	2026-02-13 14:32:21.852	2026-02-13 14:32:21.852
4	2	Chrome on Windows	desktop	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIsInRzIjoxNzcwOTkzMTQ2Mzg2LCJpYXQiOjE3NzA5OTMxNDYsImV4cCI6MTc3MzU4NTE0Nn0.Ccb96EiXgxk5ZMbxfBtTpq6qGv_rbyeIay4DZ0DOXcU	2026-03-15 15:07:22.736	2026-02-13 14:32:26.387	2026-02-13 15:07:22.736
6	1	Firefox on Windows	desktop	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsInRzIjoxNzcxMzAzNDU2MTUxLCJpYXQiOjE3NzEzMDM0NTYsImV4cCI6MTc3Mzg5NTQ1Nn0.pzWW2r7c37iWmUS0rn9qp7oAfLE5I10uwcsZTSm40r0	2026-03-19 06:34:45.355	2026-02-17 04:44:16.17	2026-02-17 06:34:45.355
7	3	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjMsInRzIjoxNzcyMDIxMzY0MjgxLCJpYXQiOjE3NzIwMjEzNjQsImV4cCI6MTc3NDYxMzM2NH0.DO1_5bSeIuZkmnLCRV7Z4dWITs6JslkwGmWFG91Bsck	2026-03-27 12:09:24.285	2026-02-25 12:09:24.286	2026-02-25 12:09:24.286
2	1	Chrome on macOS	desktop	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsInRzIjoxNzcwOTkyMDYyNzEzLCJpYXQiOjE3NzA5OTIwNjIsImV4cCI6MTc3MzU4NDA2Mn0.X1apJvmuBKsyMh-PTRrtfh3IuCCzks8OwyAsl1t9RXk	2026-03-17 08:32:17.863	2026-02-13 14:14:22.714	2026-02-15 08:32:17.863
8	3	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjMsInRzIjoxNzcyMDIxMzY0MzU2LCJpYXQiOjE3NzIwMjEzNjQsImV4cCI6MTc3NDYxMzM2NH0.y3L_yAhsohS3AcbROornf2D9HAOzEnJM2VQPn3vbFNs	2026-03-27 12:09:24.356	2026-02-25 12:09:24.356	2026-02-25 12:09:24.356
9	4	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInRzIjoxNzcyMDIxMzY0NDM2LCJpYXQiOjE3NzIwMjEzNjQsImV4cCI6MTc3NDYxMzM2NH0.JE-Q8qrprLXeF6MVFw6D-gk-Wf9ttlkZjU_1n-KXKH4	2026-03-27 12:09:24.436	2026-02-25 12:09:24.437	2026-02-25 12:09:24.437
11	5	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjUsInRzIjoxNzcyMDIxMzY0NTc5LCJpYXQiOjE3NzIwMjEzNjQsImV4cCI6MTc3NDYxMzM2NH0.VTWlzeiYDEJkLVnGhg-PGe1zrbGwnup9AE4gj6w5Rp0	2026-03-27 12:09:24.58	2026-02-25 12:09:24.58	2026-02-25 12:09:24.58
12	5	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjUsInRzIjoxNzcyMDIxMzY0NjQzLCJpYXQiOjE3NzIwMjEzNjQsImV4cCI6MTc3NDYxMzM2NH0.XuK6rPxjlK6cj4ewu5mqQ8G63Ip5ccALxL7kgagaiOc	2026-03-27 12:09:24.644	2026-02-25 12:09:24.644	2026-02-25 12:09:24.644
13	6	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjYsInRzIjoxNzcyMDIxMzY0NzE2LCJpYXQiOjE3NzIwMjEzNjQsImV4cCI6MTc3NDYxMzM2NH0.n3vMFUNG-QVwPkzPbRSfzxZRciRnCKws0VEz4Z_ClL0	2026-03-27 12:09:24.716	2026-02-25 12:09:24.716	2026-02-25 12:09:24.716
14	6	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjYsInRzIjoxNzcyMDIxMzY0NzgzLCJpYXQiOjE3NzIwMjEzNjQsImV4cCI6MTc3NDYxMzM2NH0.qd5JjBlKASfRog4ZsdRhxYN27QHbw-ZHXMjW6BfXzgs	2026-03-27 12:09:24.783	2026-02-25 12:09:24.783	2026-02-25 12:09:24.783
15	7	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjcsInRzIjoxNzcyMDIxMzY0ODU5LCJpYXQiOjE3NzIwMjEzNjQsImV4cCI6MTc3NDYxMzM2NH0.vnB5T6oP-n_lQ7_qxV3cXlgiHGlK97Pml0V22HGCPc8	2026-03-27 12:09:24.859	2026-02-25 12:09:24.859	2026-02-25 12:09:24.859
16	7	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjcsInRzIjoxNzcyMDIxMzY0OTIzLCJpYXQiOjE3NzIwMjEzNjQsImV4cCI6MTc3NDYxMzM2NH0.m6HYy6vP3L4ttb-lIy7bnfzRlMj3pQ8Y7ml6Q5wRRoA	2026-03-27 12:09:24.923	2026-02-25 12:09:24.924	2026-02-25 12:09:24.924
17	8	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjgsInRzIjoxNzcyMDIxMzY0OTkxLCJpYXQiOjE3NzIwMjEzNjQsImV4cCI6MTc3NDYxMzM2NH0.D_kqD9XHCmpsgaqRoX7vlJRIAyt5ugOHSgQDNLOUEYc	2026-03-27 12:09:24.991	2026-02-25 12:09:24.992	2026-02-25 12:09:24.992
18	8	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjgsInRzIjoxNzcyMDIxMzY1MDU3LCJpYXQiOjE3NzIwMjEzNjUsImV4cCI6MTc3NDYxMzM2NX0.nLC_LfduCodvANQhcM-CO17N7T3XDVidN1b0UZ_AYEU	2026-03-27 12:09:25.057	2026-02-25 12:09:25.057	2026-02-25 12:09:25.057
19	9	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjksInRzIjoxNzcyMDIxMzY1MTI2LCJpYXQiOjE3NzIwMjEzNjUsImV4cCI6MTc3NDYxMzM2NX0.hRvEALMDijMoGK6obA6ZWrnwn-rsg_K-5KfT8R8IXL4	2026-03-27 12:09:25.126	2026-02-25 12:09:25.126	2026-02-25 12:09:25.126
20	9	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjksInRzIjoxNzcyMDIxMzY1MTk2LCJpYXQiOjE3NzIwMjEzNjUsImV4cCI6MTc3NDYxMzM2NX0.UyxbbdmVTvbL6RvFsNUzdg5ECfUzcaAaZE27SpSaHjo	2026-03-27 12:09:25.196	2026-02-25 12:09:25.196	2026-02-25 12:09:25.196
21	10	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEwLCJ0cyI6MTc3MjAyMTM2NTI2NywiaWF0IjoxNzcyMDIxMzY1LCJleHAiOjE3NzQ2MTMzNjV9.fGyNz-kGZl0ErpikU2h83ul6R2rHxR058Bs8spH46Aw	2026-03-27 12:09:25.267	2026-02-25 12:09:25.267	2026-02-25 12:09:25.267
22	10	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEwLCJ0cyI6MTc3MjAyMTM2NTMzNCwiaWF0IjoxNzcyMDIxMzY1LCJleHAiOjE3NzQ2MTMzNjV9.kk8wuzca9sitR_iJ9Fs7e6kM-sQXEdA_W1dLkn2VuOU	2026-03-27 12:09:25.334	2026-02-25 12:09:25.335	2026-02-25 12:09:25.335
23	11	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjExLCJ0cyI6MTc3MjAyMTM2NTQwNSwiaWF0IjoxNzcyMDIxMzY1LCJleHAiOjE3NzQ2MTMzNjV9.Fe6ZAQvd7-kDsSUB8AcPZlkAToLa_wOJREM4jJv7V7I	2026-03-27 12:09:25.406	2026-02-25 12:09:25.406	2026-02-25 12:09:25.406
24	11	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjExLCJ0cyI6MTc3MjAyMTM2NTQ3MywiaWF0IjoxNzcyMDIxMzY1LCJleHAiOjE3NzQ2MTMzNjV9.2uRZI3XKjXwHkAOjZs1ahUkk9wzHeugvHEp_k0wnybE	2026-03-27 12:09:25.473	2026-02-25 12:09:25.473	2026-02-25 12:09:25.473
25	12	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyLCJ0cyI6MTc3MjAyMTQyODk4MCwiaWF0IjoxNzcyMDIxNDI4LCJleHAiOjE3NzQ2MTM0Mjh9.Dca8bsbHKXQP-gZdonm0SBSujdWXiSmqjfXk8kQ5ahM	2026-03-27 12:10:28.98	2026-02-25 12:10:28.982	2026-02-25 12:10:28.982
26	12	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyLCJ0cyI6MTc3MjAyMTQyOTA1NiwiaWF0IjoxNzcyMDIxNDI5LCJleHAiOjE3NzQ2MTM0Mjl9.lkIGE_UXpahj7mBumKIQhIPj4iGDlaS7uI_8NeWu45U	2026-03-27 12:10:29.056	2026-02-25 12:10:29.057	2026-02-25 12:10:29.057
27	1	Chrome on macOS	desktop	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsInRzIjoxNzcyMjY1ODYzODcxLCJpYXQiOjE3NzIyNjU4NjMsImV4cCI6MTc3NDg1Nzg2M30.bug9az1ufbN-Mv3uHRCmbEBzhwZEy9v5SmoB2WxHoAs	2026-03-30 10:30:41.996	2026-02-28 08:04:23.88	2026-02-28 10:30:41.996
\.


--
-- Data for Name: Setting; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Setting" (key, value, updated_at) FROM stdin;
ignore_mode	false	2026-02-25 12:09:21.529
last_collection	2026-02-25T12:09:21.562Z	2026-02-25 12:09:21.562
\.


--
-- Data for Name: ShopItem; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."ShopItem" (id, name, description, price, category, image_url, is_active, created_at, updated_at, effect, icon) FROM stdin;
1	Double Click Power	Your clicks are worth 2x points!	500	clicker	\N	t	2026-02-18 09:34:39.213	2026-02-18 09:34:39.213	clickPower:2	✌️
2	Auto-Clicker Boost	Auto-clicker generates +1 point/second	1000	clicker	\N	t	2026-02-18 09:34:39.213	2026-02-18 09:34:39.213	autoClickBoost:1	🤖
3	Custom Goose Emoji	Set a custom emoji for the digital goose	300	cosmetic	\N	t	2026-02-18 09:34:39.213	2026-02-18 09:34:39.213	customGoose	🦆
4	Neon Goose Effect	Add a glowing neon effect to the goose	250	cosmetic	\N	t	2026-02-18 09:34:39.213	2026-02-18 09:34:39.213	neonGoose	✨
5	Coolness Multiplier	All point gains multiplied by 1.5x	2000	premium	\N	t	2026-02-18 09:34:39.213	2026-02-18 09:34:39.213	multiplier:1.5	⭐
6	Instant Points Bundle	Get 100 points instantly	100	consumable	\N	t	2026-02-18 09:34:39.213	2026-02-18 09:34:39.213	instantPoints:100	💎
7	Golden Mushroom	Special mushroom skin for clicker	750	cosmetic	\N	t	2026-02-18 09:34:39.213	2026-02-18 09:34:39.213	goldenMushroom	🍄
8	Speed Upgrades	Auto-clicker generates +2 points/second	3000	clicker	\N	t	2026-02-18 09:34:39.213	2026-02-18 09:34:39.213	autoClickBoost:2	⚡
\.


--
-- Data for Name: Stock; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Stock" (name, avatar, price, coolness_score, shares, min_price, max_price, price_history) FROM stdin;
Cam	🥔	1000	10000	1000	500	5000	[{"timestamp":1770991720629,"price":1000},{"timestamp":1770991750629,"price":1000}]
Orlando	🌙	1007	10067	1000	504	5035	[{"timestamp":1770991720647,"price":1007},{"timestamp":1770991750647,"price":1007}]
Ashley	<:flooshies:1000736727259947069>	500	5000	1000	250	2500	[{"timestamp":1770991720652,"price":500},{"timestamp":1770991750652,"price":500}]
Average Hex	🌸	200	2000	1000	100	1000	[{"timestamp":1770991720656,"price":200},{"timestamp":1770991750656,"price":200}]
Temer3	🔧	180	1800	1000	90	900	[{"timestamp":1770991720660,"price":180},{"timestamp":1770991750660,"price":180}]
You	🌸	147	1467	1000	74	735	[{"timestamp":1770991720666,"price":147},{"timestamp":1770991750666,"price":147}]
美香	🏍️	2147	21467	1000	1074	10735	[{"timestamp":1770991720669,"price":2147},{"timestamp":1770991750669,"price":2147}]
Chang'Yi	<:sadcat:1000736705197907968>	137	1367	1000	69	685	[{"timestamp":1770991720671,"price":137},{"timestamp":1770991750671,"price":137}]
RIUM+	🎮	50	501	1000	25	250	[{"timestamp":1770991720675,"price":50},{"timestamp":1770991750675,"price":50}]
Goopsworthy	🍄	67	667	1000	34	335	[{"timestamp":1770991720679,"price":67},{"timestamp":1770991750679,"price":67}]
Blair	🎮	90	900	1000	45	450	[{"timestamp":1770991720681,"price":90},{"timestamp":1770991750681,"price":90}]
Others	✨	50	500	1000	25	250	[{"timestamp":1770991720685,"price":50},{"timestamp":1770991750685,"price":50}]
\.


--
-- Data for Name: SubscriptionPayment; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."SubscriptionPayment" (id, user_id, tier_name, amount, currency, payment_method, status, paypal_order_id, paypal_txn_id, bank_ref, admin_notes, created_at, updated_at, completed_at) FROM stdin;
\.


--
-- Data for Name: SyncLog; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."SyncLog" (id, user_id, device_id, sync_type, status, items_synced, conflicts_found, conflicts_resolved, error_message, started_at, completed_at) FROM stdin;
1	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-17 07:41:38.049	2026-02-17 07:41:38.06
2	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 09:46:16.051	2026-02-18 09:46:16.063
3	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 09:51:16.287	2026-02-18 09:51:16.299
4	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 09:56:16.284	2026-02-18 09:56:16.289
5	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:01:16.282	2026-02-18 10:01:16.29
6	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:06:16.728	2026-02-18 10:06:16.736
7	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:11:17.315	2026-02-18 10:11:17.324
8	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:16:17.877	2026-02-18 10:16:17.887
9	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:21:18.581	2026-02-18 10:21:18.586
10	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:26:18.804	2026-02-18 10:26:18.815
11	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:31:19.305	2026-02-18 10:31:19.33
12	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:40:43.34	2026-02-18 10:40:43.353
13	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:46:37.729	2026-02-18 10:46:37.746
14	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:47:03.577	2026-02-18 10:47:03.583
15	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:47:04.275	2026-02-18 10:47:04.288
16	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:50:32.104	2026-02-18 10:50:32.111
17	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:50:36.613	2026-02-18 10:50:36.621
18	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-21 07:28:30.951	2026-02-21 07:28:30.96
19	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-21 07:33:30.844	2026-02-21 07:33:30.856
20	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-21 07:38:31.639	2026-02-21 07:38:31.656
21	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-21 07:50:29.237	2026-02-21 07:50:29.242
22	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-21 07:56:19.697	2026-02-21 07:56:19.707
23	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-22 08:03:11.638	2026-02-22 08:03:11.661
24	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-22 08:08:12.057	2026-02-22 08:08:12.069
25	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-22 08:13:12.563	2026-02-22 08:13:12.572
26	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-22 08:18:12.563	2026-02-22 08:18:12.568
27	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-22 08:21:00.084	2026-02-22 08:21:00.091
28	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-22 08:49:54.265	2026-02-22 08:49:54.289
29	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-22 08:50:06.898	2026-02-22 08:50:06.907
30	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-22 08:50:20.748	2026-02-22 08:50:20.755
31	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-22 08:50:47.106	2026-02-22 08:50:47.115
32	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-22 09:28:26.17	2026-02-22 09:28:26.182
33	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-22 09:32:44.936	2026-02-22 09:32:44.942
34	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-22 09:32:49.686	2026-02-22 09:32:49.694
35	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-22 09:36:19.766	2026-02-22 09:36:19.934
36	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-22 09:39:07.029	2026-02-22 09:39:07.043
37	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-22 09:40:40.931	2026-02-22 09:40:40.936
38	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-23 10:45:08.033	2026-02-23 10:45:08.053
39	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-23 10:50:08.56	2026-02-23 10:50:08.569
40	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-23 10:55:08.821	2026-02-23 10:55:08.828
41	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-23 11:12:48.478	2026-02-23 11:12:48.484
42	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-23 11:12:51.466	2026-02-23 11:12:51.47
43	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-23 11:16:47.688	2026-02-23 11:16:47.695
44	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-23 11:16:49.592	2026-02-23 11:16:49.601
45	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-23 11:17:16.193	2026-02-23 11:17:16.201
46	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-23 11:17:18.488	2026-02-23 11:17:18.498
47	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-23 11:31:20.172	2026-02-23 11:31:20.179
48	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-23 11:31:22.287	2026-02-23 11:31:22.296
49	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-23 11:31:30.729	2026-02-23 11:31:30.736
50	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-25 15:37:12.959	2026-02-25 15:37:12.971
51	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-25 15:37:32.598	2026-02-25 15:37:32.606
52	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:12:28.424	2026-02-26 06:12:28.432
53	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:12:39.081	2026-02-26 06:12:39.085
54	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:13:16.319	2026-02-26 06:13:16.472
55	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:14:09.986	2026-02-26 06:14:09.997
56	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:14:12.075	2026-02-26 06:14:12.08
57	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:14:16.76	2026-02-26 06:14:16.766
58	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:14:56.183	2026-02-26 06:14:56.189
59	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:15:01.534	2026-02-26 06:15:01.54
60	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:15:09.687	2026-02-26 06:15:09.693
61	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:15:14.354	2026-02-26 06:15:14.362
62	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:16:00.673	2026-02-26 06:16:00.683
63	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:21:00.72	2026-02-26 06:21:00.725
64	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:26:01.577	2026-02-26 06:26:01.585
65	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:31:02.075	2026-02-26 06:31:02.08
66	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:36:02.877	2026-02-26 06:36:02.884
67	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:41:03.11	2026-02-26 06:41:03.117
68	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:46:03.88	2026-02-26 06:46:03.885
69	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:51:04.455	2026-02-26 06:51:04.463
70	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:56:05.254	2026-02-26 06:56:05.259
71	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 07:01:05.295	2026-02-26 07:01:05.3
72	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 07:06:06.205	2026-02-26 07:06:06.21
73	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 07:11:06.328	2026-02-26 07:11:06.335
74	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 07:16:21.093	2026-02-26 07:16:21.098
75	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 07:21:21.066	2026-02-26 07:21:21.077
76	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 07:26:21.046	2026-02-26 07:26:21.051
77	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 07:26:52.48	2026-02-26 07:26:52.5
78	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 07:31:52.463	2026-02-26 07:31:52.469
79	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 07:36:52.892	2026-02-26 07:36:52.897
80	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 07:41:53.78	2026-02-26 07:41:53.785
81	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 07:46:53.918	2026-02-26 07:46:53.924
82	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 07:51:53.906	2026-02-26 07:51:53.912
83	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 07:56:53.913	2026-02-26 07:56:53.919
84	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 08:01:53.917	2026-02-26 08:01:53.922
85	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 08:06:53.912	2026-02-26 08:06:53.918
86	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 08:11:53.924	2026-02-26 08:11:53.929
87	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 08:16:54.775	2026-02-26 08:16:54.78
88	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 08:21:55.19	2026-02-26 08:21:55.195
89	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 08:26:55.488	2026-02-26 08:26:55.493
90	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 08:31:55.704	2026-02-26 08:31:55.711
91	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 10:20:57.993	2026-02-26 10:20:58.003
92	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 10:25:58.197	2026-02-26 10:25:58.205
93	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-28 03:12:10.607	2026-02-28 03:12:10.63
94	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 08:04:23.943	2026-02-28 08:04:23.96
95	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 08:04:34.845	2026-02-28 08:04:34.851
96	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 08:04:43.934	2026-02-28 08:04:43.939
97	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 08:05:08.715	2026-02-28 08:05:08.722
98	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 08:10:08.952	2026-02-28 08:10:08.958
99	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 08:15:44.251	2026-02-28 08:15:44.262
100	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 08:43:55.058	2026-02-28 08:43:55.063
101	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 08:48:20.061	2026-02-28 08:48:20.07
102	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 08:53:55.06	2026-02-28 08:53:55.07
103	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 08:58:55.115	2026-02-28 08:58:55.123
104	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 09:03:56.092	2026-02-28 09:03:56.105
105	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 09:04:27.365	2026-02-28 09:04:27.371
106	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 09:05:07.856	2026-02-28 09:05:07.867
107	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 09:10:08.086	2026-02-28 09:10:08.091
108	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 09:15:08.098	2026-02-28 09:15:08.111
109	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 09:17:26.62	2026-02-28 09:17:26.631
110	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 09:17:36.689	2026-02-28 09:17:36.693
111	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 09:18:48.254	2026-02-28 09:18:48.261
112	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 09:23:09.703	2026-02-28 09:23:09.717
113	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 09:28:10.107	2026-02-28 09:28:10.121
114	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 09:33:10.09	2026-02-28 09:33:10.096
115	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 09:38:10.079	2026-02-28 09:38:10.084
116	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 09:43:10.069	2026-02-28 09:43:10.074
117	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 09:48:10.086	2026-02-28 09:48:10.095
118	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 09:53:10.075	2026-02-28 09:53:10.081
119	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 09:58:10.116	2026-02-28 09:58:10.126
120	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 10:03:09.727	2026-02-28 10:03:09.735
121	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 10:08:10.093	2026-02-28 10:08:10.099
122	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 10:14:06.121	2026-02-28 10:14:06.128
123	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 10:19:06.098	2026-02-28 10:19:06.103
124	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 10:23:10.108	2026-02-28 10:23:10.118
125	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 10:29:06.144	2026-02-28 10:29:06.15
126	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 10:34:06.107	2026-02-28 10:34:06.118
127	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-03-01 03:51:11.781	2026-03-01 03:51:11.788
128	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-01 13:26:08.006	2026-03-01 13:26:08.011
129	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-01 13:26:10.161	2026-03-01 13:26:10.166
130	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-03 09:41:38.312	2026-03-03 09:41:38.319
131	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-03 09:42:00.456	2026-03-03 09:42:00.461
132	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-03 10:01:51.603	2026-03-03 10:01:51.611
133	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-03-04 14:22:48.401	2026-03-04 14:22:48.416
134	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-03-04 14:23:04.177	2026-03-04 14:23:04.182
\.


--
-- Data for Name: Theme; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Theme" (id, user_id, preset, custom_colors, dark_mode, high_contrast, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: Ticket; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Ticket" (id, title, description, status, response, creator_id, created_at, updated_at, type, priority, tags, category, dependencies, is_deleted) FROM stdin;
1	test	test	pending	\N	\N	2026-02-14 11:11:41.689	2026-02-14 11:11:41.689	feature	low	\N	\N	\N	t
2	Oled Mode	We have custom themes but no oled mode. Replace the sunset theme with Oled theme and use full blacks to reduce burn in.	completed	Replaced sunset theme with OLED theme using true blacks (#000000) for burn-in reduction	creator-1771212178779-gz8u15y	2026-02-16 03:25:07.959	2026-02-16 03:25:07.959	feature	medium	\N	\N	\N	f
3	Dark mode review	There are a bunch of components that dont listen to dark mode. please review all the vue models	completed	Reviewed and fixed dark mode support across Vue components. Updated 78 files to use CSS variables instead of hardcoded colors, and removed unnecessary dark mode overrides from 38 files. Components now properly respond to dark mode state changes via theme CSS variables (--theme-background, --theme-text, --theme-primary, --theme-secondary, --theme-accent, --theme-card-bg). All changes deployed.	creator-1771212178779-gz8u15y	2026-02-16 03:25:44.31	2026-02-16 03:25:44.31	feature	medium	\N	\N	\N	f
4	Nav Bar updates	The breadcrumbs could be integrated into the nav bar so it doesnt appear as a separate bunch of cards. this should make the design clearer	completed	Integrated breadcrumbs into the nav bar (Ticket #4)\n\nChanges made:\n- Modified Router.vue to include breadcrumb logic and display\n- Added Router-breadcrumb.css for integrated breadcrumb styling  \n- Removed separate Breadcrumb component from MainApp.vue\n- Breadcrumbs now display inline within the nav bar instead of as separate cards\n- Maintained all existing breadcrumb functionality (icons, separators, truncation)\n- Breadcrumbs are hidden on home page and in performance mode\n\nDeployment is in progress - the code changes are complete and the build is running.	creator-1771212178779-gz8u15y	2026-02-16 03:27:57.193	2026-02-16 03:27:57.193	feature	medium	\N	\N	\N	f
5	Remove all SQLite references	SQLite should be completely removed from the codebase. Remaining references to clean up:\n- scripts/migrate-sqlite-to-postgres.sh (can be archived/deleted)\n- scripts/archive/* directory contains sqlite-based scripts (consider deleting entire archive)\n\nAll main application code (server/src) no longer uses sqlite. Prisma schema uses postgres only. No sqlite dependencies in package.json.	completed	All SQLite features migrated to PostgreSQL. 9 files migrated (characters, shop, tickets, sync, search, reactions, farts, profiles, favorites). Added UserDevice and SyncLog models to Prisma schema. Removed better-sqlite3 dependencies. Cleanup done: scripts/archive-root/ removed. Build successful. Ready for testing.	mhear22	2026-02-16 22:40:12.249	2026-02-16 22:40:12.249	task	medium	\N	\N	\N	f
6	Add bow emoji button to navcontrols bar - plays sound on loop	User Orlando (bellicapelli) requested a button on the navcontrols bar that:\n\n- Plays the attached sound file on loop when clicked\n- Uses a bow emoji 🎀 as the icon\n\nThe sound file has been provided and should be added to the project.\n\nRequest from: Orlando in Discord\n\nAudio file saved to: frontend/public/audio/bow-button-sound.wav (401KB)	completed	Bow emoji button (🎀) has been added to the navcontrols bar. The button plays the bow-button-sound.wav file on loop when clicked, and can be toggled on/off. The audio file is in place, the button is properly wired to the useAudio composable's toggleBowSound function, and everything is working correctly. The feature includes proper ARIA labels, active state styling, and integrates seamlessly with the existing nav-controls bar.	discord	2026-02-18 10:15:09.316	2026-02-18 10:15:09.316	feature	maximum	\N	\N	\N	f
7	I18N translation	We have users who's primary language isnt english. Give people the ability to change the language to something else and have the whole site respect it. Start with English, Chinese, and Japanese.	completed	Implemented full I18N translation support with English, Chinese (Simplified), and Japanese. Created translation files, language selector components, and integrated vue-i18n. Language preference persists in localStorage and auto-detects browser locale. Build successful and ready for deployment.	creator-1771079368671-b1btyc3	2026-02-21 07:35:42.366	2026-02-21 07:35:42.366	feature	medium	\N	\N	\N	f
8	i18n translations update	Please allow overwriting of the auto detected language in settings and allow users to set their own.\n\nAlso make sure that there is a US and AU versions of english.	completed	Implemented i18n language settings feature - users can now manually override auto-detected language in Settings. Added browser language detection, manual override UI, reset to auto-detect option, and backward compatibility support.	creator-1771748431634-0ns0o10	2026-02-22 08:22:38.651	2026-02-22 08:22:38.651	feature	medium	\N	\N	\N	f
15	Test Ticket Auth Check	This ticket tests auth	pending	\N	test-user-123	2026-02-25 12:09:21.713	2026-02-25 12:09:21.713	feature	medium	\N	\N	\N	t
14	Test Ticket to Delete	This ticket will be deleted	pending	\N	test-user-123	2026-02-25 12:09:21.68	2026-02-25 12:09:21.68	feature	medium	\N	\N	\N	t
9	Test Ticket for Update	This ticket will be updated	completed		test-user-123	2026-02-25 12:08:23.8	2026-02-25 12:08:23.8	feature	medium	\N	\N	\N	f
10	Test Ticket to Delete	This ticket will be deleted	completed		test-user-123	2026-02-25 12:08:23.903	2026-02-25 12:08:23.903	feature	medium	\N	\N	\N	f
11	Test Ticket	This is a test ticket description	completed		test-user-123	2026-02-25 12:09:21.266	2026-02-25 12:09:21.266	feature	medium	\N	\N	\N	f
12	Test Ticket No Description	Auto-generated description	completed		\N	2026-02-25 12:09:21.341	2026-02-25 12:09:21.341	feature	medium	\N	\N	\N	f
13	Updated Title	Updated description	completed		test-user-123	2026-02-25 12:09:21.596	2026-02-25 12:09:21.596	feature	medium	\N	\N	\N	f
16	Add Vibe Coding Instructions Page	Create a new page for instructions on how to vibe code.\n\n**Features:**\n- Model selector: Opus, Sonnet, GLM 5, GPT Codex, Gemini, Local models\n- Tooling recommendations for CLI (Claude Code, Opencode, Codex CLI, Copilot CLI)\n- Tooling recommendations for GUI (Claude Cowork, Codex app, Antigravity, Cursor, Z Code)\n- Show best approach for each model/tool combination\n\n**Examples of relationships:**\n- Opus/Sonnet: Best through Claude Code or Claude Cowork (first class)\n- Claude Code: Opus/Sonnet first class, GLM 5 works with asterisk\n- Cursor: Supports most models but not first class approach\n\n**Requested by:** Mika (mhear22)	completed	Created VibeCodingPage.vue with model selector, CLI/GUI tool recommendations, and quick reference table. Deployed and live at /vibe-coding	mhear22	2026-02-26 06:02:14.579	2026-02-26 06:02:14.579	feature	high	\N	\N	\N	f
17	Mobile support	The site currently doesnt have very stable mobile support. the nav doesnt work (closes when you try and pick a page) and the app doesnt have the same featureset as desktop. please update the app to be consistent between the two	completed	Fixed mobile navigation issue. Added delayed menu closing to allow Vue Router navigation to complete, improved z-index stacking for backdrop, and added touch-action CSS properties to prevent double-tap zoom issues on mobile.	creator-1771079368671-b1btyc3	2026-03-03 10:04:06.195	2026-03-03 10:04:06.195	feature	medium	\N	\N	\N	f
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."User" (id, email, password_hash, display_name, avatar_url, banner_url, bio, status, show_email, show_joined_date, is_deleted, discord_id, discord_username, discord_discriminator, discord_avatar, created_at, updated_at, payment_method, subscription_end, subscription_start, subscription_status, subscription_tier) FROM stdin;
1	test@test.com	$2b$10$843EyFSRVXV2FOqQK0EQS.zlou9yJdDYERa17MQ5HSxYYD3PJRmJS	test	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-02-13 14:10:13.985	2026-02-13 14:10:13.985	\N	\N	\N	\N	\N
2	penguin@gmail.com	$2b$10$VEi1awP/za84sucXtzMDLuamGKKiq8FW1s/VEi.os/iSitBfw42/m	0riginal	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-02-13 14:32:21.838	2026-02-13 14:32:21.838	\N	\N	\N	\N	\N
3	test-auth-1772021364140@example.com	$2b$10$894fMSbnckcItzNycrHq/O24hnCcX08nAPRTLkp5wRpXcAigCZhtu	Test User	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-02-25 12:09:24.278	2026-02-25 12:09:24.278	\N	\N	\N	\N	\N
4	test-auth-expired-1772021364371@example.com	$2b$10$BMgr3O/SlLhGD2MBCF8.quImpmgV.wCSpWX.WEPI7eRXJr9l56NtK	Test User	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-02-25 12:09:24.434	2026-02-25 12:09:24.434	\N	\N	\N	\N	\N
5	test-optional-auth-1772021364515@example.com	$2b$10$4655osVpPL0wy9/CigUBE.AbIc9lTghfKCz0CU7ctjFQtFMs6KYGG	Test User	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-02-25 12:09:24.577	2026-02-25 12:09:24.577	\N	\N	\N	\N	\N
6	test-userid-match-1772021364652@example.com	$2b$10$yWLetAsKyho8LcmBpE/41ugTbzAoMMfy3FWTAaW0pZxqYLb9ZKvGi	Test User	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-02-25 12:09:24.713	2026-02-25 12:09:24.713	\N	\N	\N	\N	\N
7	test-userid-mismatch-1772021364787@example.com	$2b$10$cJqjw2x37pYmUyx6vRifLuVojl3bdKk9DnyDdn8UhSpYgGQ8EEj1O	Test User	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-02-25 12:09:24.85	2026-02-25 12:09:24.85	\N	\N	\N	\N	\N
8	test-userid-invalid-1772021364927@example.com	$2b$10$WfAUa2uOfR4qCTGCrVF6p.ndzbklkSFfAIcYjC2DPb7Iwg5HTFN82	Test User	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-02-25 12:09:24.989	2026-02-25 12:09:24.989	\N	\N	\N	\N	\N
9	test-userid-param-1772021365060@example.com	$2b$10$6J8IA.2iUQy/dmZiCNizL.VcgUTisLfuk1twUUAwnCTas.ILoNd4C	Test User	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-02-25 12:09:25.123	2026-02-25 12:09:25.123	\N	\N	\N	\N	\N
10	test-admin-1772021365200@example.com	$2b$10$EkTU.gQmSX42uu03ZNoBQuSanhqkLTdiT34X8XOLyWxd5m.BxzFFq	Test User	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-02-25 12:09:25.263	2026-02-25 12:09:25.263	\N	\N	\N	\N	\N
11	test-admin-future-1772021365339@example.com	$2b$10$tbUawRsXVfLfpiocTrMjYOcu0fwgwguGoCBSa1/wYbJUb3RPCQXnu	Test User	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-02-25 12:09:25.403	2026-02-25 12:09:25.403	\N	\N	\N	\N	\N
12	integration-test-1772021426963@example.com	$2b$10$mia6E4KHtbAv2R.9zz20P.anuFvIELOv76vWSgg2REvWyHUYd9gYq	\N	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-02-25 12:10:28.969	2026-02-25 12:10:28.969	\N	\N	\N	\N	\N
\.


--
-- Data for Name: UserDevice; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."UserDevice" (id, user_id, device_id, device_name, device_type, platform, last_sync, created_at, updated_at) FROM stdin;
3	1	device-1772265863889-3yumwewiu	Chrome	desktop	macOS	2026-02-28 10:34:06.115	2026-02-28 08:04:23.932	2026-02-28 10:34:06.115
2	1	device-1770991813972-a6ptnqrmx	Firefox	desktop	macOS	2026-03-03 10:01:51.609	2026-02-21 07:28:30.945	2026-03-03 10:01:51.609
1	1	device-1771153470412-j1elif1ye	Firefox	desktop	Linux	2026-03-04 14:23:04.18	2026-02-17 07:41:38.027	2026-03-04 14:23:04.18
\.


--
-- Data for Name: UserFartStats; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."UserFartStats" (id, user_id, total_farts, total_volume, avg_volume, max_volume, min_volume, first_fart, last_fart, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: UserPortfolio; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."UserPortfolio" (user_id, cash, holdings, transactions) FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
e3bbf79e-c337-423c-8b27-81b1b67d1c44	0e6ead4239ba1ad4f9a5dde403ea3f8155ec44ace7d5be20409b156070c95555	2026-02-13 14:09:10.033926+00	20260212144929_init	\N	\N	2026-02-13 14:09:09.505393+00	1
8c806edc-acc2-4a77-b269-0cb03facabf6	e9b3d9d647e80aef18137a9b37719e6e5400f2452ef206de3f6390df2fe8724e	2026-02-16 22:51:09.435198+00	20260216225109_add_sync_and_update_models	\N	\N	2026-02-16 22:51:09.364625+00	1
f330332e-0525-4401-bf72-0754cc80ada0	2b55aa8e91a7719fbd596baf71dad9b27a0c9b0207bdb9a0c97bb90208c18db3	2026-02-25 15:17:28.263339+00	20260225234000_add_datacenter_runs	\N	\N	2026-02-25 15:17:28.182325+00	1
8614cf61-eda3-4188-afee-688971969127	cff6d5bbeba77d48e8c5c3d5f8b6bc5a8b931b4d633cea8e552dba596a815ca8	2026-02-26 20:56:33.052023+00	20260226205632_add_subscription_system	\N	\N	2026-02-26 20:56:32.972909+00	1
\.


--
-- Name: Achievement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."Achievement_id_seq"', 1, false);


--
-- Name: Activity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."Activity_id_seq"', 1, false);


--
-- Name: CharacterMatch_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."CharacterMatch_id_seq"', 2, true);


--
-- Name: Character_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."Character_id_seq"', 1, false);


--
-- Name: Click_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."Click_id_seq"', 1, true);


--
-- Name: ConversationParticipant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."ConversationParticipant_id_seq"', 1, false);


--
-- Name: Conversation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."Conversation_id_seq"', 1, false);


--
-- Name: DailyChallenge_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."DailyChallenge_id_seq"', 1, false);


--
-- Name: DataCenterRun_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."DataCenterRun_id_seq"', 1, true);


--
-- Name: FartEvent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."FartEvent_id_seq"', 1, false);


--
-- Name: Favorite_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."Favorite_id_seq"', 1, false);


--
-- Name: GameStat_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."GameStat_id_seq"', 1, false);


--
-- Name: HighScore_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."HighScore_id_seq"', 1, false);


--
-- Name: MembershipTier_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."MembershipTier_id_seq"', 1, false);


--
-- Name: Message_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."Message_id_seq"', 1, false);


--
-- Name: ProcessingStats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."ProcessingStats_id_seq"', 1, false);


--
-- Name: Profile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."Profile_id_seq"', 1, false);


--
-- Name: PurchasedItem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."PurchasedItem_id_seq"', 1, false);


--
-- Name: Reaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."Reaction_id_seq"', 1, false);


--
-- Name: Session_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."Session_id_seq"', 27, true);


--
-- Name: ShopItem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."ShopItem_id_seq"', 8, true);


--
-- Name: SubscriptionPayment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."SubscriptionPayment_id_seq"', 1, false);


--
-- Name: SyncLog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."SyncLog_id_seq"', 134, true);


--
-- Name: Theme_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."Theme_id_seq"', 1, false);


--
-- Name: Ticket_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."Ticket_id_seq"', 17, true);


--
-- Name: UserDevice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."UserDevice_id_seq"', 3, true);


--
-- Name: UserFartStats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."UserFartStats_id_seq"', 1, false);


--
-- Name: User_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."User_id_seq"', 12, true);


--
-- Name: Achievement Achievement_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Achievement"
    ADD CONSTRAINT "Achievement_pkey" PRIMARY KEY (id);


--
-- Name: Activity Activity_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Activity"
    ADD CONSTRAINT "Activity_pkey" PRIMARY KEY (id);


--
-- Name: CharacterMatch CharacterMatch_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."CharacterMatch"
    ADD CONSTRAINT "CharacterMatch_pkey" PRIMARY KEY (id);


--
-- Name: Character Character_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Character"
    ADD CONSTRAINT "Character_pkey" PRIMARY KEY (id);


--
-- Name: Click Click_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Click"
    ADD CONSTRAINT "Click_pkey" PRIMARY KEY (id);


--
-- Name: ConversationParticipant ConversationParticipant_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."ConversationParticipant"
    ADD CONSTRAINT "ConversationParticipant_pkey" PRIMARY KEY (id);


--
-- Name: Conversation Conversation_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Conversation"
    ADD CONSTRAINT "Conversation_pkey" PRIMARY KEY (id);


--
-- Name: DailyChallenge DailyChallenge_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."DailyChallenge"
    ADD CONSTRAINT "DailyChallenge_pkey" PRIMARY KEY (id);


--
-- Name: DataCenterRun DataCenterRun_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."DataCenterRun"
    ADD CONSTRAINT "DataCenterRun_pkey" PRIMARY KEY (id);


--
-- Name: FartEvent FartEvent_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."FartEvent"
    ADD CONSTRAINT "FartEvent_pkey" PRIMARY KEY (id);


--
-- Name: Favorite Favorite_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Favorite"
    ADD CONSTRAINT "Favorite_pkey" PRIMARY KEY (id);


--
-- Name: GameStat GameStat_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."GameStat"
    ADD CONSTRAINT "GameStat_pkey" PRIMARY KEY (id);


--
-- Name: HighScore HighScore_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."HighScore"
    ADD CONSTRAINT "HighScore_pkey" PRIMARY KEY (id);


--
-- Name: MembershipTier MembershipTier_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."MembershipTier"
    ADD CONSTRAINT "MembershipTier_pkey" PRIMARY KEY (id);


--
-- Name: Message Message_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_pkey" PRIMARY KEY (id);


--
-- Name: ProcessingStats ProcessingStats_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."ProcessingStats"
    ADD CONSTRAINT "ProcessingStats_pkey" PRIMARY KEY (id);


--
-- Name: Profile Profile_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Profile"
    ADD CONSTRAINT "Profile_pkey" PRIMARY KEY (id);


--
-- Name: PurchasedItem PurchasedItem_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."PurchasedItem"
    ADD CONSTRAINT "PurchasedItem_pkey" PRIMARY KEY (id);


--
-- Name: Reaction Reaction_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Reaction"
    ADD CONSTRAINT "Reaction_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: Setting Setting_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Setting"
    ADD CONSTRAINT "Setting_pkey" PRIMARY KEY (key);


--
-- Name: ShopItem ShopItem_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."ShopItem"
    ADD CONSTRAINT "ShopItem_pkey" PRIMARY KEY (id);


--
-- Name: Stock Stock_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Stock"
    ADD CONSTRAINT "Stock_pkey" PRIMARY KEY (name);


--
-- Name: SubscriptionPayment SubscriptionPayment_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."SubscriptionPayment"
    ADD CONSTRAINT "SubscriptionPayment_pkey" PRIMARY KEY (id);


--
-- Name: SyncLog SyncLog_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."SyncLog"
    ADD CONSTRAINT "SyncLog_pkey" PRIMARY KEY (id);


--
-- Name: Theme Theme_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Theme"
    ADD CONSTRAINT "Theme_pkey" PRIMARY KEY (id);


--
-- Name: Ticket Ticket_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Ticket"
    ADD CONSTRAINT "Ticket_pkey" PRIMARY KEY (id);


--
-- Name: UserDevice UserDevice_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."UserDevice"
    ADD CONSTRAINT "UserDevice_pkey" PRIMARY KEY (id);


--
-- Name: UserFartStats UserFartStats_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."UserFartStats"
    ADD CONSTRAINT "UserFartStats_pkey" PRIMARY KEY (id);


--
-- Name: UserPortfolio UserPortfolio_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."UserPortfolio"
    ADD CONSTRAINT "UserPortfolio_pkey" PRIMARY KEY (user_id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Achievement_user_id_achievement_id_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "Achievement_user_id_achievement_id_key" ON public."Achievement" USING btree (user_id, achievement_id);


--
-- Name: Achievement_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Achievement_user_id_idx" ON public."Achievement" USING btree (user_id);


--
-- Name: Activity_activity_type_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Activity_activity_type_idx" ON public."Activity" USING btree (activity_type);


--
-- Name: Activity_recorded_at_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Activity_recorded_at_idx" ON public."Activity" USING btree (recorded_at);


--
-- Name: Activity_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Activity_user_id_idx" ON public."Activity" USING btree (user_id);


--
-- Name: Character_elo_rating_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Character_elo_rating_idx" ON public."Character" USING btree (elo_rating);


--
-- Name: ConversationParticipant_conversation_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "ConversationParticipant_conversation_id_idx" ON public."ConversationParticipant" USING btree (conversation_id);


--
-- Name: ConversationParticipant_conversation_id_user_id_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "ConversationParticipant_conversation_id_user_id_key" ON public."ConversationParticipant" USING btree (conversation_id, user_id);


--
-- Name: ConversationParticipant_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "ConversationParticipant_user_id_idx" ON public."ConversationParticipant" USING btree (user_id);


--
-- Name: Conversation_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Conversation_id_idx" ON public."Conversation" USING btree (id);


--
-- Name: DailyChallenge_date_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "DailyChallenge_date_idx" ON public."DailyChallenge" USING btree (date);


--
-- Name: DailyChallenge_user_id_challenge_type_date_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "DailyChallenge_user_id_challenge_type_date_key" ON public."DailyChallenge" USING btree (user_id, challenge_type, date);


--
-- Name: DailyChallenge_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "DailyChallenge_user_id_idx" ON public."DailyChallenge" USING btree (user_id);


--
-- Name: DataCenterRun_last_played_at_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "DataCenterRun_last_played_at_idx" ON public."DataCenterRun" USING btree (last_played_at);


--
-- Name: DataCenterRun_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "DataCenterRun_user_id_idx" ON public."DataCenterRun" USING btree (user_id);


--
-- Name: DataCenterRun_user_id_status_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "DataCenterRun_user_id_status_idx" ON public."DataCenterRun" USING btree (user_id, status);


--
-- Name: FartEvent_timestamp_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "FartEvent_timestamp_idx" ON public."FartEvent" USING btree ("timestamp");


--
-- Name: FartEvent_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "FartEvent_user_id_idx" ON public."FartEvent" USING btree (user_id);


--
-- Name: Favorite_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Favorite_user_id_idx" ON public."Favorite" USING btree (user_id);


--
-- Name: Favorite_user_id_item_type_item_id_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "Favorite_user_id_item_type_item_id_key" ON public."Favorite" USING btree (user_id, item_type, item_id);


--
-- Name: GameStat_game_type_stat_type_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "GameStat_game_type_stat_type_idx" ON public."GameStat" USING btree (game_type, stat_type);


--
-- Name: GameStat_recorded_at_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "GameStat_recorded_at_idx" ON public."GameStat" USING btree (recorded_at);


--
-- Name: GameStat_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "GameStat_user_id_idx" ON public."GameStat" USING btree (user_id);


--
-- Name: HighScore_game_type_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "HighScore_game_type_idx" ON public."HighScore" USING btree (game_type);


--
-- Name: HighScore_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "HighScore_user_id_idx" ON public."HighScore" USING btree (user_id);


--
-- Name: MembershipTier_name_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "MembershipTier_name_key" ON public."MembershipTier" USING btree (name);


--
-- Name: Message_conversation_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Message_conversation_id_idx" ON public."Message" USING btree (conversation_id);


--
-- Name: Message_created_at_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Message_created_at_idx" ON public."Message" USING btree (created_at);


--
-- Name: Message_sender_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Message_sender_id_idx" ON public."Message" USING btree (sender_id);


--
-- Name: ProcessingStats_date_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "ProcessingStats_date_key" ON public."ProcessingStats" USING btree (date);


--
-- Name: Profile_user_id_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "Profile_user_id_key" ON public."Profile" USING btree (user_id);


--
-- Name: PurchasedItem_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "PurchasedItem_user_id_idx" ON public."PurchasedItem" USING btree (user_id);


--
-- Name: PurchasedItem_user_id_item_id_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "PurchasedItem_user_id_item_id_key" ON public."PurchasedItem" USING btree (user_id, item_id);


--
-- Name: Reaction_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Reaction_user_id_idx" ON public."Reaction" USING btree (user_id);


--
-- Name: Reaction_user_id_target_type_target_id_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "Reaction_user_id_target_type_target_id_key" ON public."Reaction" USING btree (user_id, target_type, target_id);


--
-- Name: Session_token_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Session_token_idx" ON public."Session" USING btree (token);


--
-- Name: Session_token_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "Session_token_key" ON public."Session" USING btree (token);


--
-- Name: Session_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Session_user_id_idx" ON public."Session" USING btree (user_id);


--
-- Name: ShopItem_category_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "ShopItem_category_idx" ON public."ShopItem" USING btree (category);


--
-- Name: SubscriptionPayment_created_at_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "SubscriptionPayment_created_at_idx" ON public."SubscriptionPayment" USING btree (created_at);


--
-- Name: SubscriptionPayment_paypal_order_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "SubscriptionPayment_paypal_order_id_idx" ON public."SubscriptionPayment" USING btree (paypal_order_id);


--
-- Name: SubscriptionPayment_status_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "SubscriptionPayment_status_idx" ON public."SubscriptionPayment" USING btree (status);


--
-- Name: SubscriptionPayment_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "SubscriptionPayment_user_id_idx" ON public."SubscriptionPayment" USING btree (user_id);


--
-- Name: SyncLog_device_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "SyncLog_device_id_idx" ON public."SyncLog" USING btree (device_id);


--
-- Name: SyncLog_started_at_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "SyncLog_started_at_idx" ON public."SyncLog" USING btree (started_at);


--
-- Name: SyncLog_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "SyncLog_user_id_idx" ON public."SyncLog" USING btree (user_id);


--
-- Name: Theme_user_id_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "Theme_user_id_key" ON public."Theme" USING btree (user_id);


--
-- Name: Ticket_is_deleted_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Ticket_is_deleted_idx" ON public."Ticket" USING btree (is_deleted);


--
-- Name: Ticket_priority_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Ticket_priority_idx" ON public."Ticket" USING btree (priority);


--
-- Name: Ticket_status_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Ticket_status_idx" ON public."Ticket" USING btree (status);


--
-- Name: Ticket_type_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Ticket_type_idx" ON public."Ticket" USING btree (type);


--
-- Name: UserDevice_device_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "UserDevice_device_id_idx" ON public."UserDevice" USING btree (device_id);


--
-- Name: UserDevice_device_id_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "UserDevice_device_id_key" ON public."UserDevice" USING btree (device_id);


--
-- Name: UserDevice_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "UserDevice_user_id_idx" ON public."UserDevice" USING btree (user_id);


--
-- Name: UserFartStats_user_id_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "UserFartStats_user_id_key" ON public."UserFartStats" USING btree (user_id);


--
-- Name: User_email_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "User_email_idx" ON public."User" USING btree (email);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_subscription_status_subscription_end_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "User_subscription_status_subscription_end_idx" ON public."User" USING btree (subscription_status, subscription_end);


--
-- Name: Achievement Achievement_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Achievement"
    ADD CONSTRAINT "Achievement_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Activity Activity_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Activity"
    ADD CONSTRAINT "Activity_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CharacterMatch CharacterMatch_character_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."CharacterMatch"
    ADD CONSTRAINT "CharacterMatch_character_id_fkey" FOREIGN KEY (character_id) REFERENCES public."Character"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: CharacterMatch CharacterMatch_voter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."CharacterMatch"
    ADD CONSTRAINT "CharacterMatch_voter_id_fkey" FOREIGN KEY (voter_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: CharacterMatch CharacterMatch_winner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."CharacterMatch"
    ADD CONSTRAINT "CharacterMatch_winner_id_fkey" FOREIGN KEY (winner_id) REFERENCES public."Character"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ConversationParticipant ConversationParticipant_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."ConversationParticipant"
    ADD CONSTRAINT "ConversationParticipant_conversation_id_fkey" FOREIGN KEY (conversation_id) REFERENCES public."Conversation"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: DailyChallenge DailyChallenge_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."DailyChallenge"
    ADD CONSTRAINT "DailyChallenge_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: DataCenterRun DataCenterRun_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."DataCenterRun"
    ADD CONSTRAINT "DataCenterRun_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Favorite Favorite_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Favorite"
    ADD CONSTRAINT "Favorite_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: GameStat GameStat_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."GameStat"
    ADD CONSTRAINT "GameStat_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: HighScore HighScore_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."HighScore"
    ADD CONSTRAINT "HighScore_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Message Message_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_conversation_id_fkey" FOREIGN KEY (conversation_id) REFERENCES public."Conversation"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Message Message_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_sender_id_fkey" FOREIGN KEY (sender_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Profile Profile_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Profile"
    ADD CONSTRAINT "Profile_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PurchasedItem PurchasedItem_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."PurchasedItem"
    ADD CONSTRAINT "PurchasedItem_item_id_fkey" FOREIGN KEY (item_id) REFERENCES public."ShopItem"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Reaction Reaction_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Reaction"
    ADD CONSTRAINT "Reaction_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Session Session_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SubscriptionPayment SubscriptionPayment_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."SubscriptionPayment"
    ADD CONSTRAINT "SubscriptionPayment_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Theme Theme_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Theme"
    ADD CONSTRAINT "Theme_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UserDevice UserDevice_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."UserDevice"
    ADD CONSTRAINT "UserDevice_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UserFartStats UserFartStats_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."UserFartStats"
    ADD CONSTRAINT "UserFartStats_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: UserPortfolio UserPortfolio_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."UserPortfolio"
    ADD CONSTRAINT "UserPortfolio_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict iql2trgsvAQ3FxCtbSIcXiddqto5SM5q7NI8kSqs8G1lgfcdIxMaiORbUhJTI9i

