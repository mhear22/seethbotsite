--
-- PostgreSQL database dump
--

\restrict r4adHgGIJqUCDLcY5xRRBJcDIP6BUtCYEPeg5zEPoyCAHocPfJ7n62XRgPD4ls6

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.10 (Debian 16.10-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Achievement; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Achievement" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    achievement_id text NOT NULL,
    achievement_name text NOT NULL,
    description text NOT NULL,
    icon text,
    unlocked_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Achievement" OWNER TO seethbot;

--
-- Name: Achievement_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."Achievement_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Achievement_id_seq" OWNER TO seethbot;

--
-- Name: Achievement_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."Achievement_id_seq" OWNED BY public."Achievement".id;


--
-- Name: Activity; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Activity" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    user_name text,
    user_avatar text,
    activity_type text NOT NULL,
    description text NOT NULL,
    metadata text,
    points_change integer DEFAULT 0 NOT NULL,
    game_type text,
    recorded_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Activity" OWNER TO seethbot;

--
-- Name: Activity_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."Activity_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Activity_id_seq" OWNER TO seethbot;

--
-- Name: Activity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."Activity_id_seq" OWNED BY public."Activity".id;


--
-- Name: Character; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Character" (
    id integer NOT NULL,
    name text NOT NULL,
    image_url text,
    elo_rating integer DEFAULT 1200 NOT NULL,
    wins integer DEFAULT 0 NOT NULL,
    losses integer DEFAULT 0 NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Character" OWNER TO seethbot;

--
-- Name: CharacterMatch; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."CharacterMatch" (
    id integer NOT NULL,
    character_id integer NOT NULL,
    opponent_id integer NOT NULL,
    winner_id integer NOT NULL,
    voter_id integer NOT NULL,
    voted_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."CharacterMatch" OWNER TO seethbot;

--
-- Name: CharacterMatch_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."CharacterMatch_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."CharacterMatch_id_seq" OWNER TO seethbot;

--
-- Name: CharacterMatch_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."CharacterMatch_id_seq" OWNED BY public."CharacterMatch".id;


--
-- Name: Character_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."Character_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Character_id_seq" OWNER TO seethbot;

--
-- Name: Character_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."Character_id_seq" OWNED BY public."Character".id;


--
-- Name: Click; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Click" (
    id integer NOT NULL,
    count integer DEFAULT 0 NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Click" OWNER TO seethbot;

--
-- Name: Click_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."Click_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Click_id_seq" OWNER TO seethbot;

--
-- Name: Click_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."Click_id_seq" OWNED BY public."Click".id;


--
-- Name: Conversation; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Conversation" (
    id integer NOT NULL,
    type text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Conversation" OWNER TO seethbot;

--
-- Name: ConversationParticipant; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."ConversationParticipant" (
    id integer NOT NULL,
    conversation_id integer NOT NULL,
    user_id integer NOT NULL,
    joined_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_read_at timestamp(3) without time zone
);


ALTER TABLE public."ConversationParticipant" OWNER TO seethbot;

--
-- Name: ConversationParticipant_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."ConversationParticipant_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ConversationParticipant_id_seq" OWNER TO seethbot;

--
-- Name: ConversationParticipant_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."ConversationParticipant_id_seq" OWNED BY public."ConversationParticipant".id;


--
-- Name: Conversation_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."Conversation_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Conversation_id_seq" OWNER TO seethbot;

--
-- Name: Conversation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."Conversation_id_seq" OWNED BY public."Conversation".id;


--
-- Name: DailyChallenge; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."DailyChallenge" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    challenge_type text NOT NULL,
    description text NOT NULL,
    target_value integer NOT NULL,
    current_value integer DEFAULT 0 NOT NULL,
    progress double precision DEFAULT 0 NOT NULL,
    completed boolean DEFAULT false NOT NULL,
    date text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    completed_at timestamp(3) without time zone
);


ALTER TABLE public."DailyChallenge" OWNER TO seethbot;

--
-- Name: DailyChallenge_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."DailyChallenge_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."DailyChallenge_id_seq" OWNER TO seethbot;

--
-- Name: DailyChallenge_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."DailyChallenge_id_seq" OWNED BY public."DailyChallenge".id;


--
-- Name: DataCenterRun; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."DataCenterRun" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    name text NOT NULL,
    location text NOT NULL,
    state_json text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    last_played_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."DataCenterRun" OWNER TO seethbot;

--
-- Name: DataCenterRun_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."DataCenterRun_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."DataCenterRun_id_seq" OWNER TO seethbot;

--
-- Name: DataCenterRun_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."DataCenterRun_id_seq" OWNED BY public."DataCenterRun".id;


--
-- Name: FartEvent; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."FartEvent" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    volume double precision NOT NULL,
    bass_gain double precision,
    bass_frequency double precision,
    distortion_amount double precision,
    volume_multiplier double precision,
    playback_rate double precision,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    user_agent text,
    ip_address text
);


ALTER TABLE public."FartEvent" OWNER TO seethbot;

--
-- Name: FartEvent_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."FartEvent_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."FartEvent_id_seq" OWNER TO seethbot;

--
-- Name: FartEvent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."FartEvent_id_seq" OWNED BY public."FartEvent".id;


--
-- Name: Favorite; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Favorite" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    item_type text NOT NULL,
    item_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    display_name text,
    order_index integer DEFAULT 0 NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Favorite" OWNER TO seethbot;

--
-- Name: Favorite_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."Favorite_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Favorite_id_seq" OWNER TO seethbot;

--
-- Name: Favorite_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."Favorite_id_seq" OWNED BY public."Favorite".id;


--
-- Name: GameStat; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."GameStat" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    game_type text NOT NULL,
    stat_type text NOT NULL,
    value double precision NOT NULL,
    metadata text,
    recorded_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."GameStat" OWNER TO seethbot;

--
-- Name: GameStat_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."GameStat_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."GameStat_id_seq" OWNER TO seethbot;

--
-- Name: GameStat_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."GameStat_id_seq" OWNED BY public."GameStat".id;


--
-- Name: HighScore; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."HighScore" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    user_name text,
    game_type text NOT NULL,
    score integer NOT NULL,
    details text,
    recorded_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."HighScore" OWNER TO seethbot;

--
-- Name: HighScore_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."HighScore_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."HighScore_id_seq" OWNER TO seethbot;

--
-- Name: HighScore_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."HighScore_id_seq" OWNED BY public."HighScore".id;


--
-- Name: Message; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Message" (
    id integer NOT NULL,
    conversation_id integer NOT NULL,
    sender_id integer NOT NULL,
    content text NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Message" OWNER TO seethbot;

--
-- Name: Message_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."Message_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Message_id_seq" OWNER TO seethbot;

--
-- Name: Message_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."Message_id_seq" OWNED BY public."Message".id;


--
-- Name: ProcessingStats; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."ProcessingStats" (
    id integer NOT NULL,
    date text NOT NULL,
    total_processed integer DEFAULT 0 NOT NULL,
    simple_playbacks integer DEFAULT 0 NOT NULL,
    processed_playbacks integer DEFAULT 0 NOT NULL,
    avg_bass_gain double precision DEFAULT 0.0 NOT NULL,
    avg_distortion double precision DEFAULT 0.0 NOT NULL,
    avg_volume_multiplier double precision DEFAULT 0.0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."ProcessingStats" OWNER TO seethbot;

--
-- Name: ProcessingStats_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."ProcessingStats_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ProcessingStats_id_seq" OWNER TO seethbot;

--
-- Name: ProcessingStats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."ProcessingStats_id_seq" OWNED BY public."ProcessingStats".id;


--
-- Name: Profile; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Profile" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    theme_preferences text,
    custom_colors text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    avatar_url text,
    bio text,
    display_name text,
    is_public boolean DEFAULT true NOT NULL,
    location text,
    profile_banner_url text,
    social_links text,
    status_message text,
    website text
);


ALTER TABLE public."Profile" OWNER TO seethbot;

--
-- Name: Profile_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."Profile_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Profile_id_seq" OWNER TO seethbot;

--
-- Name: Profile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."Profile_id_seq" OWNED BY public."Profile".id;


--
-- Name: PurchasedItem; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."PurchasedItem" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    item_id integer NOT NULL,
    purchased_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."PurchasedItem" OWNER TO seethbot;

--
-- Name: PurchasedItem_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."PurchasedItem_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."PurchasedItem_id_seq" OWNER TO seethbot;

--
-- Name: PurchasedItem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."PurchasedItem_id_seq" OWNED BY public."PurchasedItem".id;


--
-- Name: Reaction; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Reaction" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    target_type text NOT NULL,
    target_id text NOT NULL,
    emoji text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Reaction" OWNER TO seethbot;

--
-- Name: Reaction_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."Reaction_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Reaction_id_seq" OWNER TO seethbot;

--
-- Name: Reaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."Reaction_id_seq" OWNED BY public."Reaction".id;


--
-- Name: Session; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Session" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    device_name text,
    device_type text,
    token text NOT NULL,
    expires_at timestamp(3) without time zone NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_used_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Session" OWNER TO seethbot;

--
-- Name: Session_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."Session_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Session_id_seq" OWNER TO seethbot;

--
-- Name: Session_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."Session_id_seq" OWNED BY public."Session".id;


--
-- Name: Setting; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Setting" (
    key text NOT NULL,
    value text NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Setting" OWNER TO seethbot;

--
-- Name: ShopItem; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."ShopItem" (
    id integer NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    price integer NOT NULL,
    category text NOT NULL,
    image_url text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    effect text,
    icon text
);


ALTER TABLE public."ShopItem" OWNER TO seethbot;

--
-- Name: ShopItem_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."ShopItem_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ShopItem_id_seq" OWNER TO seethbot;

--
-- Name: ShopItem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."ShopItem_id_seq" OWNED BY public."ShopItem".id;


--
-- Name: Stock; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Stock" (
    name text NOT NULL,
    avatar text NOT NULL,
    price integer NOT NULL,
    coolness_score integer NOT NULL,
    shares integer NOT NULL,
    min_price integer NOT NULL,
    max_price integer NOT NULL,
    price_history text NOT NULL
);


ALTER TABLE public."Stock" OWNER TO seethbot;

--
-- Name: SyncLog; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."SyncLog" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    device_id text NOT NULL,
    sync_type text NOT NULL,
    status text NOT NULL,
    items_synced integer DEFAULT 0 NOT NULL,
    conflicts_found integer DEFAULT 0 NOT NULL,
    conflicts_resolved integer DEFAULT 0 NOT NULL,
    error_message text,
    started_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    completed_at timestamp(3) without time zone
);


ALTER TABLE public."SyncLog" OWNER TO seethbot;

--
-- Name: SyncLog_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."SyncLog_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."SyncLog_id_seq" OWNER TO seethbot;

--
-- Name: SyncLog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."SyncLog_id_seq" OWNED BY public."SyncLog".id;


--
-- Name: Theme; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Theme" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    preset text DEFAULT 'default'::text NOT NULL,
    custom_colors text,
    dark_mode boolean DEFAULT true NOT NULL,
    high_contrast boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Theme" OWNER TO seethbot;

--
-- Name: Theme_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."Theme_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Theme_id_seq" OWNER TO seethbot;

--
-- Name: Theme_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."Theme_id_seq" OWNED BY public."Theme".id;


--
-- Name: Ticket; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."Ticket" (
    id integer NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    response text,
    creator_id text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    type text DEFAULT 'feature'::text NOT NULL,
    priority text DEFAULT 'medium'::text NOT NULL,
    tags text,
    category text,
    dependencies text,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE public."Ticket" OWNER TO seethbot;

--
-- Name: Ticket_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."Ticket_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Ticket_id_seq" OWNER TO seethbot;

--
-- Name: Ticket_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."Ticket_id_seq" OWNED BY public."Ticket".id;


--
-- Name: User; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."User" (
    id integer NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    display_name text,
    avatar_url text,
    banner_url text,
    bio text,
    status text,
    show_email integer DEFAULT 1 NOT NULL,
    show_joined_date integer DEFAULT 1 NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    discord_id text,
    discord_username text,
    discord_discriminator text,
    discord_avatar text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."User" OWNER TO seethbot;

--
-- Name: UserDevice; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."UserDevice" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    device_id text NOT NULL,
    device_name text,
    device_type text,
    platform text,
    last_sync timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."UserDevice" OWNER TO seethbot;

--
-- Name: UserDevice_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."UserDevice_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."UserDevice_id_seq" OWNER TO seethbot;

--
-- Name: UserDevice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."UserDevice_id_seq" OWNED BY public."UserDevice".id;


--
-- Name: UserFartStats; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."UserFartStats" (
    id integer NOT NULL,
    user_id integer NOT NULL,
    total_farts integer DEFAULT 0 NOT NULL,
    total_volume double precision DEFAULT 0.0 NOT NULL,
    avg_volume double precision DEFAULT 0.0 NOT NULL,
    max_volume double precision DEFAULT 0.0 NOT NULL,
    min_volume double precision DEFAULT 0.0 NOT NULL,
    first_fart timestamp(3) without time zone,
    last_fart timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."UserFartStats" OWNER TO seethbot;

--
-- Name: UserFartStats_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."UserFartStats_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."UserFartStats_id_seq" OWNER TO seethbot;

--
-- Name: UserFartStats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."UserFartStats_id_seq" OWNED BY public."UserFartStats".id;


--
-- Name: UserPortfolio; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public."UserPortfolio" (
    user_id integer NOT NULL,
    cash integer DEFAULT 10000 NOT NULL,
    holdings text DEFAULT '{}'::text NOT NULL,
    transactions text DEFAULT '[]'::text NOT NULL
);


ALTER TABLE public."UserPortfolio" OWNER TO seethbot;

--
-- Name: User_id_seq; Type: SEQUENCE; Schema: public; Owner: seethbot
--

CREATE SEQUENCE public."User_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."User_id_seq" OWNER TO seethbot;

--
-- Name: User_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: seethbot
--

ALTER SEQUENCE public."User_id_seq" OWNED BY public."User".id;


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: seethbot
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO seethbot;

--
-- Name: Achievement id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Achievement" ALTER COLUMN id SET DEFAULT nextval('public."Achievement_id_seq"'::regclass);


--
-- Name: Activity id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Activity" ALTER COLUMN id SET DEFAULT nextval('public."Activity_id_seq"'::regclass);


--
-- Name: Character id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Character" ALTER COLUMN id SET DEFAULT nextval('public."Character_id_seq"'::regclass);


--
-- Name: CharacterMatch id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."CharacterMatch" ALTER COLUMN id SET DEFAULT nextval('public."CharacterMatch_id_seq"'::regclass);


--
-- Name: Click id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Click" ALTER COLUMN id SET DEFAULT nextval('public."Click_id_seq"'::regclass);


--
-- Name: Conversation id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Conversation" ALTER COLUMN id SET DEFAULT nextval('public."Conversation_id_seq"'::regclass);


--
-- Name: ConversationParticipant id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."ConversationParticipant" ALTER COLUMN id SET DEFAULT nextval('public."ConversationParticipant_id_seq"'::regclass);


--
-- Name: DailyChallenge id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."DailyChallenge" ALTER COLUMN id SET DEFAULT nextval('public."DailyChallenge_id_seq"'::regclass);


--
-- Name: DataCenterRun id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."DataCenterRun" ALTER COLUMN id SET DEFAULT nextval('public."DataCenterRun_id_seq"'::regclass);


--
-- Name: FartEvent id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."FartEvent" ALTER COLUMN id SET DEFAULT nextval('public."FartEvent_id_seq"'::regclass);


--
-- Name: Favorite id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Favorite" ALTER COLUMN id SET DEFAULT nextval('public."Favorite_id_seq"'::regclass);


--
-- Name: GameStat id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."GameStat" ALTER COLUMN id SET DEFAULT nextval('public."GameStat_id_seq"'::regclass);


--
-- Name: HighScore id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."HighScore" ALTER COLUMN id SET DEFAULT nextval('public."HighScore_id_seq"'::regclass);


--
-- Name: Message id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Message" ALTER COLUMN id SET DEFAULT nextval('public."Message_id_seq"'::regclass);


--
-- Name: ProcessingStats id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."ProcessingStats" ALTER COLUMN id SET DEFAULT nextval('public."ProcessingStats_id_seq"'::regclass);


--
-- Name: Profile id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Profile" ALTER COLUMN id SET DEFAULT nextval('public."Profile_id_seq"'::regclass);


--
-- Name: PurchasedItem id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."PurchasedItem" ALTER COLUMN id SET DEFAULT nextval('public."PurchasedItem_id_seq"'::regclass);


--
-- Name: Reaction id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Reaction" ALTER COLUMN id SET DEFAULT nextval('public."Reaction_id_seq"'::regclass);


--
-- Name: Session id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Session" ALTER COLUMN id SET DEFAULT nextval('public."Session_id_seq"'::regclass);


--
-- Name: ShopItem id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."ShopItem" ALTER COLUMN id SET DEFAULT nextval('public."ShopItem_id_seq"'::regclass);


--
-- Name: SyncLog id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."SyncLog" ALTER COLUMN id SET DEFAULT nextval('public."SyncLog_id_seq"'::regclass);


--
-- Name: Theme id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Theme" ALTER COLUMN id SET DEFAULT nextval('public."Theme_id_seq"'::regclass);


--
-- Name: Ticket id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Ticket" ALTER COLUMN id SET DEFAULT nextval('public."Ticket_id_seq"'::regclass);


--
-- Name: User id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."User" ALTER COLUMN id SET DEFAULT nextval('public."User_id_seq"'::regclass);


--
-- Name: UserDevice id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."UserDevice" ALTER COLUMN id SET DEFAULT nextval('public."UserDevice_id_seq"'::regclass);


--
-- Name: UserFartStats id; Type: DEFAULT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."UserFartStats" ALTER COLUMN id SET DEFAULT nextval('public."UserFartStats_id_seq"'::regclass);


--
-- Data for Name: Achievement; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Achievement" (id, user_id, achievement_id, achievement_name, description, icon, unlocked_at) FROM stdin;
\.


--
-- Data for Name: Activity; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Activity" (id, user_id, user_name, user_avatar, activity_type, description, metadata, points_change, game_type, recorded_at) FROM stdin;
\.


--
-- Data for Name: Character; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Character" (id, name, image_url, elo_rating, wins, losses, is_deleted, created_at, updated_at) FROM stdin;
2	Snouse and Mail	https://64.media.tumblr.com/54f100369945372c88d7dcd03a9a5825/57e2862b5e7186d9-24/s540x810/1c864ff3f33076224fa1a9499c0146b973588170.jpg	1154	3	6	f	2026-02-04 17:57:01	2026-02-09 10:39:46
4	Video Kojima	https://64.media.tumblr.com/f3fb1509753ce3766012363ef45694c2/7db86ffa66eba893-ce/s540x810/73f8d734cd1d5841891044bc85a6575401c850b2.jpg	1158	4	8	f	2026-02-04 17:58:35	2026-02-10 06:11:24
5	Lying down Miku	https://64.media.tumblr.com/248c337c9a79c944faa1cb222f221e3e/3b0374c89329798b-89/s540x810/d9395dbf1fd127bbbb823b5330f4e915d2e02de5.pnj	1189	1	2	f	2026-02-04 17:59:34	2026-02-06 14:15:56
6	Nurse Joy	https://x.com/i/status/1940083994168893687	1251	5	1	f	2026-02-04 18:01:29	2026-02-06 14:15:03
7	Spider Chair	https://pbs.twimg.com/media/HAPxZiFaEAAvMiL?format=jpg&name=medium	1209	4	3	f	2026-02-04 18:03:02	2026-02-06 14:15:37
8	Bluesky Account Suspension	https://pbs.twimg.com/media/HAUs_ifboAA0Plr?format=jpg&name=medium	1126	1	6	f	2026-02-04 18:03:26	2026-02-06 14:15:30
9	No Sleeper	https://pbs.twimg.com/media/HARvOApb0AA221p?format=png&name=small	1199	2	2	f	2026-02-04 18:06:05	2026-02-05 23:30:24
10	Dinner for One	https://pbs.twimg.com/media/HAUFp_DawAAUiwk?format=jpg&name=small	1259	4	0	f	2026-02-04 18:08:09	2026-02-05 04:39:43
11	Dark Uni	https://pbs.twimg.com/media/HAUUdaZbkAAxaB_?format=jpg&name=small	1276	7	1	f	2026-02-04 18:08:25	2026-02-09 10:39:46
12	Adobe Animate	\N	1113	1	7	f	2026-02-04 18:08:54	2026-02-05 05:23:45
13	Adobe Animate (With Picture)	https://pbs.twimg.com/media/HALUUJWWMAAizLr?format=png&name=small	1172	3	5	f	2026-02-04 18:09:05	2026-02-10 09:37:32
14	Queensland Police Service	https://pbs.twimg.com/media/HASr0IibMAA_1-6?format=jpg&name=small	1088	0	8	f	2026-02-04 18:09:23	2026-02-06 02:23:59
15	Jellyfish Utensil Holder	https://pbs.twimg.com/media/HAP5UtbbMAADvqP?format=jpg&name=medium	1245	4	1	f	2026-02-04 18:09:54	2026-02-06 11:51:33
16	Mar10 Milk	https://pbs.twimg.com/media/HAN1lTBbcAAg3se?format=jpg&name=large	1176	4	5	f	2026-02-04 18:11:10	2026-02-06 14:16:10
17	Tumblr Poll Cake	https://64.media.tumblr.com/d555346393e8c2ea55da646a53db82a2/1561f50b9cbf8599-e6/s540x810/8047745de8917e434a5babc2346bfc4cbb733103.pnj	1099	0	7	f	2026-02-04 18:14:37	2026-02-10 06:11:24
18	David Lynch	https://64.media.tumblr.com/7a3b60a0b1ff3daf24c8a16207beb901/82eaced35c0e6dc5-cb/s540x810/a501413f67ec64d2d56fb83d0d43275caa895ce0.jpg	1322	9	0	f	2026-02-04 18:18:52	2026-02-05 23:30:42
19	Markiplier	https://64.media.tumblr.com/bea562bda37afe0fca2d19663cb82068/9cb7467eb20e3588-57/s400x600/5a4b3d56be0cf927eaefbefcbe36a313e6c67fee.gifv	1247	7	3	f	2026-02-04 18:19:45	2026-02-09 10:39:51
20	Watermelon	https://64.media.tumblr.com/017cd22c89b7b4f0ad325aa1d9cb8fc2/4017da0d095ef769-9e/s400x600/d5f2151405bb1afa5698b8efb83623b40dce7e97.jpg	1273	6	1	f	2026-02-04 18:21:18	2026-02-05 23:30:28
21	Tennis Ball	https://64.media.tumblr.com/e47673c57712cffb4e0bc15f515063b3/1e93aa5ae9766c62-17/s400x600/206a26c46fc703ba24287c3b4a8e03bd81bc4c7f.jpg	1270	7	2	f	2026-02-04 18:22:02	2026-02-10 09:37:32
22	Never Kill Yourself	https://64.media.tumblr.com/f5b9d6b3b2605aaafd63370ba0d26dd0/5db31de0dd99240e-cf/s400x600/2a7c94a33df3f45b073f061aa354da5e638ec06b.gif	1216	1	0	f	2026-02-04 18:25:28	2026-02-06 11:50:33
23	Orlando if he had an average or even a small ween	https://media.istockphoto.com/id/1434185664/vector/lying-man-with-a-long-nose-pinocchio.jpg?s=612x612&w=0&k=20&c=zzIOrozwM89eCN11S_lWeBpJIEaN8hvywhXAmU2U2jg=	1111	0	6	f	2026-02-04 18:25:41	2026-02-06 11:51:00
24	Thousand Layer Apple Cake	https://va.media.tumblr.com/tumblr_t8lpmaWk6D1zg326b.mp4	1200	1	1	f	2026-02-04 18:27:28	2026-02-06 11:51:33
25	Giorgia Meloni Angel	https://cdn.i-scmp.com/sites/default/files/styles/1020x680/public/d8/images/canvas/2026/02/01/14bf244e-801b-4300-9837-20172ff3fb35_44db174a.jpg?itok=GSjpisR7&v=1769881806	1173	1	3	f	2026-02-04 18:27:46	2026-02-05 04:41:05
26	Toyota Fun Cargo Concept	https://64.media.tumblr.com/3a8ee0ddca17b83d76f11239961fd0eb/522475107bada3e0-16/s540x810/7c15b983058d70b4f6a539a5e7447d73cb9c94cc.jpg	1174	2	4	f	2026-02-04 18:29:56	2026-02-06 11:51:08
28	AI generated Product Names	https://64.media.tumblr.com/b66fe448dbd7a32006b5eb608c7d758c/7c01374d31631942-69/s1280x1920/729623371c6da38b83165981b63922799558134e.jpg	1174	1	3	f	2026-02-04 18:33:42	2026-02-06 14:15:23
29	MS Paint dog	https://preview.redd.it/tomodachi-life-living-the-dream-is-the-true-drawn-to-life-v0-7f97merb5dgg1.png?width=640&crop=smart&auto=webp&s=95cd092d6117a1958e828daf666482133ca09107	1183	2	3	f	2026-02-04 18:35:17	2026-02-05 05:23:40
30	Baby Thumbnails	https://64.media.tumblr.com/fe8d013afff4711d04f8adaa8365d011/3a82e4a93e29b5a1-36/s540x810/0a451f289f4eb3435907e1e95b97333b4d0aa514.pnj	1130	0	5	f	2026-02-04 18:35:28	2026-02-09 10:40:19
31	That girl that nobody wants to date from TL:LTD	https://sm.ign.com/t/ign_pt/video/t/tomodachi-/tomodachi-life-living-the-dream-direct-get-an-extended-gamep_qd75.1200.jpg	1234	4	2	f	2026-02-04 18:35:49	2026-02-07 09:10:43
32	七里ヶ浜駅-稲村ヶ崎駅間	https://64.media.tumblr.com/74ca414768db767b4601d2194b581c99/d0e4e7e03aebe7b7-a8/s540x810/6b8c4b9c75e0923fa48611c15db721efb11b1921.jpg	1155	0	3	f	2026-02-04 18:36:03	2026-02-05 21:08:20
34	Static Cling	https://64.media.tumblr.com/1bccb535ab27577426fd7f202d5b89d0/6b916191d2ed8484-76/s500x750/c1fe6e3a215b0e65aad9ac70652eedbdb71bd6cf.png	1201	1	1	f	2026-02-04 18:38:22	2026-02-07 09:10:32
35	Static Electricity	https://64.media.tumblr.com/1bccb535ab27577426fd7f202d5b89d0/6b916191d2ed8484-76/s500x750/c1fe6e3a215b0e65aad9ac70652eedbdb71bd6cf.png	1196	1	1	f	2026-02-04 18:38:33	2026-02-06 14:16:01
37	Electric Field	https://64.media.tumblr.com/1bccb535ab27577426fd7f202d5b89d0/6b916191d2ed8484-76/s500x750/c1fe6e3a215b0e65aad9ac70652eedbdb71bd6cf.png	1230	2	0	f	2026-02-04 18:38:59	2026-02-05 04:40:56
38	Electrostatics	https://64.media.tumblr.com/1bccb535ab27577426fd7f202d5b89d0/6b916191d2ed8484-76/s500x750/c1fe6e3a215b0e65aad9ac70652eedbdb71bd6cf.png	1249	3	0	f	2026-02-04 18:39:09	2026-02-09 10:39:51
39	Minecraft Civil Rights DLC	https://64.media.tumblr.com/5783d15fb011944c73bae25d89abbf69/a428cd1c18710989-4a/s540x810/ee72ffd16c7ba03c01ebe6ceb123badcd4034823.pnj	1184	2	3	f	2026-02-04 18:40:08	2026-02-06 14:16:01
40	panamaha parapara baabapapabarabara party	https://i.ytimg.com/vi/eCjfSDz4eRo/hqdefault.jpg?sqp=-oaymwEcCPYBEIoBSFXyq4qpAw4IARUAAIhCGAFwAcABBg==&rs=AOn4CLCcyyESQBQrihJrL-4qesMhDs1vgQ	1217	1	0	f	2026-02-05 04:44:23	2026-02-06 11:50:39
36	Triboelectric Effect	https://64.media.tumblr.com/1bccb535ab27577426fd7f202d5b89d0/6b916191d2ed8484-76/s500x750/c1fe6e3a215b0e65aad9ac70652eedbdb71bd6cf.png	1230	3	1	f	2026-02-04 18:38:50	2026-02-19 12:46:03.816
1	Snail and Mouse	https://64.media.tumblr.com/15ac9d233e78612262354e70f6b1c601/c9d326f499eff987-e9/s540x810/2d861b9525909e058b744ec2c2458ac5d85f753a.jpg	1235	13	12	f	2026-02-04 17:56:45	2026-02-19 12:46:03.816
41	Dragon Hunter	https://64.media.tumblr.com/7800f005e4dace4814516f5d2c1686b9/ccc0ff7f164376b6-9e/s540x810/ad68b79671913e8c9ee92489895e2fcd658be53a.jpg	1170	0	2	f	2026-02-05 05:22:11	2026-02-06 14:15:47
42	Dragon Hunter	https://64.media.tumblr.com/7800f005e4dace4814516f5d2c1686b9/ccc0ff7f164376b6-9e/s540x810/ad68b79671913e8c9ee92489895e2fcd658be53a.jpg	1222	3	1	f	2026-02-05 05:22:11	2026-02-06 14:16:20
43	Darkiplier	https://64.media.tumblr.com/645ed4744c2d9021f07a310fd91da911/tumblr_inline_ok2mgkqVEP1r3dph6_400.gif	1186	0	1	f	2026-02-05 05:29:13	2026-02-06 14:15:03
44	Darkiplier	https://64.media.tumblr.com/645ed4744c2d9021f07a310fd91da911/tumblr_inline_ok2mgkqVEP1r3dph6_400.gif	1182	0	1	f	2026-02-05 05:29:13	2026-02-06 14:15:23
45	Now Where Were We?	https://64.media.tumblr.com/0cb7e233c9f04dd349322c640ea96b3c/9da2ef120c1fc598-ed/s540x810/ddfe4d954eae6d672eaea0a34811342b47916720.jpg	1259	4	0	f	2026-02-05 05:44:10	2026-02-09 10:40:19
46	Now Where Were We?	https://64.media.tumblr.com/0cb7e233c9f04dd349322c640ea96b3c/9da2ef120c1fc598-ed/s540x810/ddfe4d954eae6d672eaea0a34811342b47916720.jpg	1233	2	0	f	2026-02-05 05:44:10	2026-02-06 14:15:14
47	Joe Biden	https://64.media.tumblr.com/217d8cdbdc04a4e7def5bc58e05f1139/5ddfde35e01979ae-fe/s250x400/339db9eccabf6f8fd82d2e6818c2cc1ac83cf7c4.gif	1186	1	2	f	2026-02-05 06:14:15	2026-02-06 02:23:59
48	Joe Biden	https://64.media.tumblr.com/217d8cdbdc04a4e7def5bc58e05f1139/5ddfde35e01979ae-fe/s250x400/339db9eccabf6f8fd82d2e6818c2cc1ac83cf7c4.gif	1177	0	2	f	2026-02-05 06:14:15	2026-02-05 23:30:42
27	Incredible Suggestion	https://64.media.tumblr.com/bbf2158701130540d51bbae3ac6ce2fc/b0489b1f87fed304-0b/s540x810/41131af2bba871425956bad209b36c2619af1412.pnj	1245	5	2	f	2026-02-04 18:30:34	2026-02-19 12:45:26.031
3	Survivorship Bias	https://64.media.tumblr.com/2586866394b278c4e6b523ec5c2c6ef8/25bc6c1cc1dc7948-13/s540x810/0ee2cce2e0170435635ec6f20b9f2cf4d490e093.jpg	1222	7	5	f	2026-02-04 17:58:15	2026-02-19 12:45:26.032
\.


--
-- Data for Name: CharacterMatch; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."CharacterMatch" (id, character_id, opponent_id, winner_id, voter_id, voted_at) FROM stdin;
\.


--
-- Data for Name: Click; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Click" (id, count, updated_at) FROM stdin;
1	29	2026-02-13 14:31:29.991
\.


--
-- Data for Name: Conversation; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Conversation" (id, type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ConversationParticipant; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."ConversationParticipant" (id, conversation_id, user_id, joined_at, last_read_at) FROM stdin;
\.


--
-- Data for Name: DailyChallenge; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."DailyChallenge" (id, user_id, challenge_type, description, target_value, current_value, progress, completed, date, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: DataCenterRun; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."DataCenterRun" (id, user_id, name, location, state_json, status, created_at, updated_at, last_played_at) FROM stdin;
1	1	Tech Hub Run	tech_hub	{"version":1,"phase":"won","locationId":"tech_hub","day":679,"secondsIntoDay":0,"rows":5,"cols":5,"cash":1582150,"clients":249,"clientInterestProgress":0.12668966257602698,"zeroClientDays":0,"totalWorkload":250.24000000000228,"pressure":0,"expansionLockDays":0,"legalStrikes":0,"rapidExpansionDebt":0,"supplierRep":{"zoogle":102.00000000000016,"asw":6515.800000000562,"macrohard":8.54,"gridlink":3021.1999999995282},"placedRacks":[{"id":"9183d930-2daf-48f6-9fae-c7d0827a52f9","offerId":"gridlink-cooling-tower","supplierId":"gridlink","role":"utility","utilityType":"cooling_tower","adjacentIncomeBoost":0,"movedToday":false,"name":"Cooling Tower","x":1,"y":2,"heat":-9.6,"dailyCash":0,"dailyPowerCost":36,"workloadContribution":0,"repGain":0.35},{"id":"af06acfb-0205-4aa4-bd78-c6db54a4d16b","offerId":"gridlink-cooling-tower","supplierId":"gridlink","role":"utility","utilityType":"cooling_tower","adjacentIncomeBoost":0,"movedToday":false,"name":"Cooling Tower","x":3,"y":2,"heat":-9.6,"dailyCash":0,"dailyPowerCost":36,"workloadContribution":0,"repGain":0.35},{"id":"adeaea5b-c380-4f43-86ec-b3ac0a669378","offerId":"gridlink-cooling-tower","supplierId":"gridlink","role":"utility","utilityType":"cooling_tower","adjacentIncomeBoost":0,"movedToday":false,"name":"Cooling Tower","x":2,"y":1,"heat":-9.6,"dailyCash":0,"dailyPowerCost":36,"workloadContribution":0,"repGain":0.35},{"id":"0dce2818-02de-4cef-a1f5-b17b881468cb","offerId":"gridlink-cooling-tower","supplierId":"gridlink","role":"utility","utilityType":"cooling_tower","adjacentIncomeBoost":0,"movedToday":false,"name":"Cooling Tower","x":2,"y":3,"heat":-9.6,"dailyCash":0,"dailyPowerCost":36,"workloadContribution":0,"repGain":0.35},{"id":"63f8e326-c99a-44cb-a6f3-ac3d16cac60a","offerId":"asw-photon-cage","supplierId":"asw","role":"compute","adjacentIncomeBoost":0,"movedToday":false,"name":"Photon Cage","x":3,"y":3,"heat":10.2,"dailyCash":325,"dailyPowerCost":0,"workloadContribution":1,"repGain":1.1},{"id":"3d78143e-9401-44c9-a3d0-1f7fa0db2886","offerId":"gridlink-cooling-tower","supplierId":"gridlink","role":"utility","utilityType":"cooling_tower","adjacentIncomeBoost":0,"movedToday":false,"name":"Cooling Tower","x":3,"y":4,"heat":-9.6,"dailyCash":0,"dailyPowerCost":36,"workloadContribution":0,"repGain":0.35},{"id":"db8596d5-41fb-42b5-8c76-135d3ab520ee","offerId":"gridlink-cooling-tower","supplierId":"gridlink","role":"utility","utilityType":"cooling_tower","adjacentIncomeBoost":0,"movedToday":false,"name":"Cooling Tower","x":4,"y":3,"heat":-9.6,"dailyCash":0,"dailyPowerCost":36,"workloadContribution":0,"repGain":0.35},{"id":"641c9257-1c26-46aa-b6c2-22722d5351e9","offerId":"gridlink-cooling-tower","supplierId":"gridlink","role":"utility","utilityType":"cooling_tower","adjacentIncomeBoost":0,"movedToday":false,"name":"Cooling Tower","x":0,"y":1,"heat":-9.6,"dailyCash":0,"dailyPowerCost":36,"workloadContribution":0,"repGain":0.35},{"id":"ba3ab6bf-4c84-418a-92b4-373b9c775467","offerId":"gridlink-cooling-tower","supplierId":"gridlink","role":"utility","utilityType":"cooling_tower","adjacentIncomeBoost":0,"movedToday":false,"name":"Cooling Tower","x":1,"y":0,"heat":-9.6,"dailyCash":0,"dailyPowerCost":36,"workloadContribution":0,"repGain":0.35},{"id":"ad9eaff1-5e84-44b3-ba9b-460865e40590","offerId":"asw-photon-cage","supplierId":"asw","role":"compute","adjacentIncomeBoost":0,"movedToday":false,"name":"Photon Cage","x":1,"y":1,"heat":10.2,"dailyCash":325,"dailyPowerCost":0,"workloadContribution":1,"repGain":1.1},{"id":"77bd8c2e-02e0-44ea-b67e-3b9cf77b3d49","offerId":"asw-photon-cage","supplierId":"asw","role":"compute","adjacentIncomeBoost":0,"movedToday":false,"name":"Photon Cage","x":4,"y":4,"heat":10.2,"dailyCash":325,"dailyPowerCost":0,"workloadContribution":1,"repGain":1.1},{"id":"32a4147e-318c-4c22-8fc1-cfc8576a65e4","offerId":"asw-photon-cage","supplierId":"asw","role":"compute","adjacentIncomeBoost":0,"movedToday":false,"name":"Photon Cage","x":0,"y":0,"heat":10.2,"dailyCash":325,"dailyPowerCost":0,"workloadContribution":1,"repGain":1.1},{"id":"42298db6-bf6c-4e8f-b84d-595f13ce9974","offerId":"asw-photon-cage","supplierId":"asw","role":"compute","adjacentIncomeBoost":0,"movedToday":false,"name":"Photon Cage","x":0,"y":2,"heat":10.2,"dailyCash":325,"dailyPowerCost":0,"workloadContribution":1,"repGain":1.1},{"id":"974c02c0-d0ce-45fc-9252-4d54a4e927fc","offerId":"asw-photon-cage","supplierId":"asw","role":"compute","adjacentIncomeBoost":0,"movedToday":false,"name":"Photon Cage","x":2,"y":4,"heat":10.2,"dailyCash":325,"dailyPowerCost":0,"workloadContribution":1,"repGain":1.1},{"id":"726ff73e-ecae-4836-b33d-fe36d1fbfeec","offerId":"gridlink-cooling-tower","supplierId":"gridlink","role":"utility","utilityType":"cooling_tower","adjacentIncomeBoost":0,"movedToday":false,"name":"Cooling Tower","x":1,"y":4,"heat":-9.6,"dailyCash":0,"dailyPowerCost":36,"workloadContribution":0,"repGain":0.35},{"id":"13ececad-447d-4728-8966-cdd5ae814913","offerId":"gridlink-cooling-tower","supplierId":"gridlink","role":"utility","utilityType":"cooling_tower","adjacentIncomeBoost":0,"movedToday":false,"name":"Cooling Tower","x":0,"y":3,"heat":-9.6,"dailyCash":0,"dailyPowerCost":36,"workloadContribution":0,"repGain":0.35},{"id":"732815c1-a35b-4e6d-8024-5c3b4004f639","offerId":"asw-photon-cage","supplierId":"asw","role":"compute","adjacentIncomeBoost":0,"movedToday":false,"name":"Photon Cage","x":1,"y":3,"heat":10.2,"dailyCash":325,"dailyPowerCost":0,"workloadContribution":1,"repGain":1.1},{"id":"f335aa0d-c262-4cd0-991f-63b3ed210cbd","offerId":"gridlink-cooling-tower","supplierId":"gridlink","role":"utility","utilityType":"cooling_tower","adjacentIncomeBoost":0,"movedToday":false,"name":"Cooling Tower","x":4,"y":1,"heat":-9.6,"dailyCash":0,"dailyPowerCost":36,"workloadContribution":0,"repGain":0.35},{"id":"05f0ea62-6d02-4aea-add9-837d4b41f001","offerId":"gridlink-cooling-tower","supplierId":"gridlink","role":"utility","utilityType":"cooling_tower","adjacentIncomeBoost":0,"movedToday":false,"name":"Cooling Tower","x":3,"y":0,"heat":-9.6,"dailyCash":0,"dailyPowerCost":36,"workloadContribution":0,"repGain":0.35},{"id":"712cbf1c-60bc-4615-9db7-11ef0e07d21b","offerId":"asw-photon-cage","supplierId":"asw","role":"compute","adjacentIncomeBoost":0,"movedToday":false,"name":"Photon Cage","x":2,"y":0,"heat":10.2,"dailyCash":325,"dailyPowerCost":0,"workloadContribution":1,"repGain":1.1},{"id":"120766fc-9ea2-4203-bfed-e930975f7bb7","offerId":"asw-photon-cage","supplierId":"asw","role":"compute","adjacentIncomeBoost":0,"movedToday":false,"name":"Photon Cage","x":3,"y":1,"heat":10.2,"dailyCash":325,"dailyPowerCost":0,"workloadContribution":1,"repGain":1.1},{"id":"79a54279-1399-40a1-9148-c40703b0b46a","offerId":"asw-photon-cage","supplierId":"asw","role":"compute","adjacentIncomeBoost":0,"movedToday":false,"name":"Photon Cage","x":4,"y":2,"heat":10.2,"dailyCash":325,"dailyPowerCost":0,"workloadContribution":1,"repGain":1.1},{"id":"3a131bd7-438d-4b1a-b238-e7eac21383dd","offerId":"gridlink-cooling-tower","supplierId":"gridlink","role":"utility","utilityType":"cooling_tower","adjacentIncomeBoost":0,"movedToday":false,"name":"Cooling Tower","x":4,"y":0,"heat":-9.6,"dailyCash":0,"dailyPowerCost":36,"workloadContribution":0,"repGain":0.35},{"id":"594e44de-2daf-406a-9d15-dcef3843751c","offerId":"gridlink-cooling-tower","supplierId":"gridlink","role":"utility","utilityType":"cooling_tower","adjacentIncomeBoost":0,"movedToday":false,"name":"Cooling Tower","x":0,"y":4,"heat":-9.6,"dailyCash":0,"dailyPowerCost":36,"workloadContribution":0,"repGain":0.35}],"heatMap":[[10.666,9.079,10.666,4.888,0],[9.079,10.666,6.984,10.666,4.888],[10.666,6.984,0.006,6.984,10.666],[4.888,10.666,6.984,10.666,9.079],[0,4.888,10.666,9.079,10.666]],"lossReason":null,"runName":"Tech Hub Run"}	won	2026-02-25 15:20:33.836	2026-02-25 15:35:45.711	2026-02-25 15:35:45.582
\.


--
-- Data for Name: FartEvent; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."FartEvent" (id, user_id, volume, bass_gain, bass_frequency, distortion_amount, volume_multiplier, playback_rate, "timestamp", user_agent, ip_address) FROM stdin;
\.


--
-- Data for Name: Favorite; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Favorite" (id, user_id, item_type, item_id, created_at, display_name, order_index, updated_at) FROM stdin;
\.


--
-- Data for Name: GameStat; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."GameStat" (id, user_id, game_type, stat_type, value, metadata, recorded_at) FROM stdin;
\.


--
-- Data for Name: HighScore; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."HighScore" (id, user_id, user_name, game_type, score, details, recorded_at, updated_at) FROM stdin;
\.


--
-- Data for Name: Message; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Message" (id, conversation_id, sender_id, content, is_deleted, created_at) FROM stdin;
\.


--
-- Data for Name: ProcessingStats; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."ProcessingStats" (id, date, total_processed, simple_playbacks, processed_playbacks, avg_bass_gain, avg_distortion, avg_volume_multiplier, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: Profile; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Profile" (id, user_id, theme_preferences, custom_colors, created_at, updated_at, avatar_url, bio, display_name, is_public, location, profile_banner_url, social_links, status_message, website) FROM stdin;
\.


--
-- Data for Name: PurchasedItem; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."PurchasedItem" (id, user_id, item_id, purchased_at) FROM stdin;
\.


--
-- Data for Name: Reaction; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Reaction" (id, user_id, target_type, target_id, emoji, created_at) FROM stdin;
\.


--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Session" (id, user_id, device_name, device_type, token, expires_at, created_at, last_used_at) FROM stdin;
5	1	Firefox on Linux	desktop	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsInRzIjoxNzcxMTUzNDcwMzg1LCJpYXQiOjE3NzExNTM0NzAsImV4cCI6MTc3Mzc0NTQ3MH0.OqOSlNqRF45EpGWUs3rW1w9_MF4bcOOMk-sEyT-sJLM	2026-04-03 14:22:48.139	2026-02-15 11:04:30.394	2026-03-04 14:22:48.139
3	2	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIsInRzIjoxNzcwOTkzMTQxODQ5LCJpYXQiOjE3NzA5OTMxNDEsImV4cCI6MTc3MzU4NTE0MX0.eFCMTFc3b04IeExsiTH772f63yh8YAq6czUy1bxoHqc	2026-03-15 14:32:21.85	2026-02-13 14:32:21.852	2026-02-13 14:32:21.852
1	1	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsInRzIjoxNzcwOTkxODEzOTg5LCJpYXQiOjE3NzA5OTE4MTMsImV4cCI6MTc3MzU4MzgxM30.QhHoury0GnYw4YZbCog1ozgUWfVDW02nf6C7MQmipmw	2026-04-13 12:23:01.569	2026-02-13 14:10:13.997	2026-03-14 12:23:01.57
4	2	Chrome on Windows	desktop	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIsInRzIjoxNzcwOTkzMTQ2Mzg2LCJpYXQiOjE3NzA5OTMxNDYsImV4cCI6MTc3MzU4NTE0Nn0.Ccb96EiXgxk5ZMbxfBtTpq6qGv_rbyeIay4DZ0DOXcU	2026-03-15 15:07:22.736	2026-02-13 14:32:26.387	2026-02-13 15:07:22.736
6	1	Firefox on Windows	desktop	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsInRzIjoxNzcxMzAzNDU2MTUxLCJpYXQiOjE3NzEzMDM0NTYsImV4cCI6MTc3Mzg5NTQ1Nn0.pzWW2r7c37iWmUS0rn9qp7oAfLE5I10uwcsZTSm40r0	2026-03-19 06:34:45.355	2026-02-17 04:44:16.17	2026-02-17 06:34:45.355
7	3	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjMsInRzIjoxNzcyMDIxMzY0MjgxLCJpYXQiOjE3NzIwMjEzNjQsImV4cCI6MTc3NDYxMzM2NH0.DO1_5bSeIuZkmnLCRV7Z4dWITs6JslkwGmWFG91Bsck	2026-03-27 12:09:24.285	2026-02-25 12:09:24.286	2026-02-25 12:09:24.286
2	1	Chrome on macOS	desktop	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsInRzIjoxNzcwOTkyMDYyNzEzLCJpYXQiOjE3NzA5OTIwNjIsImV4cCI6MTc3MzU4NDA2Mn0.X1apJvmuBKsyMh-PTRrtfh3IuCCzks8OwyAsl1t9RXk	2026-03-17 08:32:17.863	2026-02-13 14:14:22.714	2026-02-15 08:32:17.863
8	3	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjMsInRzIjoxNzcyMDIxMzY0MzU2LCJpYXQiOjE3NzIwMjEzNjQsImV4cCI6MTc3NDYxMzM2NH0.y3L_yAhsohS3AcbROornf2D9HAOzEnJM2VQPn3vbFNs	2026-03-27 12:09:24.356	2026-02-25 12:09:24.356	2026-02-25 12:09:24.356
9	4	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjQsInRzIjoxNzcyMDIxMzY0NDM2LCJpYXQiOjE3NzIwMjEzNjQsImV4cCI6MTc3NDYxMzM2NH0.JE-Q8qrprLXeF6MVFw6D-gk-Wf9ttlkZjU_1n-KXKH4	2026-03-27 12:09:24.436	2026-02-25 12:09:24.437	2026-02-25 12:09:24.437
11	5	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjUsInRzIjoxNzcyMDIxMzY0NTc5LCJpYXQiOjE3NzIwMjEzNjQsImV4cCI6MTc3NDYxMzM2NH0.VTWlzeiYDEJkLVnGhg-PGe1zrbGwnup9AE4gj6w5Rp0	2026-03-27 12:09:24.58	2026-02-25 12:09:24.58	2026-02-25 12:09:24.58
12	5	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjUsInRzIjoxNzcyMDIxMzY0NjQzLCJpYXQiOjE3NzIwMjEzNjQsImV4cCI6MTc3NDYxMzM2NH0.XuK6rPxjlK6cj4ewu5mqQ8G63Ip5ccALxL7kgagaiOc	2026-03-27 12:09:24.644	2026-02-25 12:09:24.644	2026-02-25 12:09:24.644
13	6	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjYsInRzIjoxNzcyMDIxMzY0NzE2LCJpYXQiOjE3NzIwMjEzNjQsImV4cCI6MTc3NDYxMzM2NH0.n3vMFUNG-QVwPkzPbRSfzxZRciRnCKws0VEz4Z_ClL0	2026-03-27 12:09:24.716	2026-02-25 12:09:24.716	2026-02-25 12:09:24.716
14	6	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjYsInRzIjoxNzcyMDIxMzY0NzgzLCJpYXQiOjE3NzIwMjEzNjQsImV4cCI6MTc3NDYxMzM2NH0.qd5JjBlKASfRog4ZsdRhxYN27QHbw-ZHXMjW6BfXzgs	2026-03-27 12:09:24.783	2026-02-25 12:09:24.783	2026-02-25 12:09:24.783
15	7	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjcsInRzIjoxNzcyMDIxMzY0ODU5LCJpYXQiOjE3NzIwMjEzNjQsImV4cCI6MTc3NDYxMzM2NH0.vnB5T6oP-n_lQ7_qxV3cXlgiHGlK97Pml0V22HGCPc8	2026-03-27 12:09:24.859	2026-02-25 12:09:24.859	2026-02-25 12:09:24.859
16	7	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjcsInRzIjoxNzcyMDIxMzY0OTIzLCJpYXQiOjE3NzIwMjEzNjQsImV4cCI6MTc3NDYxMzM2NH0.m6HYy6vP3L4ttb-lIy7bnfzRlMj3pQ8Y7ml6Q5wRRoA	2026-03-27 12:09:24.923	2026-02-25 12:09:24.924	2026-02-25 12:09:24.924
17	8	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjgsInRzIjoxNzcyMDIxMzY0OTkxLCJpYXQiOjE3NzIwMjEzNjQsImV4cCI6MTc3NDYxMzM2NH0.D_kqD9XHCmpsgaqRoX7vlJRIAyt5ugOHSgQDNLOUEYc	2026-03-27 12:09:24.991	2026-02-25 12:09:24.992	2026-02-25 12:09:24.992
18	8	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjgsInRzIjoxNzcyMDIxMzY1MDU3LCJpYXQiOjE3NzIwMjEzNjUsImV4cCI6MTc3NDYxMzM2NX0.nLC_LfduCodvANQhcM-CO17N7T3XDVidN1b0UZ_AYEU	2026-03-27 12:09:25.057	2026-02-25 12:09:25.057	2026-02-25 12:09:25.057
19	9	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjksInRzIjoxNzcyMDIxMzY1MTI2LCJpYXQiOjE3NzIwMjEzNjUsImV4cCI6MTc3NDYxMzM2NX0.hRvEALMDijMoGK6obA6ZWrnwn-rsg_K-5KfT8R8IXL4	2026-03-27 12:09:25.126	2026-02-25 12:09:25.126	2026-02-25 12:09:25.126
20	9	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjksInRzIjoxNzcyMDIxMzY1MTk2LCJpYXQiOjE3NzIwMjEzNjUsImV4cCI6MTc3NDYxMzM2NX0.UyxbbdmVTvbL6RvFsNUzdg5ECfUzcaAaZE27SpSaHjo	2026-03-27 12:09:25.196	2026-02-25 12:09:25.196	2026-02-25 12:09:25.196
21	10	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEwLCJ0cyI6MTc3MjAyMTM2NTI2NywiaWF0IjoxNzcyMDIxMzY1LCJleHAiOjE3NzQ2MTMzNjV9.fGyNz-kGZl0ErpikU2h83ul6R2rHxR058Bs8spH46Aw	2026-03-27 12:09:25.267	2026-02-25 12:09:25.267	2026-02-25 12:09:25.267
22	10	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEwLCJ0cyI6MTc3MjAyMTM2NTMzNCwiaWF0IjoxNzcyMDIxMzY1LCJleHAiOjE3NzQ2MTMzNjV9.kk8wuzca9sitR_iJ9Fs7e6kM-sQXEdA_W1dLkn2VuOU	2026-03-27 12:09:25.334	2026-02-25 12:09:25.335	2026-02-25 12:09:25.335
23	11	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjExLCJ0cyI6MTc3MjAyMTM2NTQwNSwiaWF0IjoxNzcyMDIxMzY1LCJleHAiOjE3NzQ2MTMzNjV9.Fe6ZAQvd7-kDsSUB8AcPZlkAToLa_wOJREM4jJv7V7I	2026-03-27 12:09:25.406	2026-02-25 12:09:25.406	2026-02-25 12:09:25.406
24	11	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjExLCJ0cyI6MTc3MjAyMTM2NTQ3MywiaWF0IjoxNzcyMDIxMzY1LCJleHAiOjE3NzQ2MTMzNjV9.2uRZI3XKjXwHkAOjZs1ahUkk9wzHeugvHEp_k0wnybE	2026-03-27 12:09:25.473	2026-02-25 12:09:25.473	2026-02-25 12:09:25.473
25	12	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyLCJ0cyI6MTc3MjAyMTQyODk4MCwiaWF0IjoxNzcyMDIxNDI4LCJleHAiOjE3NzQ2MTM0Mjh9.Dca8bsbHKXQP-gZdonm0SBSujdWXiSmqjfXk8kQ5ahM	2026-03-27 12:10:28.98	2026-02-25 12:10:28.982	2026-02-25 12:10:28.982
26	12	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEyLCJ0cyI6MTc3MjAyMTQyOTA1NiwiaWF0IjoxNzcyMDIxNDI5LCJleHAiOjE3NzQ2MTM0Mjl9.lkIGE_UXpahj7mBumKIQhIPj4iGDlaS7uI_8NeWu45U	2026-03-27 12:10:29.056	2026-02-25 12:10:29.057	2026-02-25 12:10:29.057
27	1	Chrome on macOS	desktop	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEsInRzIjoxNzcyMjY1ODYzODcxLCJpYXQiOjE3NzIyNjU4NjMsImV4cCI6MTc3NDg1Nzg2M30.bug9az1ufbN-Mv3uHRCmbEBzhwZEy9v5SmoB2WxHoAs	2026-03-30 10:30:41.996	2026-02-28 08:04:23.88	2026-02-28 10:30:41.996
28	13	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEzLCJ0cyI6MTc3NDQ2MjU1NDg4OCwiaWF0IjoxNzc0NDYyNTU0LCJleHAiOjE3NzcwNTQ1NTR9.W4G8hO0b6NoGOeiGuMtH82Xqn49gDFsnqJHPACnfpGg	2026-04-24 18:15:54.892	2026-03-25 18:15:54.901	2026-03-25 18:15:54.901
29	13	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjEzLCJ0cyI6MTc3NDQ2MjU1NTAzOSwiaWF0IjoxNzc0NDYyNTU1LCJleHAiOjE3NzcwNTQ1NTV9.J_faS0JMQqCh1cZlouM3IidpEheAS1iXrrq3hVE0_L0	2026-04-24 18:15:55.039	2026-03-25 18:15:55.039	2026-03-25 18:15:55.039
30	14	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjE0LCJ0cyI6MTc3NDQ2MjU1NTIzNywiaWF0IjoxNzc0NDYyNTU1LCJleHAiOjE3NzcwNTQ1NTV9.1P6uq7JLNG1sNfq76x5gF_vzLI8MVtut0xCWmsr6FZo	2026-04-24 18:15:55.237	2026-03-25 18:15:55.237	2026-03-25 18:15:55.237
32	15	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjE1LCJ0cyI6MTc3NDQ2MjU1NTYxOCwiaWF0IjoxNzc0NDYyNTU1LCJleHAiOjE3NzcwNTQ1NTV9.TTiS00YKIQ6seeYS8yOXW05oy4oORkO8qYo5WxuATn0	2026-04-24 18:15:55.619	2026-03-25 18:15:55.62	2026-03-25 18:15:55.62
33	15	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjE1LCJ0cyI6MTc3NDQ2MjU1NTczNiwiaWF0IjoxNzc0NDYyNTU1LCJleHAiOjE3NzcwNTQ1NTV9.l24aR5YoQKap9qnCs0kjAe7cerqVnXgGfiSN1DR-Tjo	2026-04-24 18:15:55.737	2026-03-25 18:15:55.737	2026-03-25 18:15:55.737
34	16	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjE2LCJ0cyI6MTc3NDQ2MjU1NTg3NywiaWF0IjoxNzc0NDYyNTU1LCJleHAiOjE3NzcwNTQ1NTV9.TW2NzpEhoe1onJ6AkTDlGxGX6zCaGXveuabcSUsoyNQ	2026-04-24 18:15:55.877	2026-03-25 18:15:55.877	2026-03-25 18:15:55.877
35	16	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjE2LCJ0cyI6MTc3NDQ2MjU1NjAwMSwiaWF0IjoxNzc0NDYyNTU2LCJleHAiOjE3NzcwNTQ1NTZ9.yCPIdzg1QJ8fnbVLcIXmqHnk2d3oqEF4NwK83fJfEjI	2026-04-24 18:15:56.001	2026-03-25 18:15:56.001	2026-03-25 18:15:56.001
36	17	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjE3LCJ0cyI6MTc3NDQ2MjU1NjE5NiwiaWF0IjoxNzc0NDYyNTU2LCJleHAiOjE3NzcwNTQ1NTZ9.eYMq2oX9kfJn2k6l-f831r4WAZMpAXpzfdo-SrIYeMA	2026-04-24 18:15:56.197	2026-03-25 18:15:56.197	2026-03-25 18:15:56.197
37	17	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjE3LCJ0cyI6MTc3NDQ2MjU1NjM1NiwiaWF0IjoxNzc0NDYyNTU2LCJleHAiOjE3NzcwNTQ1NTZ9.VeagUQgCm6_SyHlzghSsrdQa31wBX9d5p7C7NrZ_M7o	2026-04-24 18:15:56.357	2026-03-25 18:15:56.357	2026-03-25 18:15:56.357
38	18	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjE4LCJ0cyI6MTc3NDQ2MjU1NjU0NiwiaWF0IjoxNzc0NDYyNTU2LCJleHAiOjE3NzcwNTQ1NTZ9.NhgQTct1sXpK1djbOIh-c_wNltR7Pvtmpyd4FH-O8X8	2026-04-24 18:15:56.546	2026-03-25 18:15:56.546	2026-03-25 18:15:56.546
39	18	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjE4LCJ0cyI6MTc3NDQ2MjU1NjY5MiwiaWF0IjoxNzc0NDYyNTU2LCJleHAiOjE3NzcwNTQ1NTZ9.64UREiZzeRBtugbQKnmiEw8XgpXXGdh3-Y_1rQ4Ev_E	2026-04-24 18:15:56.693	2026-03-25 18:15:56.693	2026-03-25 18:15:56.693
40	19	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjE5LCJ0cyI6MTc3NDQ2MjU1Njg3MSwiaWF0IjoxNzc0NDYyNTU2LCJleHAiOjE3NzcwNTQ1NTZ9.Vgedk9ZvsFDNewhSF94cWPfL0hxd8s4kPjJoUQ31BZ8	2026-04-24 18:15:56.871	2026-03-25 18:15:56.871	2026-03-25 18:15:56.871
41	19	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjE5LCJ0cyI6MTc3NDQ2MjU1Njk2NiwiaWF0IjoxNzc0NDYyNTU2LCJleHAiOjE3NzcwNTQ1NTZ9.o0WiIVNY9EiNn4l40rBYYMP8pwJfZObAMpGmLEbyi5A	2026-04-24 18:15:56.966	2026-03-25 18:15:56.966	2026-03-25 18:15:56.966
42	20	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIwLCJ0cyI6MTc3NDQ2MjU1NzA2OSwiaWF0IjoxNzc0NDYyNTU3LCJleHAiOjE3NzcwNTQ1NTd9.v5Dx5K1Wl-sGUZyE0K8RGwe-mrj_cL8xVMEOXytK1YA	2026-04-24 18:15:57.072	2026-03-25 18:15:57.073	2026-03-25 18:15:57.073
43	20	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIwLCJ0cyI6MTc3NDQ2MjU1NzIzMiwiaWF0IjoxNzc0NDYyNTU3LCJleHAiOjE3NzcwNTQ1NTd9.PcA6YcOVRVtD-qVhRnDVnQjSw9PxMCSKxv7JhualzEg	2026-04-24 18:15:57.233	2026-03-25 18:15:57.233	2026-03-25 18:15:57.233
44	21	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIxLCJ0cyI6MTc3NDQ2MjU1NzM5NywiaWF0IjoxNzc0NDYyNTU3LCJleHAiOjE3NzcwNTQ1NTd9.52u7FtRnwOirJHryrFGJmgJVBN6Kd494KG55gOsMYIo	2026-04-24 18:15:57.398	2026-03-25 18:15:57.398	2026-03-25 18:15:57.398
45	21	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIxLCJ0cyI6MTc3NDQ2MjU1NzQ3NywiaWF0IjoxNzc0NDYyNTU3LCJleHAiOjE3NzcwNTQ1NTd9.tIfT942VDB27xnrlT9TGgE9__33oSgUKI9gjuMfjMDk	2026-04-24 18:15:57.477	2026-03-25 18:15:57.477	2026-03-25 18:15:57.477
46	22	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIyLCJ0cyI6MTc3NDQ2NjE3NjQyOSwiaWF0IjoxNzc0NDY2MTc2LCJleHAiOjE3NzcwNTgxNzZ9.L7gyR3VAK-vtZ5AqdS_axJ9hcRmIZs3sDcI-lzsBgwo	2026-04-24 19:16:16.435	2026-03-25 19:16:16.442	2026-03-25 19:16:16.442
47	22	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIyLCJ0cyI6MTc3NDQ2NjE3NjU1OSwiaWF0IjoxNzc0NDY2MTc2LCJleHAiOjE3NzcwNTgxNzZ9.rf3uRM_lj0zGrOfEz2xHyOnoimBsTLs8wzDygDvfLCw	2026-04-24 19:16:16.56	2026-03-25 19:16:16.56	2026-03-25 19:16:16.56
48	23	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjIzLCJ0cyI6MTc3NDQ2NjE3Njc0NCwiaWF0IjoxNzc0NDY2MTc2LCJleHAiOjE3NzcwNTgxNzZ9.45CAwQMXhS7rwQeZcNZQ6LpOUr3Pzfp7ksmmQfmkR1A	2026-04-24 19:16:16.744	2026-03-25 19:16:16.745	2026-03-25 19:16:16.745
50	24	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjI0LCJ0cyI6MTc3NDQ2NjE3Njg5OSwiaWF0IjoxNzc0NDY2MTc2LCJleHAiOjE3NzcwNTgxNzZ9.d8h8NWpncb_FI9pc__G3GchhQ_HnGdmvSb39-jJwVgU	2026-04-24 19:16:16.9	2026-03-25 19:16:16.9	2026-03-25 19:16:16.9
51	24	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjI0LCJ0cyI6MTc3NDQ2NjE3Njk2NiwiaWF0IjoxNzc0NDY2MTc2LCJleHAiOjE3NzcwNTgxNzZ9.HQ8LUB0Ogz4gueDcsN2-HGFEG74G4wbUnXf8KU152l4	2026-04-24 19:16:16.966	2026-03-25 19:16:16.967	2026-03-25 19:16:16.967
52	25	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjI1LCJ0cyI6MTc3NDQ2NjE3NzA2NCwiaWF0IjoxNzc0NDY2MTc3LCJleHAiOjE3NzcwNTgxNzd9.JFyxWdF4MkyvATSdLxchoF5wgDY2KniP7_8Kb56cbko	2026-04-24 19:16:17.064	2026-03-25 19:16:17.064	2026-03-25 19:16:17.064
53	25	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjI1LCJ0cyI6MTc3NDQ2NjE3NzEzNiwiaWF0IjoxNzc0NDY2MTc3LCJleHAiOjE3NzcwNTgxNzd9.xcfUAF0cuusePjDB7lmo0Fp7GEkUO_WlYqViVrVMduA	2026-04-24 19:16:17.137	2026-03-25 19:16:17.137	2026-03-25 19:16:17.137
54	26	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjI2LCJ0cyI6MTc3NDQ2NjE3NzIyNiwiaWF0IjoxNzc0NDY2MTc3LCJleHAiOjE3NzcwNTgxNzd9.iqQGstlwffZlItHpoRaRhx6UtVFavotIv3BudE2ksfY	2026-04-24 19:16:17.226	2026-03-25 19:16:17.226	2026-03-25 19:16:17.226
55	26	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjI2LCJ0cyI6MTc3NDQ2NjE3NzMyOCwiaWF0IjoxNzc0NDY2MTc3LCJleHAiOjE3NzcwNTgxNzd9.phqS2wjjfue8LfO-GuhF6B8K6lSg41T-A-7WVBWLB5o	2026-04-24 19:16:17.329	2026-03-25 19:16:17.329	2026-03-25 19:16:17.329
56	27	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjI3LCJ0cyI6MTc3NDQ2NjE3NzQyMSwiaWF0IjoxNzc0NDY2MTc3LCJleHAiOjE3NzcwNTgxNzd9.sr1qQcb2oabidO8du6szDOFrsjdqes6b1CzLJW169WU	2026-04-24 19:16:17.421	2026-03-25 19:16:17.422	2026-03-25 19:16:17.422
57	27	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjI3LCJ0cyI6MTc3NDQ2NjE3NzQ5NiwiaWF0IjoxNzc0NDY2MTc3LCJleHAiOjE3NzcwNTgxNzd9.J6a31ptBONMzMcUclTJgfJ8Mx7o-W9OvapuvIujE6Vw	2026-04-24 19:16:17.496	2026-03-25 19:16:17.497	2026-03-25 19:16:17.497
58	28	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjI4LCJ0cyI6MTc3NDQ2NjE3NzU2NSwiaWF0IjoxNzc0NDY2MTc3LCJleHAiOjE3NzcwNTgxNzd9.7J_BQAEyEp6IUXJ2FLfpw3AUSA47RxTKVxTp5Nn8PcI	2026-04-24 19:16:17.565	2026-03-25 19:16:17.565	2026-03-25 19:16:17.565
59	28	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjI4LCJ0cyI6MTc3NDQ2NjE3NzY0MSwiaWF0IjoxNzc0NDY2MTc3LCJleHAiOjE3NzcwNTgxNzd9.CuQ3PvMWr-wWx7kdSul_8ufkQZ_NuahkLrJ_mx-XkV0	2026-04-24 19:16:17.642	2026-03-25 19:16:17.642	2026-03-25 19:16:17.642
60	29	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjI5LCJ0cyI6MTc3NDQ2NjE3NzcxOCwiaWF0IjoxNzc0NDY2MTc3LCJleHAiOjE3NzcwNTgxNzd9.3Mu7-gBc6RvfKpTEv8v8mQ4GbkpBaLcc2U1OueEHseM	2026-04-24 19:16:17.718	2026-03-25 19:16:17.718	2026-03-25 19:16:17.718
61	29	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjI5LCJ0cyI6MTc3NDQ2NjE3NzgwOCwiaWF0IjoxNzc0NDY2MTc3LCJleHAiOjE3NzcwNTgxNzd9.fCw1fS0SthLIIhqAoFldkJ4MbG42kuv_IdRu9PSMVks	2026-04-24 19:16:17.808	2026-03-25 19:16:17.808	2026-03-25 19:16:17.808
62	30	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjMwLCJ0cyI6MTc3NDQ2NjE3Nzg5OSwiaWF0IjoxNzc0NDY2MTc3LCJleHAiOjE3NzcwNTgxNzd9.SqiAi3TqH_BvxrMJ7ngoX482tp4kmgDOQ21yoCFkrJs	2026-04-24 19:16:17.9	2026-03-25 19:16:17.9	2026-03-25 19:16:17.9
63	30	\N	\N	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOjMwLCJ0cyI6MTc3NDQ2NjE3Nzk5NywiaWF0IjoxNzc0NDY2MTc3LCJleHAiOjE3NzcwNTgxNzd9.5V2XlflVEts-M_2GDL4RnuVRZiZjDrbE2rIRk_p_Qso	2026-04-24 19:16:17.998	2026-03-25 19:16:17.998	2026-03-25 19:16:17.998
\.


--
-- Data for Name: Setting; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Setting" (key, value, updated_at) FROM stdin;
last_collection	2026-03-25T18:15:46.480Z	2026-03-25 18:15:46.48
ignore_mode	false	2026-04-28 04:02:00.619
\.


--
-- Data for Name: ShopItem; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."ShopItem" (id, name, description, price, category, image_url, is_active, created_at, updated_at, effect, icon) FROM stdin;
1	Double Click Power	Your clicks are worth 2x points!	500	clicker	\N	t	2026-02-18 09:34:39.213	2026-02-18 09:34:39.213	clickPower:2	✌️
2	Auto-Clicker Boost	Auto-clicker generates +1 point/second	1000	clicker	\N	t	2026-02-18 09:34:39.213	2026-02-18 09:34:39.213	autoClickBoost:1	🤖
3	Custom Goose Emoji	Set a custom emoji for the digital goose	300	cosmetic	\N	t	2026-02-18 09:34:39.213	2026-02-18 09:34:39.213	customGoose	🦆
4	Neon Goose Effect	Add a glowing neon effect to the goose	250	cosmetic	\N	t	2026-02-18 09:34:39.213	2026-02-18 09:34:39.213	neonGoose	✨
5	Coolness Multiplier	All point gains multiplied by 1.5x	2000	premium	\N	t	2026-02-18 09:34:39.213	2026-02-18 09:34:39.213	multiplier:1.5	⭐
6	Instant Points Bundle	Get 100 points instantly	100	consumable	\N	t	2026-02-18 09:34:39.213	2026-02-18 09:34:39.213	instantPoints:100	💎
7	Golden Mushroom	Special mushroom skin for clicker	750	cosmetic	\N	t	2026-02-18 09:34:39.213	2026-02-18 09:34:39.213	goldenMushroom	🍄
8	Speed Upgrades	Auto-clicker generates +2 points/second	3000	clicker	\N	t	2026-02-18 09:34:39.213	2026-02-18 09:34:39.213	autoClickBoost:2	⚡
\.


--
-- Data for Name: Stock; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Stock" (name, avatar, price, coolness_score, shares, min_price, max_price, price_history) FROM stdin;
Cam	🥔	1000	10000	1000	500	5000	[{"timestamp":1770991720629,"price":1000},{"timestamp":1770991750629,"price":1000}]
Orlando	🌙	1007	10067	1000	504	5035	[{"timestamp":1770991720647,"price":1007},{"timestamp":1770991750647,"price":1007}]
Ashley	<:flooshies:1000736727259947069>	500	5000	1000	250	2500	[{"timestamp":1770991720652,"price":500},{"timestamp":1770991750652,"price":500}]
Average Hex	🌸	200	2000	1000	100	1000	[{"timestamp":1770991720656,"price":200},{"timestamp":1770991750656,"price":200}]
Temer3	🔧	180	1800	1000	90	900	[{"timestamp":1770991720660,"price":180},{"timestamp":1770991750660,"price":180}]
You	🌸	147	1467	1000	74	735	[{"timestamp":1770991720666,"price":147},{"timestamp":1770991750666,"price":147}]
美香	🏍️	2147	21467	1000	1074	10735	[{"timestamp":1770991720669,"price":2147},{"timestamp":1770991750669,"price":2147}]
Chang'Yi	<:sadcat:1000736705197907968>	137	1367	1000	69	685	[{"timestamp":1770991720671,"price":137},{"timestamp":1770991750671,"price":137}]
RIUM+	🎮	50	501	1000	25	250	[{"timestamp":1770991720675,"price":50},{"timestamp":1770991750675,"price":50}]
Goopsworthy	🍄	67	667	1000	34	335	[{"timestamp":1770991720679,"price":67},{"timestamp":1770991750679,"price":67}]
Blair	🎮	90	900	1000	45	450	[{"timestamp":1770991720681,"price":90},{"timestamp":1770991750681,"price":90}]
Others	✨	50	500	1000	25	250	[{"timestamp":1770991720685,"price":50},{"timestamp":1770991750685,"price":50}]
\.


--
-- Data for Name: SyncLog; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."SyncLog" (id, user_id, device_id, sync_type, status, items_synced, conflicts_found, conflicts_resolved, error_message, started_at, completed_at) FROM stdin;
1	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-17 07:41:38.049	2026-02-17 07:41:38.06
2	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 09:46:16.051	2026-02-18 09:46:16.063
3	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 09:51:16.287	2026-02-18 09:51:16.299
4	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 09:56:16.284	2026-02-18 09:56:16.289
5	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:01:16.282	2026-02-18 10:01:16.29
6	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:06:16.728	2026-02-18 10:06:16.736
7	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:11:17.315	2026-02-18 10:11:17.324
8	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:16:17.877	2026-02-18 10:16:17.887
9	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:21:18.581	2026-02-18 10:21:18.586
10	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:26:18.804	2026-02-18 10:26:18.815
11	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:31:19.305	2026-02-18 10:31:19.33
12	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:40:43.34	2026-02-18 10:40:43.353
13	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:46:37.729	2026-02-18 10:46:37.746
14	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:47:03.577	2026-02-18 10:47:03.583
15	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:47:04.275	2026-02-18 10:47:04.288
16	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:50:32.104	2026-02-18 10:50:32.111
17	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-18 10:50:36.613	2026-02-18 10:50:36.621
18	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-21 07:28:30.951	2026-02-21 07:28:30.96
19	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-21 07:33:30.844	2026-02-21 07:33:30.856
20	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-21 07:38:31.639	2026-02-21 07:38:31.656
21	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-21 07:50:29.237	2026-02-21 07:50:29.242
22	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-21 07:56:19.697	2026-02-21 07:56:19.707
23	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-22 08:03:11.638	2026-02-22 08:03:11.661
24	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-22 08:08:12.057	2026-02-22 08:08:12.069
25	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-22 08:13:12.563	2026-02-22 08:13:12.572
26	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-22 08:18:12.563	2026-02-22 08:18:12.568
27	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-22 08:21:00.084	2026-02-22 08:21:00.091
28	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-22 08:49:54.265	2026-02-22 08:49:54.289
29	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-22 08:50:06.898	2026-02-22 08:50:06.907
30	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-22 08:50:20.748	2026-02-22 08:50:20.755
31	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-22 08:50:47.106	2026-02-22 08:50:47.115
32	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-22 09:28:26.17	2026-02-22 09:28:26.182
33	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-22 09:32:44.936	2026-02-22 09:32:44.942
34	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-22 09:32:49.686	2026-02-22 09:32:49.694
35	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-22 09:36:19.766	2026-02-22 09:36:19.934
36	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-22 09:39:07.029	2026-02-22 09:39:07.043
37	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-02-22 09:40:40.931	2026-02-22 09:40:40.936
38	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-23 10:45:08.033	2026-02-23 10:45:08.053
39	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-23 10:50:08.56	2026-02-23 10:50:08.569
40	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-23 10:55:08.821	2026-02-23 10:55:08.828
41	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-23 11:12:48.478	2026-02-23 11:12:48.484
42	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-23 11:12:51.466	2026-02-23 11:12:51.47
43	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-23 11:16:47.688	2026-02-23 11:16:47.695
44	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-23 11:16:49.592	2026-02-23 11:16:49.601
45	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-23 11:17:16.193	2026-02-23 11:17:16.201
46	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-23 11:17:18.488	2026-02-23 11:17:18.498
47	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-23 11:31:20.172	2026-02-23 11:31:20.179
48	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-23 11:31:22.287	2026-02-23 11:31:22.296
49	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-23 11:31:30.729	2026-02-23 11:31:30.736
50	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-25 15:37:12.959	2026-02-25 15:37:12.971
51	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-25 15:37:32.598	2026-02-25 15:37:32.606
52	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:12:28.424	2026-02-26 06:12:28.432
53	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:12:39.081	2026-02-26 06:12:39.085
54	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:13:16.319	2026-02-26 06:13:16.472
55	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:14:09.986	2026-02-26 06:14:09.997
56	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:14:12.075	2026-02-26 06:14:12.08
57	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:14:16.76	2026-02-26 06:14:16.766
58	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:14:56.183	2026-02-26 06:14:56.189
59	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:15:01.534	2026-02-26 06:15:01.54
60	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:15:09.687	2026-02-26 06:15:09.693
61	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:15:14.354	2026-02-26 06:15:14.362
62	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:16:00.673	2026-02-26 06:16:00.683
63	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:21:00.72	2026-02-26 06:21:00.725
64	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:26:01.577	2026-02-26 06:26:01.585
65	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:31:02.075	2026-02-26 06:31:02.08
66	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:36:02.877	2026-02-26 06:36:02.884
67	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:41:03.11	2026-02-26 06:41:03.117
68	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:46:03.88	2026-02-26 06:46:03.885
69	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:51:04.455	2026-02-26 06:51:04.463
70	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 06:56:05.254	2026-02-26 06:56:05.259
71	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 07:01:05.295	2026-02-26 07:01:05.3
72	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 07:06:06.205	2026-02-26 07:06:06.21
73	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 07:11:06.328	2026-02-26 07:11:06.335
74	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 07:16:21.093	2026-02-26 07:16:21.098
75	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 07:21:21.066	2026-02-26 07:21:21.077
76	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 07:26:21.046	2026-02-26 07:26:21.051
77	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 07:26:52.48	2026-02-26 07:26:52.5
78	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 07:31:52.463	2026-02-26 07:31:52.469
79	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 07:36:52.892	2026-02-26 07:36:52.897
80	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 07:41:53.78	2026-02-26 07:41:53.785
81	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 07:46:53.918	2026-02-26 07:46:53.924
82	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 07:51:53.906	2026-02-26 07:51:53.912
83	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 07:56:53.913	2026-02-26 07:56:53.919
84	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 08:01:53.917	2026-02-26 08:01:53.922
85	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 08:06:53.912	2026-02-26 08:06:53.918
86	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 08:11:53.924	2026-02-26 08:11:53.929
87	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 08:16:54.775	2026-02-26 08:16:54.78
88	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 08:21:55.19	2026-02-26 08:21:55.195
89	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 08:26:55.488	2026-02-26 08:26:55.493
90	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 08:31:55.704	2026-02-26 08:31:55.711
91	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 10:20:57.993	2026-02-26 10:20:58.003
92	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-26 10:25:58.197	2026-02-26 10:25:58.205
93	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-02-28 03:12:10.607	2026-02-28 03:12:10.63
94	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 08:04:23.943	2026-02-28 08:04:23.96
95	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 08:04:34.845	2026-02-28 08:04:34.851
96	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 08:04:43.934	2026-02-28 08:04:43.939
97	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 08:05:08.715	2026-02-28 08:05:08.722
98	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 08:10:08.952	2026-02-28 08:10:08.958
99	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 08:15:44.251	2026-02-28 08:15:44.262
100	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 08:43:55.058	2026-02-28 08:43:55.063
101	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 08:48:20.061	2026-02-28 08:48:20.07
102	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 08:53:55.06	2026-02-28 08:53:55.07
103	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 08:58:55.115	2026-02-28 08:58:55.123
104	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 09:03:56.092	2026-02-28 09:03:56.105
105	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 09:04:27.365	2026-02-28 09:04:27.371
106	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 09:05:07.856	2026-02-28 09:05:07.867
107	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 09:10:08.086	2026-02-28 09:10:08.091
108	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 09:15:08.098	2026-02-28 09:15:08.111
109	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 09:17:26.62	2026-02-28 09:17:26.631
110	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 09:17:36.689	2026-02-28 09:17:36.693
111	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 09:18:48.254	2026-02-28 09:18:48.261
112	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 09:23:09.703	2026-02-28 09:23:09.717
113	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 09:28:10.107	2026-02-28 09:28:10.121
114	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 09:33:10.09	2026-02-28 09:33:10.096
115	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 09:38:10.079	2026-02-28 09:38:10.084
116	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 09:43:10.069	2026-02-28 09:43:10.074
117	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 09:48:10.086	2026-02-28 09:48:10.095
118	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 09:53:10.075	2026-02-28 09:53:10.081
119	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 09:58:10.116	2026-02-28 09:58:10.126
120	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 10:03:09.727	2026-02-28 10:03:09.735
121	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 10:08:10.093	2026-02-28 10:08:10.099
122	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 10:14:06.121	2026-02-28 10:14:06.128
123	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 10:19:06.098	2026-02-28 10:19:06.103
124	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 10:23:10.108	2026-02-28 10:23:10.118
125	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 10:29:06.144	2026-02-28 10:29:06.15
126	1	device-1772265863889-3yumwewiu	upload	success	0	0	0	\N	2026-02-28 10:34:06.107	2026-02-28 10:34:06.118
127	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-03-01 03:51:11.781	2026-03-01 03:51:11.788
128	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-01 13:26:08.006	2026-03-01 13:26:08.011
129	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-01 13:26:10.161	2026-03-01 13:26:10.166
130	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-03 09:41:38.312	2026-03-03 09:41:38.319
131	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-03 09:42:00.456	2026-03-03 09:42:00.461
132	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-03 10:01:51.603	2026-03-03 10:01:51.611
133	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-03-04 14:22:48.401	2026-03-04 14:22:48.416
134	1	device-1771153470412-j1elif1ye	upload	success	0	0	0	\N	2026-03-04 14:23:04.177	2026-03-04 14:23:04.182
135	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-12 07:03:07.377	2026-03-12 07:03:07.397
136	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 07:51:34.171	2026-03-14 07:51:34.184
137	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 07:56:34.587	2026-03-14 07:56:34.592
138	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 08:01:34.787	2026-03-14 08:01:34.792
139	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 08:06:34.809	2026-03-14 08:06:34.815
140	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 08:11:35.691	2026-03-14 08:11:35.696
141	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 08:16:35.677	2026-03-14 08:16:35.683
142	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 08:21:36.448	2026-03-14 08:21:36.453
143	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 08:26:37.213	2026-03-14 08:26:37.221
144	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 08:31:38.009	2026-03-14 08:31:38.014
145	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 08:36:38.726	2026-03-14 08:36:38.731
146	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 08:41:39.496	2026-03-14 08:41:39.501
147	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 08:46:40.399	2026-03-14 08:46:40.404
148	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 08:51:41.24	2026-03-14 08:51:41.249
149	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 08:56:41.243	2026-03-14 08:56:41.248
150	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 09:01:42.117	2026-03-14 09:01:42.123
151	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 09:06:42.931	2026-03-14 09:06:42.936
152	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 09:11:42.943	2026-03-14 09:11:42.948
153	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 09:16:43.804	2026-03-14 09:16:43.809
154	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 09:21:44.548	2026-03-14 09:21:44.554
155	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 09:26:44.546	2026-03-14 09:26:44.55
156	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 09:31:45.434	2026-03-14 09:31:45.439
157	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 09:36:45.437	2026-03-14 09:36:45.444
158	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 09:41:46.195	2026-03-14 09:41:46.2
159	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 09:46:46.953	2026-03-14 09:46:46.959
160	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 09:51:47.63	2026-03-14 09:51:47.64
161	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 09:56:48.455	2026-03-14 09:56:48.466
162	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 10:01:49.167	2026-03-14 10:01:49.173
163	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 10:06:50.011	2026-03-14 10:06:50.017
164	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 10:11:50.734	2026-03-14 10:11:50.742
165	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 10:16:51.426	2026-03-14 10:16:51.432
166	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 10:21:52.218	2026-03-14 10:21:52.223
167	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 10:26:53.089	2026-03-14 10:26:53.094
168	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 10:31:53.836	2026-03-14 10:31:53.841
169	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 10:36:54.661	2026-03-14 10:36:54.666
170	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 10:41:55.49	2026-03-14 10:41:55.495
171	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 10:46:56.313	2026-03-14 10:46:56.318
172	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 10:51:56.317	2026-03-14 10:51:56.329
173	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 10:56:57.134	2026-03-14 10:56:57.139
174	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 11:01:57.928	2026-03-14 11:01:57.932
175	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 11:06:58.744	2026-03-14 11:06:58.749
176	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 11:11:58.78	2026-03-14 11:11:58.784
177	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 11:16:59.621	2026-03-14 11:16:59.626
178	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 11:22:00.431	2026-03-14 11:22:00.436
179	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 11:27:00.431	2026-03-14 11:27:00.441
180	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 11:32:01.311	2026-03-14 11:32:01.316
181	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 11:37:01.992	2026-03-14 11:37:01.997
182	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 11:42:02.711	2026-03-14 11:42:02.719
183	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 11:47:03.464	2026-03-14 11:47:03.47
184	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 11:52:04.363	2026-03-14 11:52:04.368
185	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 11:57:05.167	2026-03-14 11:57:05.171
186	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 12:02:05.91	2026-03-14 12:02:05.925
187	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 12:07:06.731	2026-03-14 12:07:06.736
188	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 12:12:06.756	2026-03-14 12:12:06.767
189	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 12:17:07.539	2026-03-14 12:17:07.543
190	1	device-1770991813972-a6ptnqrmx	upload	success	0	0	0	\N	2026-03-14 12:22:08.344	2026-03-14 12:22:08.357
\.


--
-- Data for Name: Theme; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Theme" (id, user_id, preset, custom_colors, dark_mode, high_contrast, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: Ticket; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."Ticket" (id, title, description, status, response, creator_id, created_at, updated_at, type, priority, tags, category, dependencies, is_deleted) FROM stdin;
1	test	test	pending	\N	\N	2026-02-14 11:11:41.689	2026-02-14 11:11:41.689	feature	low	\N	\N	\N	t
3	Dark mode review	There are a bunch of components that dont listen to dark mode. please review all the vue models	completed	Reviewed and fixed dark mode support across Vue components. Updated 78 files to use CSS variables instead of hardcoded colors, and removed unnecessary dark mode overrides from 38 files. Components now properly respond to dark mode state changes via theme CSS variables (--theme-background, --theme-text, --theme-primary, --theme-secondary, --theme-accent, --theme-card-bg). All changes deployed.	creator-1771212178779-gz8u15y	2026-02-16 03:25:44.31	2026-02-16 03:25:44.31	feature	medium	\N	\N	\N	f
4	Nav Bar updates	The breadcrumbs could be integrated into the nav bar so it doesnt appear as a separate bunch of cards. this should make the design clearer	completed	Integrated breadcrumbs into the nav bar (Ticket #4)\n\nChanges made:\n- Modified Router.vue to include breadcrumb logic and display\n- Added Router-breadcrumb.css for integrated breadcrumb styling  \n- Removed separate Breadcrumb component from MainApp.vue\n- Breadcrumbs now display inline within the nav bar instead of as separate cards\n- Maintained all existing breadcrumb functionality (icons, separators, truncation)\n- Breadcrumbs are hidden on home page and in performance mode\n\nDeployment is in progress - the code changes are complete and the build is running.	creator-1771212178779-gz8u15y	2026-02-16 03:27:57.193	2026-02-16 03:27:57.193	feature	medium	\N	\N	\N	f
5	Remove all SQLite references	SQLite should be completely removed from the codebase. Remaining references to clean up:\n- scripts/migrate-sqlite-to-postgres.sh (can be archived/deleted)\n- scripts/archive/* directory contains sqlite-based scripts (consider deleting entire archive)\n\nAll main application code (server/src) no longer uses sqlite. Prisma schema uses postgres only. No sqlite dependencies in package.json.	completed	All SQLite features migrated to PostgreSQL. 9 files migrated (characters, shop, tickets, sync, search, reactions, farts, profiles, favorites). Added UserDevice and SyncLog models to Prisma schema. Removed better-sqlite3 dependencies. Cleanup done: scripts/archive-root/ removed. Build successful. Ready for testing.	mhear22	2026-02-16 22:40:12.249	2026-02-16 22:40:12.249	task	medium	\N	\N	\N	f
6	Add bow emoji button to navcontrols bar - plays sound on loop	User Orlando (bellicapelli) requested a button on the navcontrols bar that:\n\n- Plays the attached sound file on loop when clicked\n- Uses a bow emoji 🎀 as the icon\n\nThe sound file has been provided and should be added to the project.\n\nRequest from: Orlando in Discord\n\nAudio file saved to: frontend/public/audio/bow-button-sound.wav (401KB)	completed	Bow emoji button (🎀) has been added to the navcontrols bar. The button plays the bow-button-sound.wav file on loop when clicked, and can be toggled on/off. The audio file is in place, the button is properly wired to the useAudio composable's toggleBowSound function, and everything is working correctly. The feature includes proper ARIA labels, active state styling, and integrates seamlessly with the existing nav-controls bar.	discord	2026-02-18 10:15:09.316	2026-02-18 10:15:09.316	feature	maximum	\N	\N	\N	f
7	I18N translation	We have users who's primary language isnt english. Give people the ability to change the language to something else and have the whole site respect it. Start with English, Chinese, and Japanese.	completed	Implemented full I18N translation support with English, Chinese (Simplified), and Japanese. Created translation files, language selector components, and integrated vue-i18n. Language preference persists in localStorage and auto-detects browser locale. Build successful and ready for deployment.	creator-1771079368671-b1btyc3	2026-02-21 07:35:42.366	2026-02-21 07:35:42.366	feature	medium	\N	\N	\N	f
8	i18n translations update	Please allow overwriting of the auto detected language in settings and allow users to set their own.\n\nAlso make sure that there is a US and AU versions of english.	completed	Implemented i18n language settings feature - users can now manually override auto-detected language in Settings. Added browser language detection, manual override UI, reset to auto-detect option, and backward compatibility support.	creator-1771748431634-0ns0o10	2026-02-22 08:22:38.651	2026-02-22 08:22:38.651	feature	medium	\N	\N	\N	f
15	Test Ticket Auth Check	This ticket tests auth	pending	\N	test-user-123	2026-02-25 12:09:21.713	2026-02-25 12:09:21.713	feature	medium	\N	\N	\N	t
14	Test Ticket to Delete	This ticket will be deleted	pending	\N	test-user-123	2026-02-25 12:09:21.68	2026-02-25 12:09:21.68	feature	medium	\N	\N	\N	t
9	Test Ticket for Update	This ticket will be updated	completed		test-user-123	2026-02-25 12:08:23.8	2026-02-25 12:08:23.8	feature	medium	\N	\N	\N	f
10	Test Ticket to Delete	This ticket will be deleted	completed		test-user-123	2026-02-25 12:08:23.903	2026-02-25 12:08:23.903	feature	medium	\N	\N	\N	f
11	Test Ticket	This is a test ticket description	completed		test-user-123	2026-02-25 12:09:21.266	2026-02-25 12:09:21.266	feature	medium	\N	\N	\N	f
12	Test Ticket No Description	Auto-generated description	completed		\N	2026-02-25 12:09:21.341	2026-02-25 12:09:21.341	feature	medium	\N	\N	\N	f
13	Updated Title	Updated description	completed		test-user-123	2026-02-25 12:09:21.596	2026-02-25 12:09:21.596	feature	medium	\N	\N	\N	f
16	Add Vibe Coding Instructions Page	Create a new page for instructions on how to vibe code.\n\n**Features:**\n- Model selector: Opus, Sonnet, GLM 5, GPT Codex, Gemini, Local models\n- Tooling recommendations for CLI (Claude Code, Opencode, Codex CLI, Copilot CLI)\n- Tooling recommendations for GUI (Claude Cowork, Codex app, Antigravity, Cursor, Z Code)\n- Show best approach for each model/tool combination\n\n**Examples of relationships:**\n- Opus/Sonnet: Best through Claude Code or Claude Cowork (first class)\n- Claude Code: Opus/Sonnet first class, GLM 5 works with asterisk\n- Cursor: Supports most models but not first class approach\n\n**Requested by:** Mika (mhear22)	completed	Created VibeCodingPage.vue with model selector, CLI/GUI tool recommendations, and quick reference table. Deployed and live at /vibe-coding	mhear22	2026-02-26 06:02:14.579	2026-02-26 06:02:14.579	feature	high	\N	\N	\N	f
17	Mobile support	The site currently doesnt have very stable mobile support. the nav doesnt work (closes when you try and pick a page) and the app doesnt have the same featureset as desktop. please update the app to be consistent between the two	completed	Fixed mobile navigation issue. Added delayed menu closing to allow Vue Router navigation to complete, improved z-index stacking for backdrop, and added touch-action CSS properties to prevent double-tap zoom issues on mobile.	creator-1771079368671-b1btyc3	2026-03-03 10:04:06.195	2026-03-03 10:04:06.195	feature	medium	\N	\N	\N	f
2	Oled Mode	We have custom themes but no oled mode. Replace the sunset theme with Oled theme and use full blacks to reduce burn in.	completed	Added comprehensive CSS styling with pink gradient backgrounds, animated particles, feature cards, responsive design, dark mode support, and reduced-motion preferences.	creator-1771212178779-gz8u15y	2026-02-16 03:25:07.959	2026-02-16 03:25:07.959	feature	medium	\N	\N	\N	f
18	Vibe coding page looks weird	Looks like the cards arent being styled correctly	completed	Fixed CSS card styling by moving :root CSS variables to component-level .vibe-coding-page class. Vue scoped styles don't properly handle :root selector.	creator-1773636124702-vz9hq5t	2026-03-16 04:42:29.213	2026-03-16 04:42:29.213	feature	medium	\N	\N	\N	f
19	Vibe coding page	Id like it to be optimized showing all the subscriptions (Claude, OpenAI, Z.ai, Cursor, Gemini) and what tooling you get access too. Open weight models also has to have an option. if you need prices for these subs, let me know otherwise look them up.	completed	Added optimized subscriptions section showing Claude, OpenAI, Z.ai, Cursor, and Gemini with clean card layout, pricing, and key features.	creator-1773636124702-vz9hq5t	2026-03-16 04:44:38.146	2026-03-16 04:44:38.146	feature	medium	\N	\N	\N	f
20	Site Review Findings	# Codebase Review Findings\n\n## Overview\nReviewed the seethbotsite codebase for improvements across UX, performance, features, and code quality. The codebase is generally well-structured with good patterns (Pinia Setup Stores, composables, repository pattern, TypeScript everywhere). Below are actionable recommendations.\n\n---\n\n## 🔮 UX Improvements\n\n### 1. Large Component Refactoring (High Priority)\n**Files:** OrbitalMechanicsPage.vue (1561 lines), MechBattlePage.vue (1542 lines), ShopPage.vue (1187 lines)\n\n**Issue:** These components are too large for maintainability and make it harder to reason about component responsibilities, test individual pieces, and reuse logic across pages.\n\n**Recommendation:** Break into smaller sub-components: extract canvas/rendering logic into composables, create UI sub-components for controls/info panels, use component composition over monolithic templates.\n\n### 2. Loading State Consistency\n**Issue:** Loading states are inconsistent - some pages show skeleton loaders, others show nothing, some show generic Loading text.\n\n**Recommendation:** Create a unified loading component (PageLoader.vue), standardize on skeleton loaders for content-heavy pages, add loading transitions to prevent layout shift.\n\n### 3. Error Message UX\n**Issue:** Error messages are technical rather than user-friendly.\n\n**Recommendation:** Create user-facing error message mapping, add error boundary components, show actionable error messages.\n\n### 4. Mobile Navigation Enhancement\n**Issue:** Mobile navigation relies primarily on FAB - could be enhanced for discoverability.\n\n**Recommendation:** Consider bottom navigation bar, add swipe-to-navigate, improve touch target sizes.\n\n---\n\n## ⚡ Performance Optimizations\n\n### 1. Rate Limiter Memory Management (High Priority)\n**File:** backend/src/middleware.ts\n\n**Issue:** In-memory rate limiter cleans up every 5 minutes but could grow unbounded under high traffic.\n\n**Recommendation:** Use bounded Map with LRU eviction, consider rate-limiter-flexible with Redis for production, add monitoring for store size.\n\n### 2. Three.js Resource Management\n**File:** OrbitalMechanicsPage.vue\n\n**Issue:** Three.js resources need explicit disposal to prevent memory leaks.\n\n**Recommendation:** Ensure all Three.js objects are disposed in onUnmounted, use dispose() pattern consistently, consider resource manager.\n\n### 3. Component-Level Code Splitting\n**Issue:** Very large components could benefit from further splitting.\n\n**Recommendation:** Use dynamic imports for heavy sub-components, consider defineAsyncComponent for conditional features.\n\n### 4. Polling Optimization\n**File:** usePolling.ts\n\n**Recommendation:** Increase max interval for non-critical data, add visibility-based pausing, consider WebSocket for real-time data.\n\n---\n\n## ✨ Feature Enhancements\n\n### 1. Sync Conflict Resolution UI (High Priority)\n**File:** useSync.ts\n\n**Issue:** Sync system tracks conflicts but lacks UI for resolution.\n\n**Recommendation:** Create SyncConflictModal.vue, allow users to choose versions, add merge option.\n\n### 2. Enhanced Search with Filters\n**Recommendation:** Add filters by content type, implement search history, add keyboard navigation, consider fuzzy matching.\n\n### 3. Contextual Keyboard Shortcuts\n**Recommendation:** Filter shortcuts by current route, highlight available shortcuts, add shortcut hints to UI elements.\n\n### 4. Rankings Trend Indicators\n**Recommendation:** Add up/down arrows for rank changes, show new badge, display historical chart.\n\n### 5. Enhanced PWA Support\n**Recommendation:** Cache frequently accessed API responses, add offline indicator UI, implement background sync.\n\n---\n\n## 🐛 Bug Fixes & Code Quality\n\n### 1. Memory Leak Audit (High Priority)\n**Issue:** Some composables may have subtle leaks.\n\n**Recommendation:** Audit all composables for event listener cleanup, ensure intervals/timeouts cleared, add ESLint rule.\n\n### 2. TypeScript Strict Mode\n**Recommendation:** Enable noUncheckedIndexedAccess and exactOptionalPropertyTypes, fix resulting errors.\n\n### 3. Error Handling in Composables\n**Recommendation:** Standardize error state pattern, add retry mechanisms, log errors consistently.\n\n### 4. Test Coverage Expansion\n**Recommendation:** Add E2E tests for auth flow, integration tests for sync, test WebSocket scenarios, add visual regression tests.\n\n### 5. Configuration Externalization\n**Recommendation:** Move hardcoded values to config files/env vars, document options, add validation.\n\n---\n\n## 📊 Summary\n\n| Category | High Priority | Medium Priority | Low Priority |\n|----------|--------------|-----------------|--------------|\n| UX | 1 | 3 | 1 |\n| Performance | 2 | 2 | 0 |\n| Features | 1 | 4 | 0 |\n| Code Quality | 2 | 3 | 0 |\n\n**Total Recommendations:** 19\n\n**Estimated Effort:**\n- High Priority items: ~2-3 weeks\n- Medium Priority items: ~3-4 weeks\n- Low Priority items: ~1 week\n\n---\n\n## 🏆 Strengths Observed\n\n1. Good Architecture: Pinia Setup Stores, composables, repository pattern\n2. Memory Leak Awareness: App.vue has proper cleanup comments\n3. Security: Good middleware stack, input validation, rate limiting\n4. Documentation: DECISIONS.md provides good context\n5. Testing Foundation: Tests exist for key composables and repositories\n6. Accessibility: Skip links, keyboard navigation support\n\n---\n\n*Review completed: 2026-03-20*	completed	Implemented high-priority improvements from site review:\n\n✅ **Rate Limiter Memory Management (High Priority)**\n- Added bounded Map with 10,000 entry limit\n- Implemented LRU eviction (removes bottom 20% when limit exceeded)\n- Added lastAccessed tracking for proper LRU behavior\n- Added monitoring logs for store size tracking\n- Prevents unbounded memory growth under high traffic\n\n✅ **Three.js Resource Management (High Priority)**\n- Verified existing cleanup implementation is comprehensive\n- All geometries, materials, textures, and renderers properly disposed\n- Cleanup called in onUnmounted hook\n- No changes needed - already well-implemented\n\n✅ **Unified Loading Component**\n- Created PageLoader.vue component\n- Supports full-page and inline loading states\n- Includes spinner and skeleton loader styles\n- Standardizes loading UX across pages\n\n✅ **Error Boundary Component**\n- Created ErrorBoundary.vue component\n- Maps technical errors to user-friendly messages\n- Provides retry and go home actions\n- Optional technical details for debugging\n- Catches and displays errors gracefully\n\n✅ **Polling Optimization (Medium Priority)**\n- Enhanced usePolling composable with visibility-based pausing\n- Automatically pauses polling when tab is hidden\n- Resumes polling when tab becomes visible\n- Configurable via pauseOnHidden option (default: true)\n- Saves resources and improves performance\n\n✅ **Sync Conflict Resolution UI (High Priority)**\n- Created SyncConflictModal.vue component\n- Displays local vs remote versions side-by-side\n- Supports local, remote, or merge resolution options\n- Batch resolution for all conflicts\n- User-friendly interface with loading states\n\n**Files Modified:**\n- backend/src/middleware.ts (Rate limiter improvements)\n- frontend/composables/usePolling.ts (Visibility pausing)\n\n**Files Created:**\n- frontend/components/shared/PageLoader.vue\n- frontend/components/shared/ErrorBoundary.vue\n- frontend/components/shared/SyncConflictModal.vue\n\n**Testing:**\n- Frontend build successful\n- All components follow existing patterns\n- TypeScript compatible\n\n**Note:** Deployment attempted but may require manual deployment via ./deploy.sh	\N	2026-03-20 18:09:35.684	2026-03-20 18:09:35.684	review	medium	\N	improvement	\N	f
21	Site Review: 2026-03-22	Comprehensive codebase review identifying critical security vulnerabilities, performance issues, and improvement opportunities. See /tmp/site-review-2026-03-22.md for full details.	completed	Reviewed by user. Decision: Remove subscription system entirely - users should have full access without subscription. Critical auth fixes (token validation) still needed but subscription controller should be deleted, not fixed.	\N	2026-03-21 18:23:19.218	2026-03-21 18:23:19.218	review	high	\N	code-quality	\N	f
22	Remove Subscription System	Remove the subscription system entirely. Users should be able to login and have full access regardless of subscription status.\n\nFiles to review/remove:\n- backend/src/controllers/subscription.controller.ts\n- Any related routes, models, and frontend components\n\nGoal: Simplify auth - logged in users get full access, no subscription tiers needed.	completed	Removed subscription system: deleted backend controller/middleware, removed routes, updated Prisma schema, applied migration. All logged-in users now have full access.	\N	2026-03-22 11:58:56.767	2026-03-22 11:58:56.767	feature	high	\N	\N	\N	f
23	Weekly Site Review - 2026-03-24	# Weekly Site Review - March 24, 2026\n\n## Overview\nComprehensive codebase review covering UX, performance, bugs, and feature enhancements.\n\n## 🔴 Critical Issues\n\n### 1. Memory Leak in UIEffectsStore - Chaos Mode\n**Location:** `frontend/stores/useUIEffectsStore.ts`\n**Issue:** The `stopChaosEffects()` function clears the `chaosIntervals` array but does not clear individual intervals first, potentially leaving orphaned intervals.\n**Recommendation:** Verify intervals are properly tracked and cleared. Consider using a Set for interval IDs.\n\n### 2. Mold Circle Growth Intervals Not Cleaned\n**Location:** `frontend/stores/useUIEffectsStore.ts` - `createMoldCircle()`\n**Issue:** Growth intervals created inside `createMoldCircle` are not tracked for cleanup. If mold mode is toggled rapidly, intervals could accumulate.\n**Recommendation:** Track all growth intervals in an array and clear them in `stopMoldSpawner()` or `clearMoldCircles()`.\n\n### 3. Token Refresh Retry Memory Leak\n**Location:** `frontend/stores/useAuthStore.ts` - `refreshToken()`\n**Issue:** On network errors, retry is scheduled with `setTimeout(() => refreshToken(), 5 * 60 * 1000)` but the timeout ID is not stored for cleanup.\n**Recommendation:** Store retry timeout ID and clear it in `clearAuth()`.\n\n---\n\n## 🟡 Performance Optimizations\n\n### 4. Rate Limiting Could Use Burst Protection\n**Location:** `backend/src/middleware.ts`\n**Issue:** Current rate limiter uses 10,000 req/min sliding window. While appropriate for real-time gameplay, it lacks burst protection which could allow short-term abuse.\n**Recommendation:** Add a secondary short-window limit (e.g., 100 req/sec) for burst protection.\n\n### 5. OptimizedImage Component Underutilized\n**Location:** Various Vue components\n**Issue:** The `OptimizedImage.vue` component exists but may not be used consistently across the codebase for all images.\n**Recommendation:** Audit all `<img>` tags and replace with OptimizedImage where appropriate.\n\n### 6. Consider Virtual Scrolling for Long Lists\n**Location:** Ticket lists, rankings, etc.\n**Issue:** Long lists (tickets, rankings) could benefit from virtual scrolling to reduce DOM nodes.\n**Recommendation:** Implement virtual scrolling for lists that could exceed 50+ items.\n\n---\n\n## 🟢 UX Improvements\n\n### 7. Missing ARIA Labels on Some Interactive Elements\n**Issue:** Some buttons and interactive elements lack proper ARIA labels for screen readers.\n**Recommendation:** Audit interactive elements and add aria-labels where missing, especially for icon-only buttons.\n\n### 8. Mobile Navigation Could Use Hints\n**Issue:** Mobile users may not discover swipe gestures without guidance.\n**Recommendation:** Add a one-time onboarding tooltip for swipe gestures on first mobile visit.\n\n### 9. Error Messages Could Be More Specific\n**Location:** Various API error responses\n**Issue:** Some error messages are generic.\n**Recommendation:** Provide more actionable error messages where possible.\n\n---\n\n## 🔵 Feature Enhancements\n\n### 10. Offline Support Enhancement\n**Location:** `frontend/composables/useSync.ts`\n**Issue:** Offline queue exists but has limited implementation.\n**Recommendation:** Expand offline queue to capture all write operations for true offline-first experience.\n\n### 11. Service Worker Update Check\n**Location:** `frontend/public/sw.js`\n**Issue:** Service worker exists but no mechanism to notify users of updates.\n**Recommendation:** Add update notification UI when new service worker version is available.\n\n### 12. Search Enhancement\n**Location:** `frontend/components/shared/ui/SearchModal.vue`\n**Recommendation:** Add fuzzy search capabilities and search history for better UX.\n\n---\n\n## ✅ What is Working Well\n\n1. Memory Leak Fixes in App.vue\n2. Polling System with visibility-based pausing\n3. Strong TypeScript usage\n4. Clean store/composable architecture\n5. Good security practices\n6. Smart performance mode defaults for mobile\n7. Comprehensive keyboard shortcuts\n8. Well-designed auth system\n\n---\n\n## Action Items\n\n**High Priority:**\n- [ ] Fix chaos mode interval cleanup\n- [ ] Fix mold circle growth interval tracking\n- [ ] Store token refresh retry timeout for cleanup\n\n**Medium Priority:**\n- [ ] Add burst rate limiting\n- [ ] Audit image component usage\n- [ ] Add ARIA labels audit to backlog\n\n**Low Priority:**\n- [ ] Enhance offline queue\n- [ ] Add service worker update notification\n- [ ] Implement virtual scrolling for long lists\n\n---\n\n*Review conducted: 2026-03-24*\n*Lines of code reviewed: ~33,500+*\n*Files examined: 50+ frontend/backend files*	completed	Fixed all three critical memory leak issues:\n\n1. **Chaos mode intervals** - Added proper cleanup in stopChaosEffects() and exposed cleanup() function to clear all intervals on component unmount\n2. **Mold circle growth intervals** - Now tracking all growth intervals in moldGrowthIntervals array and clearing them in clearMoldCircles()\n3. **Token refresh retry timeout** - Added refreshRetryTimer variable to track retry timeouts and clear them on logout in clearAuth()\n\nAll fixes ensure proper cleanup on component unmount via App.vue onUnmounted hook calling uiEffectsStore.cleanup(). TypeScript checks passed, build succeeded, and deployment completed successfully.	\N	2026-03-23 18:19:12.252	2026-03-23 18:19:12.252	feature	medium	\N	\N	\N	f
28	Test Ticket Auth Check	This ticket tests auth	pending	\N	test-user-123	2026-03-25 18:15:46.631	2026-03-25 18:15:46.631	feature	medium	\N	\N	\N	t
27	Test Ticket to Delete	This ticket will be deleted	pending	\N	test-user-123	2026-03-25 18:15:46.603	2026-03-25 18:15:46.603	feature	medium	\N	\N	\N	t
24	Test Ticket	This is a test ticket description	declined	Test ticket - declining as artifact from ticket system development	test-user-123	2026-03-25 18:15:45.933	2026-03-25 18:15:45.933	feature	medium	\N	\N	\N	f
25	Test Ticket No Description	Auto-generated description	declined	Test ticket - declining as artifact from ticket system development	\N	2026-03-25 18:15:46.079	2026-03-25 18:15:46.079	feature	medium	\N	\N	\N	f
26	Updated Title	Updated description	declined	Test ticket - declining as artifact from ticket system development	test-user-123	2026-03-25 18:15:46.517	2026-03-25 18:15:46.517	feature	medium	\N	\N	\N	f
39	Site Review - April 11 2026	SECURITY: CORS wide open (cors() no config), stock/click/points endpoints unauthenticated (requireApiKey commented out), shop purchase race condition (in-memory deduct + separate DB write), messages controller missing await on async calls, bio/avatar/banner fields not sanitized (stored XSS risk), no global body size limit, in-memory rate limiter unbounded. BUGS: Mining claim no completion check, mining progress lost on restart, click-to-points O(n) loop, sync resolve is no-op. UX: No inventory pagination, N+1 conversations, no real-time messaging, no email verification, no password complexity, no avatar dimension validation.	completed	CORS already configured with origin whitelist. Stock/click endpoints already have requireApiKey middleware. Applied additional fixes: sanitized bio/avatar/banner/status fields (XSS prevention), added auth rate limiting (20 req/15min for register/login).	\N	2026-04-10 18:41:27.887	2026-04-10 18:41:27.887	feature	high	\N	security	\N	f
29	Weekly Site Review	## 🔴 Bugs\n\n1. **Incomplete JWT validation in sync.controller.ts (line 26)**\n   - TODO comment indicates token validation is mocked\n   - Uses insecure base64 decode without proper verification\n   - Could allow unauthorized access to sync endpoints\n\n2. **Placeholder points system in shop.controller.ts (line 318)**\n   - Returns hardcoded 1000 points instead of actual user points\n   - Purchase flow is incomplete - points not actually deducted\n\n## 🟡 Performance & Code Quality\n\n3. **Excessive `any` type usage (257 instances)**\n   - Significantly reduces TypeScript type safety\n   - Concentrated in composables and services\n   - Recommend: Add strict TypeScript checks incrementally\n\n4. **Console.log statements in production code**\n   - Found in: useFartAudio, useSync, useSpeechSynthesis, useVoiceNavigation, useAudio\n   - Should use debug flag or remove for production\n   - Consider: Create a logger utility with debug levels\n\n5. **Deprecated useAuth.ts composable still exists**\n   - Marked deprecated but no removal timeline\n   - Causes confusion about which to use (store vs composable)\n\n## 🔵 Infrastructure & Cleanup\n\n6. **Uncommitted subscription system removal**\n   - Deleted files not staged: subscription.controller.ts, subscription middleware\n   - Uncommitted migration: `20260322182607_remove_subscription_system`\n   - Action: Complete the removal or document rollback plan\n\n7. **Backup files not in .gitignore**\n   - Daily/weekly/monthly backup .sql.gz files showing as untracked\n   - Should be excluded from version control\n   - Add: `backups/postgres/**/*.sql.gz` to .gitignore\n\n## 🟢 Minor Enhancements\n\n8. **Rate limiter logs to console every 5 min**\n   - Consider reducing frequency or using debug level\n   - Current: logs store size even when no cleanup needed\n\n9. **Missing error boundary component**\n   - ErrorBoundary.vue exists but not integrated into main app\n   - Would improve UX for JavaScript errors\n\n## Priority Recommendation\n\n1. Fix JWT validation (security)\n2. Complete subscription cleanup (code hygiene)\n3. Update .gitignore for backups (housekeeping)\n4. Address `any` types incrementally (technical debt)	completed	Fixed both security issues: (1) JWT validation now uses proper token verification via validateTokenAndGetUser() instead of insecure base64 decode. (2) Shop purchase endpoint now actually checks and deducts points using pointsManager instead of returning hardcoded 1000 points. Both fixes compile and pass tests.	\N	2026-03-25 18:17:40.384	2026-03-25 18:17:40.384	bug	low	\N	\N	\N	f
30	Codebase Review: UX, Performance, Bug Fixes & Feature Recommendations	# Seethbotsite Codebase Review - Improvement Recommendations\n\n## Overview\nReviewed the full codebase (Vue 3 frontend + Express/TypeScript backend with Prisma) for improvement opportunities.\n\n---\n\n## 🎨 UX IMPROVEMENTS\n\n### 1. Console.log Cleanup (298 statements)\n- **Issue:** 298 console statements in frontend code\n- **Impact:** Clutters production, minor performance overhead\n- **Recommendation:** Create a logger utility that respects NODE_ENV, strip console.* in production build\n- **Priority:** Low\n\n### 2. Accessibility Enhancements\n- **Current:** 331 aria/role/alt attributes (good coverage)\n- **Gaps:** Missing skip-to-content links on some pages, focus trap management in modals, color contrast in darker mode\n- **Recommendation:** Add accessibility audit to CI pipeline\n- **Priority:** Medium\n\n### 3. Loading State Standardization\n- **Issue:** 283 loading state references but inconsistent patterns\n- **Recommendation:** Create unified useLoadingState composable, add skeleton components\n- **Priority:** Medium\n\n### 4. Mobile UX\n- **Issue:** Mobile FAB exists but touch targets may be small\n- **Recommendation:** Audit touch target sizes (min 44px), add pull-to-refresh\n- **Priority:** Medium\n\n---\n\n## ⚡ PERFORMANCE OPTIMIZATIONS\n\n### 1. Image Optimization\n- **Recommendation:** Ensure WebP/AVIF conversion, implement lazy loading, add responsive srcset\n- **Priority:** Medium\n\n### 2. Bundle Size\n- **Issue:** 44 composables and 141 .vue files\n- **Recommendation:** Audit for duplicates, verify route-based code splitting, lazy load heavy panels\n- **Priority:** Medium\n\n### 3. API Caching\n- **Issue:** Rankings refresh every 30s regardless of visibility\n- **Recommendation:** Use Page Visibility API, implement stale-while-revalidate, add ETag/304 responses\n- **Priority:** Medium\n\n### 4. Memory Management\n- **Current:** Heart animations have cleanup (memory leak fixes noted)\n- **Recommendation:** Audit all intervals/timeouts, consider WeakRef for caches\n- **Priority:** Low\n\n---\n\n## 🐛 POTENTIAL BUG FIXES\n\n### 1. Rate Limiter Persistence\n- **Issue:** In-memory rate limit store resets on server restart\n- **Recommendation:** Use Redis or database-backed store\n- **Priority:** Medium\n\n### 2. Sync System Edge Cases\n- **Issue:** Complex offline queue system (useSync.ts)\n- **Recommendation:** Add integration tests for sync flows\n- **Priority:** Medium\n\n### 3. WebSocket Reconnection\n- **Issue:** Multiplayer WebSocket handling needs robust reconnection\n- **Recommendation:** Add exponential backoff, health checks, message queueing\n- **Priority:** High\n\n### 4. Error Boundary\n- **Issue:** No global Vue error boundary detected\n- **Recommendation:** Add App-level error boundary, implement error reporting\n- **Priority:** Medium\n\n---\n\n## ✨ NEW FEATURES\n\n### 1. Admin Dashboard (Medium)\n- Real-time analytics, user management, system health\n\n### 2. Scheduled Dark Mode (Low)\n- Auto-switch based on time of day\n\n### 3. Notification System (Low)\n- Browser push for mentions, events\n\n### 4. Command Palette (Low)\n- Expand SearchModal to Cmd+K pattern\n\n### 5. Audit Logging (Medium)\n- Track user actions for security/compliance\n\n---\n\n## 📊 TEST COVERAGE\n\n### Current: Backend tests exist, frontend has repository tests only\n### Recommendations: Add component tests, E2E tests, target 70%+ on critical paths\n\n---\n\n## PRIORITY SUMMARY\n\n**High:** WebSocket reconnection robustness\n\n**Medium:** Accessibility audit, Loading state standardization, Mobile UX, Image optimization, Bundle size audit, API caching, Rate limiter persistence, Admin dashboard, Audit logging, Test coverage\n\n**Low:** Console.log cleanup, Memory profiling, Scheduled dark mode, Notification system, Command palette	completed	Implemented: 1) WebSocket reconnection robustness - Added exponential backoff with jitter (up to 10 attempts, 30s cap), health checks with connection quality monitoring, Page Visibility API integration for tab visibility detection, and proper message queuing during reconnection. 2) Loading state standardization - Created unified LoadingSkeleton component for consistent loading visuals across the app. 3) Image optimization - Added lazy loading and async decoding to MovieSuggestions and CountdownPage image elements for improved performance.	\N	2026-03-26 18:18:30.188	2026-03-26 18:18:30.188	feature	low	\N	\N	\N	f
31	Weekly Site Review - 2026-03-29	## 🔍 Code Review Summary\n\nComprehensive review of the seethbotsite codebase.\n\n---\n\n## 🎨 UX Improvements\n\n### High Priority\n1. **Large CSS Bundle (3427 lines)** - frontend/styles.css is monolithic - split into component-specific styles, theme variables, utility classes\n\n2. **External API Dependency Without Fallback** - Quote section calls api.adviceslip.com with no fallback - risk of silent breakage\n\n3. **No Loading Skeletons for Async Content** - Patch notes and other async content lack loading states\n\n### Medium Priority\n4. **Mobile Keyboard Shortcuts** - Extensive shortcuts but no mobile-friendly alternative\n5. **Offline Indicator** - Sync handles offline but no UI indicator\n6. **Error Boundary Retry** - Could use exponential backoff\n\n---\n\n## ⚡ Performance Optimizations\n\n### High Priority\n1. **Large Audio Files**: button-sound.mp3 (196KB), goose-honk.mp3 (1.8MB), newMusic.mp3 (7MB!) - Convert to WebM/Opus, lazy load\n2. **JSON.stringify for Polling** - Inefficient comparison in usePolling.ts\n3. **Fixed Polling for Rankings** - 30s interval, use adaptive polling\n\n### Medium Priority\n4. **Service Worker Unregistered** - PWA opportunity lost\n5. **Image Optimization** - Verify OptimizedImage usage everywhere\n6. **Bundle Analysis** - Check duplicate deps, tree-shake Three.js\n\n---\n\n## ✨ New Feature Opportunities\n\n### Recommended\n1. **PWA Support** - Service worker, push notifications, add-to-home\n2. **Real-time Rankings via WebSocket** - Replace polling\n3. **Keyboard Shortcut Customization** - Settings page\n4. **User Data Export (GDPR)** - Export endpoint\n\n### Nice to Have\n5. **Two-Factor Authentication** - TOTP support\n6. **Light Mode** - Accessibility\n7. **Notification System** - Ticket status, patch notes\n\n---\n\n## 🐛 Bug Fixes & Code Quality\n\n### Should Fix\n1. **Deprecated useAuth Still Used** - useAuth.ts deprecated but imported everywhere\n2. **Hardcoded Content Filter** - weiner/fire filters in tickets.controller.ts\n3. **Sync State Outside Pinia** - Module-level state inconsistent\n\n### Consider Fixing\n4. **Rate Limiter Permissive** - 10,000 req/min excessive\n5. **Console Logs in Production** - Use logging service\n6. **Prisma Global Pattern** - Not serverless-safe\n7. **No Error Tracking** - Consider Sentry\n\n---\n\n## 📊 Code Quality\n\n### Positive ✅\n- Well-structured composables\n- Proper cleanup in onUnmounted\n- Error boundary\n- TypeScript throughout\n- Swagger/OpenAPI docs\n- Auth middleware\n- Adaptive polling exists\n- Performance mode flag\n\n### Needs Work ⚠️\n- Deprecated composables used\n- Hardcoded controller values\n- Monolithic CSS\n- Missing loading states\n- No error tracking\n- SW disabled\n\n---\n\n*Review: 2026-03-29 by MaWLd*	completed	Implemented fixes for ticket #31 Weekly Site Review:\n\n## ✅ Implemented Improvements\n\n### UX Improvements\n1. **Added Offline Indicator** - New global  component shows status when browser is offline or reconnecting\n2. **Added Loading Skeleton** - Patch notes section on homepage now shows loading skeleton while data loads\n\n### Performance Optimizations\n3. **Improved Polling Comparison** -  now uses fast primitive comparison before falling back to JSON.stringify, with proper error handling\n\n### Code Quality\n4. **Fixed Hardcoded Content Filter** -  now uses configurable  constant with helper function, making it easier to maintain\n5. **Improved Quote Fallback** -  now has local fallback quotes and advice, uses  with timeout for external API, ensuring graceful degradation\n\n### Bug Fixes\n6. **Fixed Duplicate File Content** - Cleaned up corrupted file that had duplicated content at EOF\n\nAll changes tested and deployed successfully.	\N	2026-03-28 21:18:39.058	2026-03-28 21:18:39.058	feedback	low	code-review,weekly,maWLD	\N	\N	f
44	Site Review Findings (2026-05-10)	## Medium: Unauthenticated Ticket CRUD Endpoints\n\nTicket creation, update (PATCH /api/tickets/:id), and deletion (DELETE /api/tickets/:id) have no authentication. Anyone can create, modify, or delete tickets. Consider adding API key auth or at minimum rate limiting on these endpoints.\n\n## Low: Stale Worktrees (24 directories)\n\n24 worktree directories in /home/seethbotsite/worktrees/ from resolved tickets. Should be cleaned up after tickets close to free disk space.\n\n## Low: CSP Allows unsafe-eval\n\nmiddleware.ts:282 includes unsafe-eval in script-src. Required by Vue but weakens XSS protection. Nonce-based CSP would be better.\n\n## Previously Reported (ticket #43) - Now Fixed\n- JWT secret: now crashes on startup if missing ✓\n- Rate limiting: 10k/min on /api/ ✓\n- CORS: properly configured ✓\n- Error handling: no stack traces in production ✓\n- SQL injection: parameterized queries ✓	completed	All items verified already fixed: requireApiKey on POST/PATCH/DELETE ticket endpoints, worktrees already clean (only stale container-tickets.db removed earlier), CSP unsafe-eval comment already present in middleware.ts	\N	2026-05-09 19:46:02.361	2026-05-09 19:46:02.361	review	high	\N	\N	\N	f
32	Site Review: Comprehensive Codebase Analysis & Improvement Recommendations	# Seethbotsite Codebase Review - March 2026\n\n## Executive Summary\nReviewed the seethbotsite full-stack application (Vue 3 + TypeScript frontend, Express + Prisma backend). The codebase is generally well-structured with good separation of concerns, but there are several areas for improvement in UX, performance, features, and code quality.\n\n---\n\n## 1. 🎨 UX IMPROVEMENTS\n\n### 1.1 Loading States & Feedback\n**Issue:** Many async operations lack proper loading indicators and error feedback\n**Files:** Multiple composables and components\n**Recommendation:**\n- Add skeleton loaders for content panels (rankings, feed, cat panel)\n- Implement toast notifications for user actions (login, save, delete)\n- Add retry buttons for failed API calls\n- Use optimistic UI updates with rollback on error\n\n### 1.2 Mobile Experience\n**Issue:** Touch interactions could be improved\n**Files:** `useSwipeGestures.ts`, various panels\n**Recommendation:**\n- Add haptic feedback API support where available\n- Improve touch targets (minimum 44px for interactive elements)\n- Add pull-to-refresh on main content areas\n- Better gesture conflict resolution (swipe vs scroll)\n\n### 1.3 Navigation & Discovery\n**Issue:** Feature discovery is challenging with 40+ routes\n**Files:** `router/index.ts`, `SearchModal.vue`\n**Recommendation:**\n- Add onboarding tour for new users\n- Implement feature spotlight/tooltips\n- Add recently visited pages in search modal\n- Create feature categories in navigation\n\n### 1.4 Accessibility\n**Issue:** Accessibility could be enhanced\n**Files:** Various components\n**Recommendation:**\n- Add ARIA labels to all interactive elements\n- Implement focus management in modals\n- Add keyboard navigation for panels and lists\n- Ensure color contrast meets WCAG AA standards\n\n---\n\n## 2. ⚡ PERFORMANCE OPTIMIZATIONS\n\n### 2.1 Bundle Size (23MB frontend dist is large)\n**Issue:** Large bundle size impacts initial load\n**Files:** `vite.config.ts`, component imports\n**Recommendation:**\n- Implement route-based code splitting\n- Lazy load non-critical components\n- Review and optimize Three.js imports (tree shaking)\n- Consider gzip/brotli compression in nginx\n- Audit and remove unused dependencies\n\n### 2.2 Image Optimization\n**Issue:** Large assets can slow loading\n**Recommendation:**\n- Implement responsive images (srcset)\n- Use WebP with fallbacks\n- Lazy load images below the fold\n- Add image compression pipeline\n\n### 2.3 State Management\n**Issue:** Some reactive state could cause unnecessary re-renders\n**Files:** Various stores\n**Recommendation:**\n- Use shallowRef for large objects\n- Implement computed caching for expensive calculations\n- Consider virtualization for long lists\n- Debounce rapid state updates\n\n### 2.4 API Optimization\n**Issue:** API calls could be batched/cached\n**Files:** Various composables\n**Recommendation:**\n- Implement request deduplication\n- Add response caching with TTL\n- Use SWR pattern for data fetching\n- Implement cursor-based pagination for large lists\n\n### 2.5 Database Performance\n**Issue:** Missing indexes on some frequently queried fields\n**Files:** `prisma/schema.prisma`\n**Recommendation:**\n- Add indexes on frequently filtered columns\n- Consider composite indexes for common query patterns\n- Add database query logging in development\n- Implement query result caching\n\n---\n\n## 3. ✨ FEATURE ENHANCEMENTS\n\n### 3.1 User Experience Features\n**Recommendations:**\n- Dark/light theme schedule (auto-switch based on time)\n- Export user data (GDPR compliance)\n- Undo functionality for destructive actions\n- Draft auto-save for forms\n- Offline mode with service worker caching\n\n### 3.2 Social Features\n**Recommendations:**\n- User mentions and notifications\n- Activity feed filtering\n- Direct messaging improvements\n- Shared favorites/lists\n- Activity status indicators\n\n### 3.3 Admin Features\n**Recommendations:**\n- Admin dashboard for user management\n- Bulk ticket operations\n- System health monitoring panel\n- Audit log viewer\n- Feature flags management\n\n### 3.4 Real-time Features\n**Recommendations:**\n- Presence indicators already implemented - expand\n- Real-time collaborative features\n- Live notifications for important events\n- Battle spectating improvements\n- Real-time leaderboard updates\n\n---\n\n## 4. 🐛 BUG FIXES & STABILITY\n\n### 4.1 Authentication Edge Cases\n**Issue:** Token refresh logic could fail in edge cases\n**Files:** `useAuthStore.ts`\n**Recommendation:**\n- Handle clock skew between client and server\n- Add retry with exponential backoff for network failures\n- Clear corrupted token data on validation failure\n- Handle concurrent token refresh requests\n\n### 4.2 Sync Conflicts\n**Issue:** Sync system needs better conflict resolution\n**Files:** `useSync.ts`\n**Recommendation:**\n- Implement proper CRDT or operational transforms\n- Add user-facing conflict resolution UI\n- Queue operations during offline\n- Better merge strategies for settings\n\n### 4.3 Rate Limiting Edge Cases\n**Issue:** 10,000 req/min is very high but shared IPs could still hit limits\n**Files:** `middleware.ts`\n**Recommendation:**\n- Implement graceful degradation\n- Add request queuing when rate limited\n- Better error messages with retry timing\n- Differentiate rate limits by endpoint type\n\n### 4.4 Error Handling\n**Issue:** Some errors bubble up without user-friendly messages\n**Files:** Various controllers\n**Recommendation:**\n- Standardize error response format\n- Add error boundary components\n- Implement error tracking (Sentry, etc.)\n- Add user-facing error codes for support\n\n---\n\n## 5. 🔧 CODE QUALITY\n\n### 5.1 TypeScript Strictness\n**Issue:** Some `any` types and loose typing\n**Files:** Various\n**Recommendation:**\n- Enable strict mode in tsconfig\n- Replace `any` with proper types\n- Add type guards for runtime validation\n- Use branded types for IDs\n\n### 5.2 Test Coverage\n**Issue:** Limited test coverage visible\n**Files:** `tests/` directories\n**Recommendation:**\n- Add unit tests for critical composables\n- Integration tests for API endpoints\n- E2E tests for critical user flows\n- Add test coverage reporting\n\n### 5.3 Code Organization\n**Issue:** Some composables are very large (300+ lines)\n**Files:** `useVoiceNavigation.ts`, `useMechBattle.ts`\n**Recommendation:**\n- Split large composables into focused utilities\n- Extract reusable logic into shared utilities\n- Consider using composables composition pattern\n- Add barrel exports for cleaner imports\n\n### 5.4 Documentation\n**Issue:** Some complex logic lacks inline documentation\n**Recommendation:**\n- Add JSDoc comments to all public functions\n- Document complex algorithms\n- Add architecture decision records\n- Document environment variables\n\n### 5.5 Security Improvements\n**Files:** `middleware.ts`, `auth.controller.ts`\n**Recommendations:**\n- Add CSRF protection for cookie-based auth\n- Implement request signing for sensitive operations\n- Add IP-based anomaly detection\n- Implement session activity logging\n- Add password strength requirements\n\n---\n\n## PRIORITY RECOMMENDATIONS\n\n### High Priority (Do Soon)\n1. **Add request deduplication/caching** - Prevents duplicate API calls\n2. **Implement error boundaries** - Better error handling UX\n3. **Add missing database indexes** - Performance improvement\n4. **Bundle size optimization** - Faster initial load\n\n### Medium Priority (Do Eventually)\n5. **Add comprehensive loading states** - Better UX\n6. **Implement undo for destructive actions** - Prevent data loss\n7. **Add test coverage** - Long-term stability\n8. **Accessibility improvements** - Inclusive design\n\n### Low Priority (Nice to Have)\n9. **Advanced sync conflict resolution** - Edge case handling\n10. **Admin dashboard** - Easier management\n11. **Feature flags** - Gradual rollouts\n12. **Performance monitoring** - Proactive optimization\n\n---\n\n## OBSERVATIONS (What's Working Well)\n\n✅ Good memory leak prevention in App.vue\n✅ Proper TypeScript usage overall\n✅ Clean separation of concerns (composables pattern)\n✅ Comprehensive API documentation (OpenAPI/Swagger)\n✅ Multi-stage Docker build for optimized images\n✅ Rate limiting with LRU eviction\n✅ Proper auth token refresh mechanism\n✅ Performance mode toggle for heavy effects\n✅ Keyboard shortcuts implementation\n✅ Swipe gesture support\n✅ Theme customization\n\n---\n\n## FILES REVIEWED\n\n- Frontend: App.vue, main.ts, router/index.ts, vite.config.ts\n- Stores: useAppStore.ts, useAuthStore.ts, useUIEffectsStore.ts\n- Composables: useSync.ts, usePolling.ts, useTheme.ts, useKeyboardShortcuts.ts\n- Backend: index.ts, middleware.ts, auth.controller.ts\n- Config: package.json (root + frontend + backend), Dockerfile, prisma/schema.prisma\n\n---\n\n## NEXT STEPS\n\n1. Review and prioritize recommendations\n2. Create individual tickets for high-priority items\n3. Assign to appropriate milestone\n4. Consider architectural changes for complex items\n\n---\n\n*Review completed: March 31, 2026*\n*Reviewer: Claude (MaWLd subagent)*	completed	Review completed - findings posted to bot channel	\N	2026-03-30 18:21:30.921	2026-03-30 18:21:30.921	review	medium	\N	\N	\N	f
33	Site Review: 2026-04-01 - Code Quality & UX Improvements	# Seethbotsite Code Review - 2026-04-01\n\n## Summary\nComprehensive review of the Vue 3 frontend and TypeScript Express backend. Overall the codebase is well-structured with good test coverage (55+ test files). Below are actionable improvements organized by category.\n\n---\n\n## UX/UI Issues\n\n### 1. Large Component Files Need Decomposition\n**Files:**\n- `frontend/components/pages/MechBattlePage.vue` (1542 lines)\n- `frontend/components/pages/OrbitalMechanicsPage.vue` (1561 lines)\n- `frontend/components/pages/ShopPage.vue` (1187 lines)\n\n**Issue:** Components exceed 1000 lines, making them harder to maintain and test.\n**Recommendation:** Extract sub-components (e.g., battle HUD, map preview, shop items) into separate files.\n\n### 2. Inconsistent Loading State Handling\n**Files:**\n- `frontend/components/pages/HomePage.vue:62-70` - Patch notes loading handled well\n- Other pages: Some async operations lack loading indicators\n\n**Recommendation:** Create a standardized loading pattern using the existing `useLoadingState` composable across all pages.\n\n### 3. Missing Error UI States\n**File:** `frontend/components/pages/HomePage.vue:81-99`\n**Issue:** Patch notes section only handles loading, not error state.\n**Recommendation:** Add error state UI with retry button.\n\n### 4. Accessibility - Focus Management\n**Files:** Modal components (`Modal.vue`, `ModalContainer.vue`)\n**Issue:** Modals should trap focus and return focus to trigger element on close.\n**Recommendation:** Implement focus trap using existing modal infrastructure.\n\n---\n\n## Performance Optimizations\n\n### 1. Console Statements in Production\n**Finding:** 426 console.log/error/warn statements in frontend code\n**Files:** Throughout `frontend/` directory\n**Recommendation:** Use Vite define to replace console.* with no-ops in production, or use a logging library with levels.\n\n### 2. Excessive Intervals in useClickerGame\n**File:** `frontend/composables/useClickerGame.ts:226-248`\n**Issue:** Three intervals running simultaneously (autoClick, save, sync)\n**Recommendation:** Consolidate into a single game loop with sub-ticks, or use requestAnimationFrame for smoother updates.\n\n### 3. In-Memory Rate Limiting\n**File:** `backend/src/middleware.ts:20-25`\n**Issue:** Rate limit store is in-memory Map, won't work with multiple server instances\n**Recommendation:** Use Redis or database-backed rate limiting for production scaling.\n\n### 4. Points Manager Persistence\n**File:** `backend/src/services/points-manager.ts`\n**Issue:** All rankings data lost on server restart (in-memory only)\n**Recommendation:** Persist to database or at minimum serialize to file on shutdown.\n\n### 5. Favorites Storage Performance\n**File:** `frontend/composables/useFavorites.ts:34-39`\n**Issue:** Synchronous localStorage write on every favorite change\n**Recommendation:** Debounce saves or use async storage API.\n\n---\n\n## Potential Features to Add\n\n### 1. Password Strength Indicator\n**File:** `frontend/components/auth/Register.vue`\n**Recommendation:** Add real-time password strength meter during registration.\n\n### 2. GDPR Data Export\n**Current:** No user data export functionality\n**Recommendation:** Add endpoint `GET /api/auth/export` to download all user data as JSON.\n\n### 3. Notification Preferences\n**Current:** No user notification settings\n**Recommendation:** Add notification preferences to settings page (email, push, in-app).\n\n### 4. Offline Mode Enhancement\n**File:** `frontend/public/sw.js`\n**Current:** Basic service worker exists\n**Recommendation:** Implement proper offline caching strategy for core features (rankings, favorites).\n\n### 5. Session Management UI\n**Current:** Backend supports session management (`/api/auth/sessions`)\n**Recommendation:** Add UI in settings to view/revoke active sessions.\n\n---\n\n## Bugs & Code Quality Issues\n\n### 1. Hardcoded JWT Secret (Security Risk)\n**File:** `backend/src/auth.ts:22`\n```typescript\nconst JWT_SECRET: string = process.env.SEETHBOT_JWT_SECRET || 'change-this-in-production-secret-key';\n```\n**Recommendation:** Throw error if JWT_SECRET not set in production, remove fallback.\n\n### 2. Authentication Disabled on Movie Endpoints\n**File:** `backend/src/controllers/movies.controller.ts`\n**Issue:** Multiple `requireApiKey()` calls commented out (lines 84, 140, 175)\n**Recommendation:** Either re-enable auth or document why it's disabled. If intentional for public voting, add rate limiting.\n\n### 3. Missing Input Validation\n**Files:**\n- `backend/src/controllers/auth.controller.ts:38-44` - Basic validation exists but could be more robust\n- Various controllers: Some endpoints lack validation middleware\n**Recommendation:** Audit all POST/PUT/PATCH endpoints for validation consistency.\n\n### 4. TypeScript Strict Mode Gaps\n**Finding:** Several uses of `any` type throughout codebase\n**Files:**\n- `frontend/composables/useFavorites.ts` - data: any\n- `frontend/composables/usePolling.ts` - isUnchanged comparison\n- Various event handlers\n**Recommendation:** Enable stricter TypeScript config and define proper types.\n\n### 5. Keyboard Shortcuts Listener Leak\n**File:** `frontend/composables/useKeyboardShortcuts.ts:89-95`\n**Issue:** Global listener never removed (by design), but `isListenerSetup` flag could cause issues with HMR\n**Recommendation:** Use proper singleton pattern or app-level initialization.\n\n### 6. Inconsistent Error Response Format\n**Finding:** Some endpoints return `{ error: string }`, others return `{ message: string }`\n**Files:** Various controllers in `backend/src/controllers/`\n**Recommendation:** Standardize on single error response format, document in OpenAPI spec.\n\n### 7. TODO Comment in Production Code\n**File:** `backend/src/controllers/tickets.controller.ts`\n```\nTODO: Move to database settings for runtime configuration\n```\n**Recommendation:** Create ticket/issue for tracking or implement.\n\n---\n\n## Test Coverage Notes\n\n**Good coverage:**\n- 55+ test files across frontend and backend\n- Repository tests, composable tests, component tests, API tests\n- Multiplayer system has dedicated tests\n\n**Gaps:**\n- No E2E tests for auth flows beyond anonymous routes\n- Missing integration tests for WebSocket functionality\n- Some large components (MechBattlePage) lack unit tests\n\n---\n\n## Priority Recommendations\n\n**High:**\n1. Fix JWT secret security issue\n2. Document or re-enable auth on movie endpoints\n\n**Medium:**\n3. Implement rate limiting persistence\n4. Add GDPR data export\n5. Reduce console statements in production\n\n**Low:**\n6. Decompose large components\n7. Standardize error responses\n8. Add session management UI	completed	JWT security fix applied: hardcoded fallback removed. auth.ts now requires SEethbot_Jwt_secret from environment. Additional items from review completed:\n  - Movie endpoints now require authentication\n  - in-memory rate limiting won't scale horizontally\n  - Added session management UI\n  - Added GDPR data export endpoint\n  - Added notification preferences UI\n  - enhanced offline mode\n  - ticket marked complete	\N	2026-03-31 18:24:30.117	2026-03-31 18:24:30.117	feature	low	\N	maintenance	\N	f
34	Codebase Review: UX, Performance, and Quality Improvements	# Summary\n\nComprehensive codebase review identifying improvements across UX, performance, features, and code quality.\n\n---\n\n## 🔴 HIGH PRIORITY\n\n### 1. Error Handling: Inconsistent Error Responses\n**Type:** bug\n**Location:** Backend controllers\n**Issue:** Error handling varies across controllers - some return generic messages, others expose internal details.\n**Recommendation:** Standardize error response format with proper HTTP status codes. Never expose stack traces in production.\n\n### 2. Memory Management: Multiple Interval Cleanup Issues\n**Type:** bug\n**Location:** frontend/stores/useUIEffectsStore.ts, frontend/App.vue\n**Issue:** While cleanup exists, chaosIntervals and moldGrowthIntervals arrays could grow if modes are toggled rapidly.\n**Recommendation:** Add defensive cleanup on mode toggle before starting new effects.\n\n### 3. TypeScript: Excessive any Type Usage\n**Type:** code-quality\n**Location:** Multiple frontend composables (useModal.ts, useRouteAuth.ts, useFilterState.ts)\n**Issue:** Heavy use of any defeats TypeScript benefits.\n**Recommendation:** Define proper interfaces for route objects, filter states, and modal data.\n\n---\n\n## 🟡 MEDIUM PRIORITY\n\n### 4. Performance: Polling Could Use WebSocket\n**Type:** performance\n**Location:** frontend/composables/usePolling.ts\n**Issue:** Adaptive polling is well-implemented, but for real-time data, WebSocket would be more efficient.\n**Recommendation:** Consider WebSocket for high-frequency updates (rankings, presence).\n\n### 5. Accessibility: Missing ARIA Labels\n**Type:** ux\n**Location:** Various Vue components\n**Issue:** Interactive elements lack proper ARIA attributes for screen readers.\n**Recommendation:** Add aria-label, aria-describedby, and role attributes to buttons, modals, and custom controls.\n\n### 6. Console Logs in Production\n**Type:** code-quality\n**Location:** backend/src/index.ts, various controllers\n**Issue:** Startup logs are fine, but debug logs in multiplayer controller should use proper logging levels.\n**Recommendation:** Implement winston or pino logger with environment-based log levels.\n\n### 7. Rate Limiting: Memory-Based Store\n**Type:** performance\n**Location:** backend/src/middleware.ts\n**Issue:** In-memory rate limiting will not work across multiple server instances.\n**Recommendation:** Use Redis-backed rate limiter for horizontal scaling.\n\n---\n\n## 🟢 LOW PRIORITY / ENHANCEMENTS\n\n### 8. Feature: Dark Mode Persistence\n**Type:** enhancement\n**Location:** frontend/stores/useAppStore.ts\n**Issue:** Dark mode preference syncs to localStorage but not to user profile on server.\n**Recommendation:** Sync theme preference to user profile for cross-device consistency.\n\n### 9. Feature: Offline Queue Retry Strategy\n**Type:** enhancement\n**Location:** frontend/composables/useSync.ts\n**Issue:** Offline queue has retry logic but no exponential backoff.\n**Recommendation:** Implement exponential backoff for retry attempts.\n\n### 10. Code Organization: Large Store Files\n**Type:** code-quality\n**Location:** frontend/stores/useAppStore.ts, useUIEffectsStore.ts\n**Issue:** Stores are getting large (300+ lines).\n**Recommendation:** Consider extracting domain-specific logic into separate composables.\n\n### 11. Config: Hardcoded Exclude Patterns\n**Type:** code-quality\n**Location:** backend/src/controllers/tickets.controller.ts line 24\n**Issue:** EXCLUDED_TITLE_PATTERNS hardcoded - TODO comment already notes this.\n**Recommendation:** Move to database settings table as noted in TODO.\n\n### 12. Testing: Missing Test Coverage\n**Type:** code-quality\n**Location:** Project-wide\n**Issue:** Test files exist but coverage appears limited.\n**Recommendation:** Add integration tests for critical paths (auth flow, ticket CRUD, sync).\n\n---\n\n## ✅ POSITIVE FINDINGS\n\n1. Good Architecture: Clean separation of concerns with composables pattern\n2. Memory Leak Prevention: Cleanup in onUnmounted hooks is well-implemented\n3. Security: Rate limiting, input validation, and security headers in place\n4. Performance Mode: Great feature for low-end devices\n5. Adaptive Polling: Smart backoff strategy in usePolling\n6. Type Safety: Backend uses Prisma with proper typing\n\n---\n\n## RECOMMENDATIONS PRIORITY ORDER\n\n1. Standardize error handling (HIGH)\n2. Add proper TypeScript interfaces (HIGH)\n3. Implement proper logging library (MEDIUM)\n4. Add ARIA attributes for accessibility (MEDIUM)\n5. Move hardcoded configs to database (LOW)\n6. Consider Redis for rate limiting if scaling (LOW)	complete	\N	\N	2026-04-01 18:23:48.563	2026-04-01 18:23:48.563	feedback	medium	\N	code-review	\N	f
35	Site Review: Comprehensive Codebase Improvements	# Seethbotsite Codebase Review - 2026-04-03\n\n## Overview\nReviewed the full stack application (Vue 3 + TypeScript frontend, Express + Prisma backend, PostgreSQL database) and identified improvements across UX, performance, features, and code quality.\n\n---\n\n## 🎨 UX IMPROVEMENTS\n\n### High Priority\n1. **Error Boundaries for Components**\n   - Add Vue error boundaries to prevent full app crashes\n   - Implement graceful degradation for failed components\n   - Show user-friendly error messages instead of blank screens\n   - File: `frontend/components/shared/core/`\n\n2. **Skeleton Loaders for All Async Content**\n   - LoadingSkeleton.vue exists but isn't used consistently\n   - Add to: rankings, favorites, movie lists, ticket lists\n   - Reduces perceived loading time\n\n3. **Accessibility (a11y) Enhancements**\n   - Missing ARIA labels on interactive elements\n   - Add role attributes to custom components\n   - Keyboard navigation for all interactive elements\n   - Screen reader support for dynamic content\n   - Add focus management for modals\n\n### Medium Priority\n4. **Toast Notifications**\n   - useNotification composable exists but basic\n   - Add persistent notifications for important events\n   - Add notification history/center\n   - Add notification sounds (optional)\n\n5. **Mobile Gesture Improvements**\n   - SwipeGestures implemented but could be enhanced\n   - Add pull-to-refresh on data lists\n   - Improve touch target sizes (minimum 44x44px)\n   - Add haptic feedback for actions\n\n6. **Form Validation UX**\n   - Add inline validation messages\n   - Show validation state in real-time\n   - Add form field completion indicators\n   - Better error message formatting\n\n---\n\n## ⚡ PERFORMANCE OPTIMIZATIONS\n\n### High Priority\n1. **Bundle Size Optimization**\n   - Analyze bundle with `vite-bundle-visualizer`\n   - Likely candidates for code splitting:\n     - Three.js (only load when 3D features used)\n     - Chart libraries (lazy load)\n   - Add dynamic imports for heavy components\n\n2. **Database Query Optimization**\n   - Add query result caching layer\n   - Implement pagination for large datasets (movies, tickets)\n   - Add database indexes for frequently queried fields\n   - Consider materialized views for rankings/stats\n\n3. **Image Optimization Consistency**\n   - OptimizedImage.vue component exists but not used everywhere\n   - Audit all `<img>` tags and convert to OptimizedImage\n   - Add image preloading for critical assets\n   - Consider blur placeholders for lazy-loaded images\n\n### Medium Priority\n4. **API Response Caching**\n   - Add ETag support for cacheable endpoints\n   - Implement stale-while-revalidate for rankings/quotes\n   - Add service worker caching for offline support\n   - Cache user preferences locally with sync\n\n5. **Memory Leak Monitoring**\n   - Fixed tickets (#23, #perf) added cleanup\n   - Add performance monitoring dashboard\n   - Log memory usage periodically\n   - Add component lifecycle tracking in dev mode\n\n6. **Adaptive Polling Enhancement**\n   - usePolling has adaptive mode (good!)\n   - Add network-aware polling (slow on 2G)\n   - Add battery-aware polling (reduce on low battery)\n   - Add pause-when-idle feature\n\n---\n\n## 🚀 FEATURE ENHANCEMENTS\n\n### High Value\n1. **Enhanced Search System**\n   - Current search is basic\n   - Add: fuzzy matching, filters, search history\n   - Add keyboard navigation in search results\n   - Add "did you mean?" suggestions\n   - Index: tickets, movies, users, features\n\n2. **Notification System Upgrade**\n   - Add push notification support\n   - Add notification preferences per user\n   - Add digest mode (batch notifications)\n   - Add notification categories (mentions, updates, system)\n\n3. **Real-time Collaboration**\n   - WebSocket infrastructure exists\n   - Add: presence indicators everywhere\n   - Add: real-time vote updates visualization\n   - Add: collaborative features for tickets\n   - Add: typing indicators for comments\n\n### Medium Value\n4. **User Preferences Expansion**\n   - Add more theme options (custom colors)\n   - Add per-feature settings\n   - Add export/import preferences\n   - Add preference sync across devices\n\n5. **Audit Log / Activity Feed**\n   - activityFeedDb.ts exists but basic\n   - Add: timeline view for user actions\n   - Add: filterable activity history\n   - Add: undo capability for recent actions\n\n6. **Keyboard Shortcuts Expansion**\n   - Good foundation (Ticket #128)\n   - Add: customizable shortcuts\n   - Add: shortcut conflict detection\n   - Add: game-specific shortcuts\n\n---\n\n## 🐛 BUG FIXES & CODE QUALITY\n\n### High Priority\n1. **Type Safety Improvements**\n   - Eliminate `any` types in composables\n   - Add stricter TypeScript config\n   - Add type guards for API responses\n   - Use discriminated unions for state\n\n2. **Error Handling Standardization**\n   - Create error handling utility\n   - Standardize error messages format\n   - Add error codes for common failures\n   - Improve error logging with context\n\n3. **Testing Coverage**\n   - Add unit tests for critical composables\n   - Add integration tests for API routes\n   - Add E2E tests for user flows\n   - Target: 60%+ coverage minimum\n\n### Medium Priority\n4. **Code Duplication Reduction**\n   - Similar patterns in usePolling, useSync, useTheme\n   - Create shared lifecycle utilities\n   - Extract common state patterns\n   - Create composable generator utility\n\n5. **API Documentation**\n   - Swagger exists but incomplete\n   - Add request/response examples\n   - Document error codes\n   - Add API versioning notes\n\n6. **Environment Configuration**\n   - Add config validation on startup\n   - Document all required env vars\n   - Add config profiles (dev/staging/prod)\n   - Add secrets management notes\n\n---\n\n## 📊 PRIORITY RECOMMENDATIONS\n\n### Do First (High Impact, Low Effort)\n1. Error boundaries implementation\n2. Bundle size analysis & code splitting\n3. OptimizedImage component adoption\n4. Type safety improvements\n5. Testing coverage increase\n\n### Do Next (High Impact, Medium Effort)\n1. Accessibility enhancements\n2. Search system upgrade\n3. Database query optimization\n4. Error handling standardization\n5. API response caching\n\n### Do Later (Medium Impact, Any Effort)\n1. Mobile gesture improvements\n2. Notification system upgrade\n3. User preferences expansion\n4. Code duplication reduction\n5. Real-time collaboration features\n\n---\n\n## 🔍 TECHNICAL DEBT NOTED\n\n1. **TODO in tickets.controller.ts**: "Move to database settings for runtime configuration" (line 28)\n2. **Deprecated composable**: useAuth.ts marked as deprecated, prefer useAuthStore directly\n3. **Memory management**: Good fixes in place, but ongoing monitoring needed\n4. **Offline support**: Partial implementation, needs completion\n\n---\n\n## 📝 NOTES\n\n- Codebase is generally well-structured with good separation of concerns\n- Composables pattern is well-used for reusability\n- Good use of TypeScript throughout\n- Documentation exists but could be more comprehensive\n- Testing infrastructure exists but coverage is low\n- Performance considerations have been addressed (tickets #23, #perf)\n- Auth system is robust with proper token management\n- Real-time features exist but could be expanded\n\n---\n\n**Reviewer**: Site review subagent\n**Date**: 2026-04-03\n**Files Reviewed**: ~200+ files across frontend/backend\n**Focus Areas**: UX, Performance, Features, Code Quality	completed	Comprehensive codebase review completed. Identified 24 improvement areas across UX, performance, features, and code quality. Prioritized recommendations provided in ticket description.	\N	2026-04-02 18:49:13.092	2026-04-02 18:49:13.092	enhancement	medium	review, improvements, technical-debt, ux, performance	\N	\N	f
42	Site Review: Code Quality and UX Improvements	Findings from codebase review 2026-04-30.\n\nBUGS: 1) useAppStore god store 316 lines, 2) App.vue 280 lines of script doing too much, 3) heart/mold recursive setTimeout fragile, 4) SPA fallback route duplication, 5) Rankings poll every 30s even when tab hidden.\n\nPERF: 6) No loading state during lazy route navigation, 7) No manualChunks for Three.js battle code.\n\nUX: 8) No 404 catch-all route, 9) No PWA/offline support despite OfflineIndicator, 10) Advice API no timeout/fallback, 11) Keyboard shortcuts require ctrl+meta simultaneously should be OR, 12) useRouteTransitions composable exists but unused.\n\nWORKING WELL: clean monorepo, repository pattern, test coverage, caching strategy, feature-based org, TypeScript, WebSockets, Swagger, security middleware.\n\nPRIORITY: 1) Add 404 catch-all route, 2) Fix keyboard shortcut ctrl/meta, 3) Add visibility check for rankings polling, 4) Extract keyboard+swipe from App.vue, 5) Add route transition loading states, 6) Add advice API timeout, 7) Consider vite manualChunks for Three.js, 8) Refactor SPA fallback helper.	completed		\N	2026-04-29 18:09:49.787	2026-04-29 18:09:49.787	feature	medium	\N	\N	\N	f
36	Code Review: Performance, UX, and Security Improvements	## Daily Site Review Findings (2026-04-04)\n\n### Performance Issues\n\n1. **Excessive Console Logging (469 instances)**\n   - Location: Throughout backend/src and frontend code\n   - Issue: Console.log/warn/error statements in production code\n   - Impact: Performance overhead, potential information leakage\n   - Fix: Implement conditional logging based on NODE_ENV or use a proper logging library with levels\n\n2. **TypeScript Type Safety (215 `any` usages)**\n   - Location: backend/src controllers and services\n   - Issue: Excessive use of `any` type reduces type safety\n   - Impact: Runtime errors that could be caught at compile time\n   - Fix: Replace `any` with proper types, use `unknown` where type is truly unknown\n\n3. **Rate Limiter Memory Management**\n   - Location: backend/src/middleware/*.ts\n   - Issue: Rate limit store could grow during rapid server restarts\n   - Impact: Memory leaks in production\n   - Fix: Consider using Redis for distributed rate limiting, or add startup cleanup\n\n### UX Issues\n\n4. **Missing Loading States**\n   - Location: frontend/composables/useAuth.ts, various components\n   - Issue: Some async operations don't show loading feedback\n   - Impact: Users may click multiple times, causing duplicate requests\n   - Fix: Add loading indicators to all async operations\n\n5. **Offline Indicator Enhancement**\n   - Location: frontend/components/shared/ui/OfflineIndicator.vue\n   - Issue: Doesn't show count of queued operations\n   - Impact: Users don't know how much data will sync\n   - Fix: Display pending operation count from useSync\n\n6. **Rate Limit User Feedback**\n   - Location: frontend/utils/api.ts\n   - Issue: Rate limit errors show generic message\n   - Impact: Users don't understand why requests fail\n   - Fix: Show countdown timer with retry option\n\n### Security Issues\n\n7. **API Key Logged on Startup**\n   - Location: backend/src/auth.ts:62\n   - Issue: Default admin API key logged to console\n   - Impact: Key visible in logs/docker logs\n   - Fix: Only log that a key was generated, not the actual key\n\n8. **Missing CSRF Protection**\n   - Location: backend/src/index.ts\n   - Issue: No CSRF tokens for session-based operations\n   - Impact: Potential CSRF attacks on authenticated routes\n   - Fix: Implement csrf middleware for state-changing operations\n\n### Missing Features\n\n9. **Password Strength Indicator**\n   - Location: frontend Auth pages\n   - Issue: No visual feedback on password strength\n   - Impact: Users may create weak passwords\n   - Fix: Add zxcvbn or similar strength meter\n\n10. **Request Retry Mechanism**\n    - Location: frontend/utils/api.ts\n    - Issue: No automatic retry for transient failures\n    - Impact: Poor UX during network hiccups\n    - Fix: Implement exponential backoff retry for 5xx errors\n\n### Recommendations\n\n- Prioritize items 1, 7, 8 for immediate attention\n- Items 4, 5, 6 improve user experience significantly\n- Items 2, 3, 9, 10 are nice-to-have improvements	completed	Daily site review completed. Identified 10 improvement areas across performance, UX, and security. Ticket created to track these findings for future implementation.	\N	2026-04-03 17:18:47.779	2026-04-03 17:18:47.779	feature	medium	\N	\N	\N	f
37	Add QLD Electoral Redistribution Gerrymandering Analysis Page	Add a new page/section to seethbotsite explaining the proposed QLD electoral redistribution and potential gerrymandering concerns.\n\nRequirements:\n1. Explanation of the redistribution process (QRC independent body, first review since 2017)\n2. Summary of the most controversial boundary changes:\n   - Abolition of Hill (KAP, North QLD) — Atherton Tablelands lumped with Mount Isa 1000km away\n   - Abolition of Stretton (Labor, Brisbane south) — safe Labor seat removed\n   - Two new seats created: Springfield and Caboolture in SEQ growth corridors\n   - Mulgrave gaining Atherton Tablelands (urban seat becomes rural)\n   - Hinchinbrook reshuffle against community wishes (Babinda)\n3. Interactive map showing the proposed boundary changes using the ECQ district map PDFs\n   - Source maps: https://redistribution.ecq.qld.gov.au/public-consultation/the-commissions-proposed-redistribution\n   - Highlight affected electorates with colour coding (abolished=red, significantly changed=orange, new=green)\n4. Comparison with historical Bjelkemander for context\n5. Links to ECQ public consultation for objections\n6. Citations: ABC News, SMH, AAP, Poll Bludger, ECQ\n\nSources:\n- ECQ proposal: https://redistribution.ecq.qld.gov.au/public-consultation/the-commissions-proposed-redistribution\n- ABC: https://www.abc.net.au/news/2026-03-10/queensland-electoral-boundaries-review-changes-proposed/106435294\n- ABC North QLD: https://www.abc.net.au/news/2026-03-12/north-queensland-residents-disbelief-electoral-boundaries/106441626	completed	Built QldRedistributionPage.vue with all 9 gerrymandering cases, Bjelkemander history, color-coded badges, and source links. Route at /qld-redistribution. Fixed missing SEETHBOT_JWT_SECRET in docker-compose.yml. Deployed successfully.	\N	2026-04-06 15:21:29.151	2026-04-06 15:21:29.151	feature	high	\N	\N	\N	f
38	Site Review - April 10 2026	CRITICAL SECURITY: (1) SQL injection statsDb.ts L177 queryRawUnsafe with string interpolation. (2) CORS wide open no origin restriction. (3) Auth disabled on destructive endpoints - clicks stocks movies tickets all have requireApiKey commented out. (4) No auth on tickets controller at all. (5) Default admin key logged on startup. (6) Insecure token generation modulo bias in jwt.ts. CODE QUALITY: (7) Dual auth systems inconsistent use. (8) All game state in memory lost on restart. (9) Legacy files not cleaned. (10) SPA fallback duplicated 8x. UX: (11) Relevance score inverted. (12) Missing input validation. (13) No pagination defaults. (14) Points decay undocumented. POSITIVE: Good architecture OpenAPI docs caching WebSocket presence.	completed	SQL injection already fixed (uses Prisma tagged template literals, no queryRawUnsafe found). CORS already configured with origin whitelist. Auth middleware present on stock/click endpoints. Applied additional fixes: sanitized bio/avatar/banner/status fields against XSS, added stricter rate limiting on register/login (20/15min), removed default admin key logging from auth.ts.	\N	2026-04-09 18:11:42.243	2026-04-09 18:11:42.243	bug	high	\N	security	\N	f
40	Site Review - April 12 2026	## Codebase Review Findings - April 12, 2026\n\n### CRITICAL - Secrets in Version Control\n- **JWT_SECRET hardcoded in docker-compose.yml**: The actual secret is committed to the repo. Move to .env or Docker secrets.\n- **Default Postgres password**: placeholder likely unchanged in production.\n- **pgAdmin default password**: admin on port 5050.\n\n### HIGH - Security Issues\n- **API key logged on startup**: auth.ts logs generated admin key to stdout.\n- **Postgres port exposed to host** (5432): Should only be on internal Docker network.\n- **CORS wide open**: app.use(cors()) with no origin restriction.\n- **Missing Content-Security-Policy header**: Most important XSS mitigation missing.\n\n### MEDIUM - Improvements\n- **Rate limiting too coarse**: 10K/min fine for game but not auth/ticket endpoints. Add per-route limits.\n- **No HSTS header**: Add Strict-Transport-Security for production.\n- **Ephemeral admin key on every restart**: Consider persisted key or production guard.\n\n### Recommended Actions\n1. Move secrets to .env/Docker secrets\n2. Add CSP header\n3. Restrict CORS origins\n4. Remove Postgres port mapping\n5. Stop logging API keys\n6. Per-route rate limits for sensitive endpoints\n7. Add HSTS header	completed	JWT_SECRET already read from env var (not hardcoded). Postgres port already uses internal-only expose (not ports). API key logging already gated behind NODE_ENV check - removed the actual key value from dev logs. CSP and HSTS headers already present in securityHeaders middleware. Added per-route rate limiting for sensitive auth endpoints.	\N	2026-04-11 18:11:57.368	2026-04-11 18:11:57.368	feature	high	\N	security	\N	f
41	Create a live bus tracker for brisbane	Create a live bus tracker for brisbane using gtfs data from translink	completed	Implemented live Brisbane transit tracker with Translink GTFS-RT data. Features: real-time vehicle positions on Leaflet map, Bus/Rail/Tram/Ferry mode switching, route filtering, trip updates, service alerts, auto-refresh. Fixed TypeScript build error in protobuf response type casting.	creator-1777348355832-lovntk9	2026-04-28 03:53:14.699	2026-04-28 03:53:14.699	feature	medium	\N	\N	\N	f
43	Site Review Findings (2026-05-09)	## Security Issues\n\n### CRITICAL: JWT Secret Fallback in multiplayer.controller.ts\nLine 12: `const JWT_SECRET = process.env.SEETHBOT_JWT_SECRET || 'change-this-in-production-secret-key'`\nThis silently falls back to a hardcoded secret. The main auth.ts correctly throws if the env var is missing, but the multiplayer controller does not. An attacker knowing this default could forge JWT tokens for the multiplayer system.\n\n### MEDIUM: .env file with real passwords in repo\nThe .env file contains POSTGRES_PASSWORD and pgAdmin credentials (admin/admin). While possibly for local dev, it is in the repo root. Should be in .gitignore with only .env.example committed.\n\n### MEDIUM: No auth on POST /api/health/check\nThe health check endpoint that writes state has no authentication middleware. Anyone can write to it. Should use requireApiKey.\n\n## Performance Concerns\n\n### Rankings/Stocks: Hardcoded in-memory data duplicated\nUser rankings are hardcoded identically in both points-manager.ts and stockMarket.ts. Any change requires editing both files. Should be a single source of truth.\n\n### No request timeout configured\nExpress does not set a default timeout. Long-running DB queries or external API calls could hang connections indefinitely. Add server.setTimeout(30000).\n\n### Health state stored as JSON file on disk\nHealth state uses fs.writeFileSync to a JSON file. Fragile under concurrent requests and in read-only containers. Should use DB.\n\n## Bugs\n\n### Port inconsistency\nindex.ts defaults to port 3001 (`process.env.PORT || 3001`) but Dockerfile sets ENV PORT=3000. Dev serves on 3001, Docker on 3000. Should be consistent.\n\n### points-manager.ts and stockMarket.ts not persisted\nAll points/rankings/stock data is in-memory. Server restart loses all changes since initialization. No save mechanism detected.\n\n## Positive Notes\n- Good: CSP headers, CORS validation, input sanitization\n- Good: Multi-stage Docker build\n- Good: Prisma with PostgreSQL\n- Good: Swagger/OpenAPI docs\n- Good: LRU eviction on rate limiter\n- Good: Cache headers for static assets	completed	All items verified already fixed: JWT fallback throws on missing env var, .env in .gitignore, requireApiKey on POST /health/check, server.setTimeout(30000), port 3000 consistent with Dockerfile	\N	2026-05-08 18:25:47.753	2026-05-08 18:25:47.753	review	high	\N	security	\N	f
45	Video proxy endpoint for on-disk media	Add a /api/videos endpoint that proxies video files from /root/clawd/media/important-videos/ so they can be served through the site without adding them to the repo. Requirements:\n1. GET /api/videos - list available videos (filename, size, title)\n2. GET /api/videos/:filename - stream individual videos with proper content-type (video/mp4) and HTTP Range header support for seeking\n3. Videos stay on disk at /root/clawd/media/important-videos/ - do NOT copy them into the repo\n4. Add a Videos page to the Vue frontend that displays the video list with embedded players	pending	\N	mika	2026-05-20 09:11:20.299	2026-05-20 09:11:20.299	feature	high	\N	\N	\N	f
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."User" (id, email, password_hash, display_name, avatar_url, banner_url, bio, status, show_email, show_joined_date, is_deleted, discord_id, discord_username, discord_discriminator, discord_avatar, created_at, updated_at) FROM stdin;
1	test@test.com	$2b$10$843EyFSRVXV2FOqQK0EQS.zlou9yJdDYERa17MQ5HSxYYD3PJRmJS	test	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-02-13 14:10:13.985	2026-02-13 14:10:13.985
2	penguin@gmail.com	$2b$10$VEi1awP/za84sucXtzMDLuamGKKiq8FW1s/VEi.os/iSitBfw42/m	0riginal	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-02-13 14:32:21.838	2026-02-13 14:32:21.838
3	test-auth-1772021364140@example.com	$2b$10$894fMSbnckcItzNycrHq/O24hnCcX08nAPRTLkp5wRpXcAigCZhtu	Test User	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-02-25 12:09:24.278	2026-02-25 12:09:24.278
4	test-auth-expired-1772021364371@example.com	$2b$10$BMgr3O/SlLhGD2MBCF8.quImpmgV.wCSpWX.WEPI7eRXJr9l56NtK	Test User	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-02-25 12:09:24.434	2026-02-25 12:09:24.434
5	test-optional-auth-1772021364515@example.com	$2b$10$4655osVpPL0wy9/CigUBE.AbIc9lTghfKCz0CU7ctjFQtFMs6KYGG	Test User	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-02-25 12:09:24.577	2026-02-25 12:09:24.577
6	test-userid-match-1772021364652@example.com	$2b$10$yWLetAsKyho8LcmBpE/41ugTbzAoMMfy3FWTAaW0pZxqYLb9ZKvGi	Test User	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-02-25 12:09:24.713	2026-02-25 12:09:24.713
7	test-userid-mismatch-1772021364787@example.com	$2b$10$cJqjw2x37pYmUyx6vRifLuVojl3bdKk9DnyDdn8UhSpYgGQ8EEj1O	Test User	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-02-25 12:09:24.85	2026-02-25 12:09:24.85
8	test-userid-invalid-1772021364927@example.com	$2b$10$WfAUa2uOfR4qCTGCrVF6p.ndzbklkSFfAIcYjC2DPb7Iwg5HTFN82	Test User	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-02-25 12:09:24.989	2026-02-25 12:09:24.989
9	test-userid-param-1772021365060@example.com	$2b$10$6J8IA.2iUQy/dmZiCNizL.VcgUTisLfuk1twUUAwnCTas.ILoNd4C	Test User	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-02-25 12:09:25.123	2026-02-25 12:09:25.123
10	test-admin-1772021365200@example.com	$2b$10$EkTU.gQmSX42uu03ZNoBQuSanhqkLTdiT34X8XOLyWxd5m.BxzFFq	Test User	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-02-25 12:09:25.263	2026-02-25 12:09:25.263
11	test-admin-future-1772021365339@example.com	$2b$10$tbUawRsXVfLfpiocTrMjYOcu0fwgwguGoCBSa1/wYbJUb3RPCQXnu	Test User	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-02-25 12:09:25.403	2026-02-25 12:09:25.403
12	integration-test-1772021426963@example.com	$2b$10$mia6E4KHtbAv2R.9zz20P.anuFvIELOv76vWSgg2REvWyHUYd9gYq	\N	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-02-25 12:10:28.969	2026-02-25 12:10:28.969
13	test-auth-1774462554561@example.com	$2b$10$JPxd/AxmOGdE3264BbUqU.Z7.AuyBSbGZa4Xj0EVHtumYGsnhnT7u	Test User	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-03-25 18:15:54.883	2026-03-25 18:15:54.883
14	test-auth-expired-1774462555064@example.com	$2b$10$DvM12KH7.QrgGbhq3lzDJ.UYZPJWRcOEIxf3JXQ5SbIn4Z5xN/Bme	Test User	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-03-25 18:15:55.234	2026-03-25 18:15:55.234
15	test-optional-auth-1774462555443@example.com	$2b$10$v2gZlxcvm6wOBmtZySd9/uyfg8tvJGkiKVuNtMvuoXXiBMLvB98tC	Test User	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-03-25 18:15:55.609	2026-03-25 18:15:55.609
16	test-userid-match-1774462555757@example.com	$2b$10$V.940ut6zMC8YjYkzQwdkuPQjfTnRgSEzUNqasAk2UWXF2y26.w6S	Test User	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-03-25 18:15:55.865	2026-03-25 18:15:55.865
17	test-userid-mismatch-1774462556012@example.com	$2b$10$3KQE0NkUf4dE.si2WtS22ODAr5rgBaS53sGCpgnFjYIMYkTM0yT9y	Test User	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-03-25 18:15:56.18	2026-03-25 18:15:56.18
18	test-userid-invalid-1774462556374@example.com	$2b$10$dgKEVuCR5PKMS81D4RUcF.LobHI2E.RBfxjkFpUBvhCso4ShNBhOW	Test User	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-03-25 18:15:56.535	2026-03-25 18:15:56.535
19	test-userid-param-1774462556703@example.com	$2b$10$EFNMzZYfIqv3FuL0huB7nuXPb4W0Y.mx15Lyvuj5aZxvhfuAfMKPG	Test User	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-03-25 18:15:56.861	2026-03-25 18:15:56.861
20	test-admin-1774462556970@example.com	$2b$10$Vi65xYeSjcURnvhNfPbeYuyU5nZy1x5JxIRbusHSRwaOmgz8GeY3a	Test User	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-03-25 18:15:57.063	2026-03-25 18:15:57.063
21	test-admin-future-1774462557243@example.com	$2b$10$JSkeFYUYxqJi56YWzEMR6.WEqPg0Fq7rt8QivVC2mcOpMEnJxdUTO	Test User	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-03-25 18:15:57.388	2026-03-25 18:15:57.388
22	test-auth-1774466175993@example.com	$2b$10$Xajt3sKSUQbDDYVnS2hW..d27AjOY7tHHMWhav2pzii/mne.91VRe	Test User	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-03-25 19:16:16.414	2026-03-25 19:16:16.414
23	test-auth-expired-1774466176596@example.com	$2b$10$7h/HlWsCC1PoyMcxvWA2VurGxOM5g/nsXNdkFFq1rNpI/FGvSvi/m	Test User	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-03-25 19:16:16.738	2026-03-25 19:16:16.738
24	test-optional-auth-1774466176833@example.com	$2b$10$UztKmpllTRUyiK67dHPWMuCKpGtA7sFysq/wtV7N6TXU/iSr.y/b.	Test User	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-03-25 19:16:16.897	2026-03-25 19:16:16.897
25	test-userid-match-1774466176987@example.com	$2b$10$HmmyVCoLYEFThPWEwEto4OU6RQDS04HUnBzrd/2Ch3Yl998MU60z2	Test User	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-03-25 19:16:17.06	2026-03-25 19:16:17.06
26	test-userid-mismatch-1774466177141@example.com	$2b$10$L9sZG8c2Mqn5FQa4u.45EusFkHIxwGFPAj8SEBAq5DGYwFJPq1DIq	Test User	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-03-25 19:16:17.223	2026-03-25 19:16:17.223
27	test-userid-invalid-1774466177335@example.com	$2b$10$/3VWwVU8YxsaT7RTBN1XD.f2fhnfUFdjdmOTcnJjCCmW2vcDMUo8e	Test User	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-03-25 19:16:17.419	2026-03-25 19:16:17.419
28	test-userid-param-1774466177500@example.com	$2b$10$IOQbzrOOWw3nRj1DdaOgW.5LT/5QEXC3QVUAZ7HcTeBEEBwIiIUWe	Test User	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-03-25 19:16:17.562	2026-03-25 19:16:17.562
29	test-admin-1774466177648@example.com	$2b$10$KmpSfZoHtwITGkgaprw78Oli/Rd4Iofskh8XN1fdjO6zipZEPtn2G	Test User	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-03-25 19:16:17.715	2026-03-25 19:16:17.715
30	test-admin-future-1774466177811@example.com	$2b$10$k72TIOOMwgxG2FdRKKX46.PuoPtOdenSE2GmWCCwHD.kN4HIv4V96	Test User	\N	\N	\N	\N	1	1	f	\N	\N	\N	\N	2026-03-25 19:16:17.896	2026-03-25 19:16:17.896
\.


--
-- Data for Name: UserDevice; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."UserDevice" (id, user_id, device_id, device_name, device_type, platform, last_sync, created_at, updated_at) FROM stdin;
2	1	device-1770991813972-a6ptnqrmx	Firefox	desktop	macOS	2026-03-14 12:22:08.353	2026-02-21 07:28:30.945	2026-03-14 12:22:08.353
3	1	device-1772265863889-3yumwewiu	Chrome	desktop	macOS	2026-02-28 10:34:06.115	2026-02-28 08:04:23.932	2026-02-28 10:34:06.115
1	1	device-1771153470412-j1elif1ye	Firefox	desktop	Linux	2026-03-04 14:23:04.18	2026-02-17 07:41:38.027	2026-03-04 14:23:04.18
\.


--
-- Data for Name: UserFartStats; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."UserFartStats" (id, user_id, total_farts, total_volume, avg_volume, max_volume, min_volume, first_fart, last_fart, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: UserPortfolio; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public."UserPortfolio" (user_id, cash, holdings, transactions) FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: seethbot
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
e3bbf79e-c337-423c-8b27-81b1b67d1c44	0e6ead4239ba1ad4f9a5dde403ea3f8155ec44ace7d5be20409b156070c95555	2026-02-13 14:09:10.033926+00	20260212144929_init	\N	\N	2026-02-13 14:09:09.505393+00	1
8c806edc-acc2-4a77-b269-0cb03facabf6	e9b3d9d647e80aef18137a9b37719e6e5400f2452ef206de3f6390df2fe8724e	2026-02-16 22:51:09.435198+00	20260216225109_add_sync_and_update_models	\N	\N	2026-02-16 22:51:09.364625+00	1
f330332e-0525-4401-bf72-0754cc80ada0	2b55aa8e91a7719fbd596baf71dad9b27a0c9b0207bdb9a0c97bb90208c18db3	2026-02-25 15:17:28.263339+00	20260225234000_add_datacenter_runs	\N	\N	2026-02-25 15:17:28.182325+00	1
8614cf61-eda3-4188-afee-688971969127	cff6d5bbeba77d48e8c5c3d5f8b6bc5a8b931b4d633cea8e552dba596a815ca8	2026-02-26 20:56:33.052023+00	20260226205632_add_subscription_system	\N	\N	2026-02-26 20:56:32.972909+00	1
6180bdcb-2830-48c4-98c1-578e43a34c29	d24ef2d8bd3858f44d52606971155b59898a3adacfcd2a4abbdd3202b8496fee	2026-03-22 18:26:19.666986+00	20260322182607_remove_subscription_system	\N	\N	2026-03-22 18:26:19.632867+00	1
\.


--
-- Name: Achievement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."Achievement_id_seq"', 1, false);


--
-- Name: Activity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."Activity_id_seq"', 1, false);


--
-- Name: CharacterMatch_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."CharacterMatch_id_seq"', 2, true);


--
-- Name: Character_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."Character_id_seq"', 1, false);


--
-- Name: Click_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."Click_id_seq"', 1, true);


--
-- Name: ConversationParticipant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."ConversationParticipant_id_seq"', 1, false);


--
-- Name: Conversation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."Conversation_id_seq"', 1, false);


--
-- Name: DailyChallenge_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."DailyChallenge_id_seq"', 1, false);


--
-- Name: DataCenterRun_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."DataCenterRun_id_seq"', 1, true);


--
-- Name: FartEvent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."FartEvent_id_seq"', 1, false);


--
-- Name: Favorite_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."Favorite_id_seq"', 1, false);


--
-- Name: GameStat_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."GameStat_id_seq"', 1, false);


--
-- Name: HighScore_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."HighScore_id_seq"', 1, false);


--
-- Name: Message_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."Message_id_seq"', 1, false);


--
-- Name: ProcessingStats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."ProcessingStats_id_seq"', 1, false);


--
-- Name: Profile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."Profile_id_seq"', 1, false);


--
-- Name: PurchasedItem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."PurchasedItem_id_seq"', 1, false);


--
-- Name: Reaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."Reaction_id_seq"', 1, false);


--
-- Name: Session_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."Session_id_seq"', 63, true);


--
-- Name: ShopItem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."ShopItem_id_seq"', 8, true);


--
-- Name: SyncLog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."SyncLog_id_seq"', 190, true);


--
-- Name: Theme_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."Theme_id_seq"', 1, false);


--
-- Name: Ticket_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."Ticket_id_seq"', 45, true);


--
-- Name: UserDevice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."UserDevice_id_seq"', 3, true);


--
-- Name: UserFartStats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."UserFartStats_id_seq"', 1, false);


--
-- Name: User_id_seq; Type: SEQUENCE SET; Schema: public; Owner: seethbot
--

SELECT pg_catalog.setval('public."User_id_seq"', 30, true);


--
-- Name: Achievement Achievement_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Achievement"
    ADD CONSTRAINT "Achievement_pkey" PRIMARY KEY (id);


--
-- Name: Activity Activity_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Activity"
    ADD CONSTRAINT "Activity_pkey" PRIMARY KEY (id);


--
-- Name: CharacterMatch CharacterMatch_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."CharacterMatch"
    ADD CONSTRAINT "CharacterMatch_pkey" PRIMARY KEY (id);


--
-- Name: Character Character_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Character"
    ADD CONSTRAINT "Character_pkey" PRIMARY KEY (id);


--
-- Name: Click Click_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Click"
    ADD CONSTRAINT "Click_pkey" PRIMARY KEY (id);


--
-- Name: ConversationParticipant ConversationParticipant_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."ConversationParticipant"
    ADD CONSTRAINT "ConversationParticipant_pkey" PRIMARY KEY (id);


--
-- Name: Conversation Conversation_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Conversation"
    ADD CONSTRAINT "Conversation_pkey" PRIMARY KEY (id);


--
-- Name: DailyChallenge DailyChallenge_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."DailyChallenge"
    ADD CONSTRAINT "DailyChallenge_pkey" PRIMARY KEY (id);


--
-- Name: DataCenterRun DataCenterRun_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."DataCenterRun"
    ADD CONSTRAINT "DataCenterRun_pkey" PRIMARY KEY (id);


--
-- Name: FartEvent FartEvent_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."FartEvent"
    ADD CONSTRAINT "FartEvent_pkey" PRIMARY KEY (id);


--
-- Name: Favorite Favorite_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Favorite"
    ADD CONSTRAINT "Favorite_pkey" PRIMARY KEY (id);


--
-- Name: GameStat GameStat_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."GameStat"
    ADD CONSTRAINT "GameStat_pkey" PRIMARY KEY (id);


--
-- Name: HighScore HighScore_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."HighScore"
    ADD CONSTRAINT "HighScore_pkey" PRIMARY KEY (id);


--
-- Name: Message Message_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_pkey" PRIMARY KEY (id);


--
-- Name: ProcessingStats ProcessingStats_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."ProcessingStats"
    ADD CONSTRAINT "ProcessingStats_pkey" PRIMARY KEY (id);


--
-- Name: Profile Profile_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Profile"
    ADD CONSTRAINT "Profile_pkey" PRIMARY KEY (id);


--
-- Name: PurchasedItem PurchasedItem_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."PurchasedItem"
    ADD CONSTRAINT "PurchasedItem_pkey" PRIMARY KEY (id);


--
-- Name: Reaction Reaction_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Reaction"
    ADD CONSTRAINT "Reaction_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: Setting Setting_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Setting"
    ADD CONSTRAINT "Setting_pkey" PRIMARY KEY (key);


--
-- Name: ShopItem ShopItem_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."ShopItem"
    ADD CONSTRAINT "ShopItem_pkey" PRIMARY KEY (id);


--
-- Name: Stock Stock_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Stock"
    ADD CONSTRAINT "Stock_pkey" PRIMARY KEY (name);


--
-- Name: SyncLog SyncLog_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."SyncLog"
    ADD CONSTRAINT "SyncLog_pkey" PRIMARY KEY (id);


--
-- Name: Theme Theme_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Theme"
    ADD CONSTRAINT "Theme_pkey" PRIMARY KEY (id);


--
-- Name: Ticket Ticket_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Ticket"
    ADD CONSTRAINT "Ticket_pkey" PRIMARY KEY (id);


--
-- Name: UserDevice UserDevice_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."UserDevice"
    ADD CONSTRAINT "UserDevice_pkey" PRIMARY KEY (id);


--
-- Name: UserFartStats UserFartStats_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."UserFartStats"
    ADD CONSTRAINT "UserFartStats_pkey" PRIMARY KEY (id);


--
-- Name: UserPortfolio UserPortfolio_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."UserPortfolio"
    ADD CONSTRAINT "UserPortfolio_pkey" PRIMARY KEY (user_id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Achievement_user_id_achievement_id_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "Achievement_user_id_achievement_id_key" ON public."Achievement" USING btree (user_id, achievement_id);


--
-- Name: Achievement_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Achievement_user_id_idx" ON public."Achievement" USING btree (user_id);


--
-- Name: Activity_activity_type_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Activity_activity_type_idx" ON public."Activity" USING btree (activity_type);


--
-- Name: Activity_recorded_at_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Activity_recorded_at_idx" ON public."Activity" USING btree (recorded_at);


--
-- Name: Activity_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Activity_user_id_idx" ON public."Activity" USING btree (user_id);


--
-- Name: Character_elo_rating_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Character_elo_rating_idx" ON public."Character" USING btree (elo_rating);


--
-- Name: ConversationParticipant_conversation_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "ConversationParticipant_conversation_id_idx" ON public."ConversationParticipant" USING btree (conversation_id);


--
-- Name: ConversationParticipant_conversation_id_user_id_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "ConversationParticipant_conversation_id_user_id_key" ON public."ConversationParticipant" USING btree (conversation_id, user_id);


--
-- Name: ConversationParticipant_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "ConversationParticipant_user_id_idx" ON public."ConversationParticipant" USING btree (user_id);


--
-- Name: Conversation_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Conversation_id_idx" ON public."Conversation" USING btree (id);


--
-- Name: DailyChallenge_date_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "DailyChallenge_date_idx" ON public."DailyChallenge" USING btree (date);


--
-- Name: DailyChallenge_user_id_challenge_type_date_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "DailyChallenge_user_id_challenge_type_date_key" ON public."DailyChallenge" USING btree (user_id, challenge_type, date);


--
-- Name: DailyChallenge_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "DailyChallenge_user_id_idx" ON public."DailyChallenge" USING btree (user_id);


--
-- Name: DataCenterRun_last_played_at_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "DataCenterRun_last_played_at_idx" ON public."DataCenterRun" USING btree (last_played_at);


--
-- Name: DataCenterRun_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "DataCenterRun_user_id_idx" ON public."DataCenterRun" USING btree (user_id);


--
-- Name: DataCenterRun_user_id_status_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "DataCenterRun_user_id_status_idx" ON public."DataCenterRun" USING btree (user_id, status);


--
-- Name: FartEvent_timestamp_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "FartEvent_timestamp_idx" ON public."FartEvent" USING btree ("timestamp");


--
-- Name: FartEvent_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "FartEvent_user_id_idx" ON public."FartEvent" USING btree (user_id);


--
-- Name: Favorite_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Favorite_user_id_idx" ON public."Favorite" USING btree (user_id);


--
-- Name: Favorite_user_id_item_type_item_id_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "Favorite_user_id_item_type_item_id_key" ON public."Favorite" USING btree (user_id, item_type, item_id);


--
-- Name: GameStat_game_type_stat_type_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "GameStat_game_type_stat_type_idx" ON public."GameStat" USING btree (game_type, stat_type);


--
-- Name: GameStat_recorded_at_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "GameStat_recorded_at_idx" ON public."GameStat" USING btree (recorded_at);


--
-- Name: GameStat_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "GameStat_user_id_idx" ON public."GameStat" USING btree (user_id);


--
-- Name: HighScore_game_type_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "HighScore_game_type_idx" ON public."HighScore" USING btree (game_type);


--
-- Name: HighScore_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "HighScore_user_id_idx" ON public."HighScore" USING btree (user_id);


--
-- Name: Message_conversation_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Message_conversation_id_idx" ON public."Message" USING btree (conversation_id);


--
-- Name: Message_created_at_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Message_created_at_idx" ON public."Message" USING btree (created_at);


--
-- Name: Message_sender_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Message_sender_id_idx" ON public."Message" USING btree (sender_id);


--
-- Name: ProcessingStats_date_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "ProcessingStats_date_key" ON public."ProcessingStats" USING btree (date);


--
-- Name: Profile_user_id_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "Profile_user_id_key" ON public."Profile" USING btree (user_id);


--
-- Name: PurchasedItem_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "PurchasedItem_user_id_idx" ON public."PurchasedItem" USING btree (user_id);


--
-- Name: PurchasedItem_user_id_item_id_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "PurchasedItem_user_id_item_id_key" ON public."PurchasedItem" USING btree (user_id, item_id);


--
-- Name: Reaction_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Reaction_user_id_idx" ON public."Reaction" USING btree (user_id);


--
-- Name: Reaction_user_id_target_type_target_id_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "Reaction_user_id_target_type_target_id_key" ON public."Reaction" USING btree (user_id, target_type, target_id);


--
-- Name: Session_token_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Session_token_idx" ON public."Session" USING btree (token);


--
-- Name: Session_token_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "Session_token_key" ON public."Session" USING btree (token);


--
-- Name: Session_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Session_user_id_idx" ON public."Session" USING btree (user_id);


--
-- Name: ShopItem_category_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "ShopItem_category_idx" ON public."ShopItem" USING btree (category);


--
-- Name: SyncLog_device_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "SyncLog_device_id_idx" ON public."SyncLog" USING btree (device_id);


--
-- Name: SyncLog_started_at_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "SyncLog_started_at_idx" ON public."SyncLog" USING btree (started_at);


--
-- Name: SyncLog_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "SyncLog_user_id_idx" ON public."SyncLog" USING btree (user_id);


--
-- Name: Theme_user_id_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "Theme_user_id_key" ON public."Theme" USING btree (user_id);


--
-- Name: Ticket_is_deleted_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Ticket_is_deleted_idx" ON public."Ticket" USING btree (is_deleted);


--
-- Name: Ticket_priority_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Ticket_priority_idx" ON public."Ticket" USING btree (priority);


--
-- Name: Ticket_status_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Ticket_status_idx" ON public."Ticket" USING btree (status);


--
-- Name: Ticket_type_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "Ticket_type_idx" ON public."Ticket" USING btree (type);


--
-- Name: UserDevice_device_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "UserDevice_device_id_idx" ON public."UserDevice" USING btree (device_id);


--
-- Name: UserDevice_device_id_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "UserDevice_device_id_key" ON public."UserDevice" USING btree (device_id);


--
-- Name: UserDevice_user_id_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "UserDevice_user_id_idx" ON public."UserDevice" USING btree (user_id);


--
-- Name: UserFartStats_user_id_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "UserFartStats_user_id_key" ON public."UserFartStats" USING btree (user_id);


--
-- Name: User_email_idx; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE INDEX "User_email_idx" ON public."User" USING btree (email);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: seethbot
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: Achievement Achievement_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Achievement"
    ADD CONSTRAINT "Achievement_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Activity Activity_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Activity"
    ADD CONSTRAINT "Activity_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CharacterMatch CharacterMatch_character_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."CharacterMatch"
    ADD CONSTRAINT "CharacterMatch_character_id_fkey" FOREIGN KEY (character_id) REFERENCES public."Character"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: CharacterMatch CharacterMatch_voter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."CharacterMatch"
    ADD CONSTRAINT "CharacterMatch_voter_id_fkey" FOREIGN KEY (voter_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: CharacterMatch CharacterMatch_winner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."CharacterMatch"
    ADD CONSTRAINT "CharacterMatch_winner_id_fkey" FOREIGN KEY (winner_id) REFERENCES public."Character"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ConversationParticipant ConversationParticipant_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."ConversationParticipant"
    ADD CONSTRAINT "ConversationParticipant_conversation_id_fkey" FOREIGN KEY (conversation_id) REFERENCES public."Conversation"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: DailyChallenge DailyChallenge_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."DailyChallenge"
    ADD CONSTRAINT "DailyChallenge_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: DataCenterRun DataCenterRun_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."DataCenterRun"
    ADD CONSTRAINT "DataCenterRun_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Favorite Favorite_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Favorite"
    ADD CONSTRAINT "Favorite_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: GameStat GameStat_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."GameStat"
    ADD CONSTRAINT "GameStat_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: HighScore HighScore_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."HighScore"
    ADD CONSTRAINT "HighScore_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Message Message_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_conversation_id_fkey" FOREIGN KEY (conversation_id) REFERENCES public."Conversation"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Message Message_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_sender_id_fkey" FOREIGN KEY (sender_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Profile Profile_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Profile"
    ADD CONSTRAINT "Profile_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PurchasedItem PurchasedItem_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."PurchasedItem"
    ADD CONSTRAINT "PurchasedItem_item_id_fkey" FOREIGN KEY (item_id) REFERENCES public."ShopItem"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Reaction Reaction_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Reaction"
    ADD CONSTRAINT "Reaction_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Session Session_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Theme Theme_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."Theme"
    ADD CONSTRAINT "Theme_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UserDevice UserDevice_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."UserDevice"
    ADD CONSTRAINT "UserDevice_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: UserFartStats UserFartStats_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."UserFartStats"
    ADD CONSTRAINT "UserFartStats_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: UserPortfolio UserPortfolio_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: seethbot
--

ALTER TABLE ONLY public."UserPortfolio"
    ADD CONSTRAINT "UserPortfolio_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict r4adHgGIJqUCDLcY5xRRBJcDIP6BUtCYEPeg5zEPoyCAHocPfJ7n62XRgPD4ls6

